package com.centurylink.cgs.dispatchdatabase;

import java.util.ArrayList;

import oracle.sql.ARRAY;
import oracle.sql.CLOB;

public class ArrayWithClobs {
	private ARRAY array = null;
	private ArrayList<CLOB> clobArray = new ArrayList<CLOB>();
	public ARRAY getArray() {
		return array;
	}
	public void setArray(ARRAY array) {
		this.array = array;
	}
	public ArrayList<CLOB> getClobArray() {
		return clobArray;
	}
	public void setClobArray(ArrayList<CLOB> clobArray) {
		this.clobArray = clobArray;
	}

}
