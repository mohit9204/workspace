package com.centurylink.cgs.dispatchdatabase;

import java.util.Collection;

/**
 * This interface defines the methods required by the Database class to use arrays of ORACLE objects as 
 * parameters to stored procedures.
 *  
 * @author wmiddle
 *
 */
public interface DatabaseObjectArray extends Collection<DatabaseObject>{
	/**
	 * This returns the name of the collection type in ORACLE
	 * @return
	 */
	public String getArrayDescriptorName();
	/**
	 * This returns the name of the ORACLE data type for the collection objects
	 * @return
	 */
	public String getObjectDescriptorName();
	/**
	 * This method returns the specific class type of the collection objects
	 * @return
	 */
	public Class getObjectClass();

}
