package com.centurylink.cgs.dispatchdatabase;

public class Statement {

	private String name;
	private String statement;

	
	public Statement() {

	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}


}
