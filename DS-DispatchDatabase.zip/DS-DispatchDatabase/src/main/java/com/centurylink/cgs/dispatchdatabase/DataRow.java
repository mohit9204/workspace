package com.centurylink.cgs.dispatchdatabase;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
/***
 *   
 * @author wmiddle
 * 
 */
public class DataRow<Object1, Object2> extends Hashtable<Object, Object> {

	// An ArrayList is used to preserve the order of the column names in a row
	private ArrayList<String> mKeys = new ArrayList<String>();
	
	private static final long serialVersionUID = 6043881632922440894L;
	
	/***
	 * Adds a new column to the row. Column name is converted to upper case.
	 * A list of the column names is maintained to preserve column order.
	 */
	@Override
	public Object put(Object pKey, Object pValue) {
		mKeys.add(pKey.toString().toUpperCase());
		return super.put(pKey.toString().toUpperCase(), pValue == null ? "" : pValue);
	}
	/**
	 * Retrieve a value from a row.  Column name is case insensitive.
	 */
	@Override
	public Object get(Object pKey) {
		return super.get(pKey.toString().toUpperCase());
	}
	public Date getDate(Object pKey) {
		Object object = super.get(pKey.toString().toUpperCase());
		if (object instanceof oracle.sql.TIMESTAMP) {
			oracle.sql.TIMESTAMP ts = (oracle.sql.TIMESTAMP) object;
			try {
				return new Timestamp(ts.dateValue().getTime());
			} catch (SQLException e) {
				return null;
			}
		}
		if (object == null)
			return null;
		else if (object.toString().trim().length() == 0)
			return null;
		else
			return (Date) super.get(pKey.toString().toUpperCase());
	}
	public String getString(Object pKey) { 
		if (super.get(pKey.toString().toUpperCase()) != null)
			return super.get(pKey.toString().toUpperCase()).toString();
		else
			return null;
	}
	public Timestamp getTimestamp(Object pKey) {
		Object object = super.get(pKey.toString().toUpperCase());
		if (object instanceof oracle.sql.TIMESTAMP) {
			oracle.sql.TIMESTAMP ts = (oracle.sql.TIMESTAMP) object;
			try {
				return new Timestamp(ts.dateValue().getTime());
			} catch (SQLException e) {
				return null;
			}
		}
		if (object == null)
			return null;
		else if (object.toString().trim().length() == 0)
			return null;
		else
			return (Timestamp) super.get(pKey.toString().toUpperCase());
	}
	/***
	 * Returns an ArrayList of the column name values (In uppercase)
	 * @return
	 */
	public ArrayList<String> getColumnHeaders() {
		return mKeys;
	}
}
