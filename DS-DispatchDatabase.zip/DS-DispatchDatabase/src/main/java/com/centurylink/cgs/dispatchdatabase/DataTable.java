package com.centurylink.cgs.dispatchdatabase;

import java.util.ArrayList;
/***

 * @author wmiddle
 *
 */
public class DataTable {
	ArrayList<DataRow<String, Object>> mRows = new ArrayList<DataRow<String, Object>>();
	
	/***
	 * Returns the rows in a table
	 * @return ArrayList
	 */
	public ArrayList<DataRow<String, Object>> getRows() {
		return mRows;
	}

	/***
	 * Set the ArrayList rows for a table
	 * @param rows ArrayList of DataRow objects
	 */
	public void setRows(ArrayList<DataRow<String, Object>> rows) {
		for(DataRow<String, Object> row: rows) {
			addRow(row);
		}
	}

	
	/***
	 * Filters rows based on input key.
	 * @return ArrayList
	 */	
	public ArrayList<Object> filterRows(String inputKey) {

		ArrayList<Object> filteredRecord = new ArrayList<Object>();

		for (int index = 0; index < mRows.size(); index++) {
            DataRow<String, Object> returnData = (DataRow<String, Object>) mRows.get(index);
        	if(null!= returnData.get("INPUT_KEY")&&inputKey.equals(returnData.get("INPUT_KEY"))){
        	filteredRecord.add(returnData.get("OUTPUT_VALUE"));
			}

		}
		return filteredRecord;
	}

	/***
	 * Add a single row to a DataTable
	 * @param pRow
	 */
	public void addRow(DataRow<String, Object> pRow) {
		mRows.add(pRow);
	}
	/***
	 * Provides a formatted string for the table.  
	 */
	@Override
	public String toString() {
		boolean first = true;
		StringBuilder str = new StringBuilder();
		
		ArrayList<Integer>  sizes = getColSizes();
		for (DataRow<String, Object> row : this.getRows()) {
			ArrayList<String> keys = row.getColumnHeaders();
			if (first)
			{
				int i = 0;
				for(Object key: keys) {
					str.append(String.format("%-"+sizes.get(i)+"s    ",key.toString()));
					++i;
				}
				first = false;
				str.append("\n");	
				for (i = 0; i < sizes.size(); ++i)
				{
					for (int j = 0; j < sizes.get(i); ++j)
						str.append("-");
					str.append("    ");
				}
				str.append("\n");	
			}
			int i = 0;
			for(Object key: keys) {
				str.append(String.format("%-"+sizes.get(i)+"s    ",row.get(key).toString()));
				++i;
			}	
			str.append("\n");			
		}
		return str.toString();
	}
	public String toDelimitedString(String delimiter) {
		boolean first = true;
		StringBuilder str = new StringBuilder();
		
		for (DataRow<String, Object> row : this.getRows()) {
			ArrayList<String> keys = row.getColumnHeaders();
			if (first)
			{
				int i = 0;
				for(Object key: keys) {
					str.append(String.format("\"%s\"",key.toString()));
					++i;
					if (i < keys.size())
						str.append(delimiter);
				}
				str.append("\n");	
				first = false;
			}
			int i = 0;
			for(Object key: keys) {
				str.append(String.format("\"%s\"",row.get(key).toString()));
				++i;
				if (i < keys.size())
					str.append(delimiter);
			}	
			str.append("\n");			
		}
		return str.toString();

	}
	public String toCsvString() {
		return toDelimitedString(",");
	}
	/***
	 * Calculates the maximum column widths for a table based on 
	 * header and table values
	 * @return ArrayList of Integers
	 */
	private ArrayList<Integer> getColSizes() {
		
		ArrayList<Integer> sizes = new ArrayList<Integer>();
		if (mRows.size() > 0)
		{
			// Set the initial column width to the header width
			int i = 0;
			for (Object header : mRows.get(0).getColumnHeaders())
			{
				if (sizes.size() > i)
					sizes.set(i, header.toString().length());
				else
					sizes.add(header.toString().length());
				++i;
			}
			// If any value is wider than the header for any row, set the new width
			for(DataRow<String, Object> row : mRows)
			{
				i = 0;
				for (Object column : row.getColumnHeaders())
				{
					Integer maxSize = sizes.get(i);
					Object value = row.get(column);
					if (value.toString().length() > maxSize)
						sizes.set(i, value.toString().length());
					++i;
				}
			}
		}

		return sizes;
	}
}
