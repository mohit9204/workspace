package com.centurylink.cgs.dispatchdatabase;

/**
 * This interface defines the methods required by the Database class to use ORACLE objects as parameters to stored procedures.
 *  
 * @author wmiddle
 *
 */
public interface DatabaseObject {
	
	
	/**
	 * This method should construct an array of objects that matches the specification of the associated ORACLE object
	 * @return
	 */
	public Object [] toObjects();
	/**
	 * %This method should populate the object with the values as provided through the assocuated ORACLE object
	 * @param objects
	 */
	public void init(Object[] objects);
	/**
	 * This method will return the name of the type in ORACLE
	 * @return
	 */
	public String getObjectDescriptorName();
	

}
