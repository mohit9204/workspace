package com.centurylink.cgs.dispatchdatabase;

import java.util.ArrayList;

import oracle.sql.CLOB;
import oracle.sql.STRUCT;

public class StructWithClobs {
	STRUCT struct = null;
	ArrayList<CLOB> clobArray = new ArrayList<CLOB>();
	public STRUCT getStruct() {
		return struct;
	}
	public void setStruct(STRUCT struct) {
		this.struct = struct;
	}
	public ArrayList<CLOB> getClobArray() {
		return clobArray;
	}
	public void setClobArray(ArrayList<CLOB> clobArray) {
		this.clobArray = clobArray;
	}

}
