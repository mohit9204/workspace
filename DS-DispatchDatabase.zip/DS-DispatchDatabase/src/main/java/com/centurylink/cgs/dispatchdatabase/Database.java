package com.centurylink.cgs.dispatchdatabase;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import oracle.jdbc.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

public class Database  extends NamedParameterJdbcDaoSupport {

	private final static String DEFAULT_CONFIG_FILE = "DatabaseConfiguration.xml";

	private static HashMap<String, BeanFactory> factoryMap = new HashMap<String, BeanFactory>();
	BeanFactory factory = null;
	
	
	public Database(String name) {
		factory = getbeanFactory(DEFAULT_CONFIG_FILE); 
		this.setDataSource((DataSource) factory.getBean(name));
	}
	public Database(DataSource dataSource) {
		factory = getbeanFactory(DEFAULT_CONFIG_FILE); 
		this.setDataSource(dataSource);
	}
	public Database(String configFileName, String name) {
		factory = getbeanFactory(configFileName); 
		this.setDataSource((DataSource) factory.getBean(name));
	}
	public Database(String configFileName, DataSource dataSource) {
		factory = getbeanFactory(configFileName); 
		this.setDataSource(dataSource);
	}
	public DataTable runQuery(String statementName) throws Exception {
		return runQuery(statementName, new ArrayList<Parameter>());
	}
	/**
	 * This method retrieves the prepared statement from DatabaseConfiguration.xml
	 * and runs it using the parameters passed in
	 * @param statementName - The name of statement in the queries list in the config file
	 * @param parameters - An array list of the input and output parameters
	 * @return
	 * @throws Exception 
	 */
	public DataTable runQuery(String statementName, ArrayList<Parameter> parameters) throws Exception {
		DataTable table = new DataTable();
		ArrayList<DataRow<String, Object>> rows = new ArrayList<DataRow<String, Object>>();
		Statement statementConfig = null;
		ArrayList queries = (ArrayList) factory.getBean("queries");
		for(Object query : queries) {
			Statement statement = (Statement)query;
			if (statement.getName().equalsIgnoreCase(statementName)) {
				statementConfig = statement;
				break;
			}
		}
		if (statementConfig == null)
			throw new Exception("Undefined statement "+statementName);
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		InputStream in = null;
		StringWriter w = null;
		try {
			connection = this.getDataSource().getConnection();
			preparedStatement = connection.prepareStatement(statementConfig.getStatement());
		
			for (int i = 0; parameters != null && i < parameters.size(); ++i) {
				Object value = parameters.get(i).getValue();
				if (value instanceof java.util.Date)
					value = new java.sql.Date(((java.util.Date)value).getTime());
				preparedStatement.setObject(i+1,value);
			}
			rs = preparedStatement.executeQuery();
	
			while(rs.next()){
				ResultSetMetaData rsmd = rs.getMetaData();
				DataRow<String, Object> row = new DataRow<String, Object>();
				for (int i = 1;i <= rsmd.getColumnCount(); ++i) {
					if (rs.getObject(i) instanceof oracle.sql.TIMESTAMPTZ)
						row.put(rsmd.getColumnName(i),  ((oracle.sql.TIMESTAMPTZ)rs.getObject(i)).dateValue(connection.unwrap(OracleConnection.class)));
					else if (rs.getObject(i) instanceof oracle.sql.CLOB) {
		        		CLOB clob = (CLOB)rs.getObject(i);
						in = clob.getAsciiStream();
						w = new StringWriter();
						IOUtils.copy(in, w);
						String stringValue = w.toString();
						row.put(rsmd.getColumnName(i), stringValue);
						try { if (clob.isTemporary()) clob.freeTemporary(); } catch (Exception e) {}
						try { clob.free(); } catch (Exception e) {}
					}
					else if (rs.getObject(i) instanceof oracle.sql.BLOB) {
						BLOB blob = (BLOB)rs.getObject(i);
						int blobLength = (int) blob.length();  
						byte[] blobAsBytes = blob.getBytes(1, blobLength);
						row.put(rsmd.getColumnName(i), blobAsBytes);
						try { if (blob.isTemporary()) blob.freeTemporary(); } catch (Exception e) {}
						try { blob.free(); } catch (Exception e) {}
					}
					else	
						row.put(rsmd.getColumnName(i),  rs.getObject(i)); 
				}
				rows.add(row);
			}
		} finally {
			if (rs != null)
				try { rs.close(); } catch (SQLException e){};
			if (preparedStatement != null)
				try { preparedStatement.close(); } catch (SQLException e){};
			if (connection != null)
				try{ connection.close(); } catch (SQLException e){};
			if (in != null)
				try {in.close();} catch(Exception e) {}
			if (w != null)
				try {w.close();} catch(Exception e) {}
		}
		table.setRows(rows);
		return table;
		
	}
/**
	 * This method retrieves the prepared statement from DatabaseConfiguration.xml
	 * and runs it using the parameters passed in.  It uses JDBCTemplate which does a better job
	 * of releasing temporary CLOB tablespace.  However, performance is slower than runQuery
	 * @param statementName - The name of statement in the queries list in the config file
	 * @param parameters - An array list of the input and output parameters
	 * @return
	 * @throws Exception 
 */
	public DataTable runQueryJdbcTemplate(String statementName, ArrayList<Parameter> parameters) throws Exception {
		DataTable table = new DataTable();
		ArrayList<DataRow<String, Object>> rows = new ArrayList<DataRow<String, Object>>();
		Statement statementConfig = null;
		ArrayList queries = (ArrayList) factory.getBean("queries");
		for(Object query : queries) {
			Statement statement = (Statement)query;
			if (statement.getName().equalsIgnoreCase(statementName)) {
				statementConfig = statement;
				break;
			}
		}
		if (statementConfig == null)
			throw new Exception("Undefined statement "+statementName);
		Object [] parameterObjects = new Object[parameters.size()];
		for(int i = 0; i < parameters.size(); ++i) {
			parameterObjects[i] = parameters.get(i).getValue();
		}

		List<DataRow> list = this.getJdbcTemplate().query(statementConfig.getStatement(), parameterObjects, new DataRowMapper());
		this.getJdbcTemplate().getDataSource().getConnection().close();
		for (DataRow row : list)
			table.addRow(row);
		return table;
	}
	/**
	 * This method runs a simple query to see if the database connection pool is healthy
	 * @throws Exception 
	 */
	public void runHealthCheck() throws Exception {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = this.getDataSource().getConnection();
			if (connection.toString().toUpperCase().contains("ORACLE")) {
				preparedStatement = connection.prepareStatement("select 1 from dual");
			} else {
				preparedStatement = connection.prepareStatement("SELECT GETDATE()");
			}
			preparedStatement.executeQuery();
		} finally {
			if (preparedStatement != null)
				try { preparedStatement.close(); } catch (SQLException e){};
			if (connection != null)
				try{ connection.close(); } catch (SQLException e){};
		}
	}
	
	/**
	 * This method retrieves the prepared statement from DatabaseConfiguration.xml
	 * and runs it using the parameters passed in
	 * @param statementName - The name of statement in the nonQueries list in the config file
	 * @param parameters - An array list of the input and output parameters
	 * @throws Exception 
	 */
	public void runNonQuery(String statementName, ArrayList<Parameter> parameters) throws Exception {
		Statement statementConfig = null;
		ArrayList nonQueries = (ArrayList) factory.getBean("nonQueries");
		for(Object nonQuery : nonQueries) {
			Statement statement = (Statement)nonQuery;
			if (statement.getName().equalsIgnoreCase(statementName)) {
				statementConfig = statement;
				break;
			}
		}
		if (statementConfig == null)
			throw new Exception("Undefined statement "+statementName);
		
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			connection = this.getDataSource().getConnection();
			preparedStatement = connection.prepareStatement(statementConfig.getStatement());
		
			for (int i = 0; parameters != null && i < parameters.size(); ++i) {
				Object value = parameters.get(i).getValue();
				if ( value instanceof Timestamp) {
					preparedStatement.setTimestamp(i+1, (Timestamp) value);
				}
				else {
					if (value instanceof java.util.Date)
						value = new java.sql.Date(((java.util.Date)value).getTime());
					preparedStatement.setObject(i+1,value);
				}
			}
			rs = preparedStatement.executeQuery();
	
		} finally {
			if (rs != null)
				try { rs.close(); } catch (SQLException e){};
			if (preparedStatement != null)
				try { preparedStatement.close(); } catch (SQLException e){};
			if (connection != null)
				try{ connection.close(); } catch (SQLException e){};
		}
		
	}
	/**
	 * This method retrieves the stored procedure from DatabaseConfiguration.xml
	 * and runs it with the parameters provided
	 * @param name - The name of the stored procedure in the storedProcedures list in the config file
	 * @param parameters - An array list of the input and output parameters
	 * @return
	 * @throws Exception 
	 */
	public DataTable runStoredProcedure(String name, ArrayList<Parameter> parameters) throws Exception {
		ArrayList nonQueries = (ArrayList) factory.getBean("storedProcedures");
		ArrayList<CLOB> clobArray = new ArrayList<CLOB>();
		StoredProcedure procedureConfig = null;
		for(Object nonQuery : nonQueries) {
			StoredProcedure procedure = (StoredProcedure)nonQuery;
			if (procedure.getName().equalsIgnoreCase(name)) {
				procedureConfig = procedure;
				break;
			}
		}
		if (procedureConfig == null)
			throw new Exception("Undefined procedure "+procedureConfig);
		DataTable table = new DataTable();
		ArrayList<DataRow<String, Object>> rows = new ArrayList<DataRow<String, Object>>();
		Connection connection = null;
		CallableStatement statement = null;

		try {
			connection = this.getDataSource().getConnection();
			String stmnt = buildCallStatement(procedureConfig.getProcedure(), parameters);
			statement = connection.prepareCall(stmnt);		
			int i = 1;
			for (Parameter parameter : parameters) {
				if (parameter.getDirection().equals(Parameter.DIRECTION_OUT) || parameter.getDirection().equals(Parameter.DIRECTION_IN_OUT )) {
					if (parameter.getType() == Types.STRUCT)
						statement.registerOutParameter(i, Types.STRUCT, parameter.getObjectDescriptorName());
					else if (parameter.getType() == Types.ARRAY)
						statement.registerOutParameter(i, Types.ARRAY, parameter.getArrayDescriptorName());
					else
						statement.registerOutParameter(i, parameter.getType());
				}
				
				if (parameter.getDirection().equals(Parameter.DIRECTION_IN) || parameter.getDirection().equals(Parameter.DIRECTION_IN_OUT )) {
					switch (parameter.getType()) {
						case Types.VARCHAR : 
							statement.setString(i, (String)parameter.getValue());
							break;
						case Types.INTEGER : 
							statement.setInt(i, (Integer)parameter.getValue());
							break;
						case Types.BIGINT : 
							statement.setLong(i, (Long)parameter.getValue());
							break;
						case Types.DATE : 
							statement.setDate(i, (Date)parameter.getValue());
							break;
						case Types.BLOB : 
							statement.setBytes(i, (byte[])parameter.getValue());
							break;
						case Types.TIMESTAMP :
							statement.setTimestamp(i, (Timestamp) parameter.getValue());
							break;
						case Types.CLOB : 
							char [] chars = (char [])parameter.getValue();
							String value = new String(chars);
							statement.setString(i, value);
							break;		
						case Types.STRUCT :
							DatabaseObject object = (DatabaseObject)parameter.getValue();
							if (object != null && object.toObjects() != null) {
								StructWithClobs structWithClobs = getSTRUCT(connection, parameter.getObjectDescriptorName(), object);
								clobArray.addAll(structWithClobs.getClobArray());
								statement.setObject(i, structWithClobs.getStruct(), Types.STRUCT);
							}							
							else
								statement.setNull(i, Types.STRUCT, parameter.getObjectDescriptorName());
							break;
						case Types.ARRAY :
							ArrayList<DatabaseObject> arrayList = (ArrayList<DatabaseObject>)parameter.getValue();
							if (arrayList != null && arrayList.size() > 0) {
								ArrayWithClobs arrayWithClobs = getArray(connection, parameter.getObjectDescriptorName(), parameter.getArrayDescriptorName(), arrayList);
								clobArray.addAll(arrayWithClobs.getClobArray());
								statement.setArray(i, arrayWithClobs.getArray());
							}
							else
								statement.setNull(i, Types.ARRAY, parameter.getArrayDescriptorName());
							break;
					}				
				}
				++i;
			}
			boolean success = statement.execute();
			i = 1;
			DataRow row = new DataRow();
			for (Parameter parameter : parameters) {
				if (parameter.getDirection().equals(Parameter.DIRECTION_OUT) ||
						parameter.getDirection().equals(Parameter.DIRECTION_IN_OUT)) {
					Object value = statement.getObject(i);
					if (parameter.getType() == Types.STRUCT) {
						parameter.setValue(getDatabaseObject((Struct)value, parameter.getClazz()));
					}
					else if (parameter.getType() == Types.ARRAY) {
						if (value != null) {
							ArrayList<DatabaseObject> objectArray = getObjectArrayArrayList((Object [])((Array)value).getArray(), parameter.getClazz());
							DatabaseObjectArray databaseObjectArray = (DatabaseObjectArray) parameter.getArrayClazz().newInstance();
							databaseObjectArray.addAll(objectArray);
				            parameter.setValue(databaseObjectArray);
						}
						else
							parameter.setValue((String)null);
					}
					else if (value instanceof oracle.sql.TIMESTAMPTZ) {
						Date dateValue = ((oracle.sql.TIMESTAMPTZ)value).dateValue(connection.unwrap(OracleConnection.class));
						parameter.setValue(dateValue);
						if (parameter.getName() != null)
							row.put(parameter.getName(), dateValue);
					}
					else {
						parameter.setValue(value);
						if (parameter.getName() != null)
							row.put(parameter.getName(), value);
					}
				}
				++i;
			}
			if (row.size() > 0)
				table.addRow(row);

		}
		finally {
			for (CLOB clob : clobArray) {
				try { if (clob.isTemporary()) clob.freeTemporary(); } catch (Exception e) {}
				try { clob.free(); } catch (Exception e) {}
			}
			if (statement != null)
				try { statement.close(); } catch (SQLException e){};
			if (connection != null)
				try{ connection.close(); } catch (SQLException e){};
		}
		return table;
	}
	public ArrayList<Object []> runStoredProcedure(String pProcedureName,
			String pObjectDescriptorName, String pArrayDescriptorName,
			ArrayList<Object[]> pObjectArray, String pOutObjectDescriptorName,
			String pOutArrayDescriptorName,
			String pTimeoutValueSeconds) throws SQLException
 {
		ArrayList nonQueries = (ArrayList) factory.getBean("storedProcedures");
		ArrayList<CLOB> clobArray = new ArrayList<CLOB>();
		StoredProcedure procedureConfig = null;
		for(Object nonQuery : nonQueries) {
			StoredProcedure procedure = (StoredProcedure)nonQuery;
			if (procedure.getName().equalsIgnoreCase(pProcedureName)) {
				procedureConfig = procedure;
				break;
			}
		}
		ArrayList<Object []> outputArray = new ArrayList<Object []>();
		Connection connection = this.getDataSource().getConnection();
		OracleConnection oracleConnection = null;
		CallableStatement cs = null;
		try {

			oracleConnection = connection.unwrap(OracleConnection.class);
			StructDescriptor structDescriptor = StructDescriptor.createDescriptor(pObjectDescriptorName, oracleConnection);
			StructDescriptor.createDescriptor(pOutObjectDescriptorName, oracleConnection);

			int numberOfRows = pObjectArray.size();
			STRUCT[] structs = new STRUCT[numberOfRows];
			for (int index = 0; index < numberOfRows; index++)
			{
				Object [] objectArray = pObjectArray.get(index);
  				for (int i = 0; i < objectArray.length; ++i) {
					Object object = objectArray[i];
					if (object instanceof char []) {
						CLOB clob = CLOB.createTemporary(oracleConnection, true, CLOB.DURATION_SESSION);
						clob.putChars(1, (char[]) object);
						objectArray[i] = clob;
						clobArray.add(clob);
					}
				}
				STRUCT struct = new STRUCT(structDescriptor, oracleConnection, objectArray);
				structs[index] = struct;
				
			}
			ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor(pArrayDescriptorName, oracleConnection);
			ArrayDescriptor.createDescriptor(pOutArrayDescriptorName, oracleConnection);
			ARRAY myArray = new ARRAY(descriptor, oracleConnection, structs);
	        cs = oracleConnection.prepareCall(String.format("{Call %s(?, ?)}",procedureConfig.getProcedure()));
			cs.setArray(1, myArray);
	        cs.registerOutParameter(2, Types.ARRAY, pOutArrayDescriptorName);     
	        cs.execute();

	        Object[] data = (Object[]) ((Array) cs.getObject(2)).getArray();
	        for(Object object : data) {
	            Struct row = (Struct) object;
	            Object [] objectArray = new Object[row.getAttributes().length];
	            int idx = 0;
	            for(Object attribute : row.getAttributes()) {               
	                objectArray[idx] = attribute;
	                ++idx;
	            }
	            outputArray.add(objectArray);
	        }
	        

		} 
		finally{
			for (CLOB clob : clobArray) {
				try { if (clob.isTemporary()) clob.freeTemporary(); } catch (Exception e) {}
				try { clob.free(); } catch (Exception e) {}
			}
			if (cs != null)
				try { cs.close(); } catch (SQLException e){};
			if (connection != null)
				try{ connection.close(); } catch (SQLException e){};
		}

		return outputArray;
	}
	public void runStoredProcedure(String pProcedureName,
			String pObjectDescriptorName, String pArrayDescriptorName,
			ArrayList<Parameter> pParameterList) throws SQLException, ParseException  {
		ArrayList nonQueries = (ArrayList) factory.getBean("storedProcedures");
		ArrayList<CLOB> clobArray = new ArrayList<CLOB>();
		StoredProcedure procedureConfig = null;
		for(Object nonQuery : nonQueries) {
			StoredProcedure procedure = (StoredProcedure)nonQuery;
			if (procedure.getName().equalsIgnoreCase(pProcedureName)) {
				procedureConfig = procedure;
				break;
			}
		}
		int arraySize = 0;
		
		Connection connection = this.getDataSource().getConnection();

		String stmnt = buildCallStatement(procedureConfig.getProcedure(), pParameterList);
		CallableStatement statement = null;
		try {
			statement = connection.prepareCall(stmnt);
			for (int i = 1; i <= pParameterList.size(); ++i) {
				Parameter parameter = (Parameter)pParameterList.get(i-1);
				if (parameter.getDirection() == Parameter.DIRECTION_OUT || parameter.getDirection() == Parameter.DIRECTION_IN_OUT) {
					statement.registerOutParameter(i, parameter.getType());
				}
				if (parameter.getDirection() == Parameter.DIRECTION_IN || parameter.getDirection() == Parameter.DIRECTION_IN_OUT) {

					switch (parameter.getType()) {
						case Types.VARCHAR : 
							statement.setString(i, (String)parameter.getValue());
							break;
						case Types.INTEGER : 
							statement.setInt(i, (Integer)parameter.getValue());
							break;
						case Types.BIGINT : 
							statement.setLong(i, (Long)parameter.getValue());
							break;
						case Types.DATE : 
							statement.setDate(i, (Date)parameter.getValue());
							break;
						case Types.BLOB : 
							statement.setBytes(i, (byte[])parameter.getValue());
							break;
						case Types.TIMESTAMP :
							statement.setTimestamp(i, (Timestamp) parameter.getValue());
							break;
						case Types.CLOB : 
							char [] chars = (char [])parameter.getValue();
							String value = new String(chars);
							statement.setString(i, value);
							break;				
						case Types.ARRAY :
							ArrayList<DatabaseObject> parameterArray = (ArrayList<DatabaseObject>)parameter.getValue();
							ArrayWithClobs arrayWithClobs = getArray(connection, pObjectDescriptorName, pArrayDescriptorName, parameterArray);
							clobArray.addAll(arrayWithClobs.getClobArray());
							arraySize = parameterArray.size();
							statement.setArray(i, arrayWithClobs.getArray());
							
							break;
					}
				}
			}
			boolean success = statement.execute();


		} 
		finally{
			for (CLOB clob : clobArray) {
				try { if (clob.isTemporary()) clob.freeTemporary(); } catch (Exception e) {}
				try { clob.free(); } catch (Exception e) {}
			}
			if (statement != null)
				try { statement.close(); } catch (SQLException e){};
			if (connection != null)
				try{ connection.close(); } catch (SQLException e){};
		}


	}
	private StructWithClobs getSTRUCT(Connection connection, String objectDescriptorName, DatabaseObject databaseObject)  throws SQLException {
		
		StructWithClobs structWithClobs = new StructWithClobs();
		OracleConnection oracleConnection = connection.unwrap(OracleConnection.class);

		Object [] objects = databaseObject.toObjects(); 
		for (int j = 0; j < objects.length; ++j) {
			Object object = objects[j];
			if (object instanceof char []) {
				CLOB clob = CLOB.createTemporary(oracleConnection, true, CLOB.DURATION_SESSION);
				clob.putChars(1, (char[]) object);
				objects[j] = clob;
				structWithClobs.getClobArray().add(clob);
			}
		}
		StructDescriptor structDescriptor = StructDescriptor.createDescriptor(objectDescriptorName, oracleConnection);
		STRUCT struct = new STRUCT(structDescriptor, oracleConnection, objects);
		structWithClobs.setStruct(struct);
		return structWithClobs;

	}
	private ArrayWithClobs getArray(Connection connection, String objectDescriptorName, String arrayDescriptorName, ArrayList<DatabaseObject> arrayList) throws SQLException, ParseException {
		
		ArrayWithClobs arrayWithClobs = new ArrayWithClobs();
		OracleConnection oracleConnection = connection.unwrap(OracleConnection.class);
		
		int numberOfRows = arrayList.size();
		STRUCT[] structs = new STRUCT[numberOfRows];
		for (int index = 0; index < numberOfRows; index++)
		{
			DatabaseObject objectArray = arrayList.get(index);
			StructWithClobs structWithClobs = getSTRUCT(connection, objectDescriptorName, objectArray);
			structs[index] = structWithClobs.getStruct();
			arrayWithClobs.getClobArray().addAll(structWithClobs.getClobArray());
		}
		ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor(arrayDescriptorName, oracleConnection);
		ARRAY array = new ARRAY(descriptor, oracleConnection, structs);
		arrayWithClobs.setArray(array);
		return arrayWithClobs;
	}
	private DatabaseObject getDatabaseObject(Struct object, Class clazz) throws SQLException, IOException, InstantiationException, IllegalAccessException {
		if (object == null)
			return null;
		InputStream in = null;
		StringWriter w = null;
        Object [] objectArray = new Object[object.getAttributes().length];
        int idx = 0;
        for(Object attribute : object.getAttributes()) {
        	if (attribute instanceof CLOB) {
        		CLOB clob = (CLOB)attribute;
				in = clob.getAsciiStream();
				w = new StringWriter();
				IOUtils.copy(in, w);
				String stringValue = w.toString();
				objectArray[idx] = stringValue;
				try { if (clob.isTemporary()) clob.freeTemporary(); } catch (Exception e) {}
				try { clob.free(); } catch (Exception e) {}
        	}
        	else
        		objectArray[idx] = attribute;
            ++idx;
            
        }
		DatabaseObject databaseObject = (DatabaseObject) clazz.newInstance();
		databaseObject.init(objectArray);
        return databaseObject;
		
	}
	private ArrayList<DatabaseObject> getObjectArrayArrayList(Object[] data, Class clazz) throws SQLException, IOException, InstantiationException, IllegalAccessException {
		ArrayList<DatabaseObject> outputArray = new ArrayList<DatabaseObject>();
        for(Object object : data) {
        	DatabaseObject databaseObject = getDatabaseObject((Struct) object, clazz);
            outputArray.add(databaseObject);
        }
		return outputArray;
	}
	/**
	 * Constructs a call statement string from the list of parameters
	 * @param pProcedureName Stored procedure name
	 * @param pParameterList List of Parameter values
	 * @return
	 */
	protected String buildCallStatement(String pProcedureName,
			ArrayList<Parameter> parameterList) {
		StringBuilder stmt = new StringBuilder();
		stmt.append(String.format("{Call %s(",pProcedureName));
		for(int i = 0; i < parameterList.size(); ++i)
		{
			if (i == 0)
				stmt.append("?");
			else
				stmt.append(", ?");
		}
		stmt.append(")}");
		return stmt.toString();
	}
	private synchronized BeanFactory getbeanFactory(String configFileName) {
		BeanFactory beanFactory = factoryMap.get(configFileName);
		if (beanFactory == null) {
			beanFactory = SpringHelper.getBeanFactory(configFileName);
			factoryMap.put(configFileName, beanFactory);
		}
		return beanFactory;
	}
	
	
	public DataTable runDirectQuery(String query) throws Exception {
		DataTable table = new DataTable();
		ArrayList<DataRow<String, Object>> rows = new ArrayList<DataRow<String, Object>>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		InputStream in = null;
		StringWriter w = null;
		try {
			connection = this.getDataSource().getConnection();
			preparedStatement = connection.prepareStatement(query);
		
			rs = preparedStatement.executeQuery();
			while(rs.next()){
				ResultSetMetaData rsmd = rs.getMetaData();
				DataRow<String, Object> row = new DataRow<String, Object>();
				for (int i = 1;i <= rsmd.getColumnCount(); ++i) {
					if (rs.getObject(i) instanceof oracle.sql.TIMESTAMPTZ)
						row.put(rsmd.getColumnName(i),  ((oracle.sql.TIMESTAMPTZ)rs.getObject(i)).dateValue(connection.unwrap(OracleConnection.class)));
					else if (rs.getObject(i) instanceof oracle.sql.CLOB) {
		        		CLOB clob = (CLOB)rs.getObject(i);
						in = clob.getAsciiStream();
						w = new StringWriter();
						IOUtils.copy(in, w);
						String stringValue = w.toString();
						row.put(rsmd.getColumnName(i), stringValue);
						try { if (clob.isTemporary()) clob.freeTemporary(); } catch (Exception e) {}
						try { clob.free(); } catch (Exception e) {}
					}
					else if (rs.getObject(i) instanceof oracle.sql.BLOB) {
						BLOB blob = (BLOB)rs.getObject(i);
						int blobLength = (int) blob.length();  
						byte[] blobAsBytes = blob.getBytes(1, blobLength);
						row.put(rsmd.getColumnName(i), blobAsBytes);
						try { if (blob.isTemporary()) blob.freeTemporary(); } catch (Exception e) {}
						try { blob.free(); } catch (Exception e) {}
					}
					else	
						row.put(rsmd.getColumnName(i),  rs.getObject(i)); 
				}
				rows.add(row);
			}
		} finally {
			if (rs != null)
				try { rs.close(); } catch (SQLException e){};
			if (preparedStatement != null)
				try { preparedStatement.close(); } catch (SQLException e){};
			if (connection != null)
				try{ connection.close(); } catch (SQLException e){};
			if (in != null)
				try {in.close();} catch(Exception e) {}
			if (w != null)
				try {w.close();} catch(Exception e) {}
		}
		table.setRows(rows);
		return table;
		
	}
}
