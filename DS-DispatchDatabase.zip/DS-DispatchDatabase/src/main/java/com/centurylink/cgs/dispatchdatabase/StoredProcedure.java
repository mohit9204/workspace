package com.centurylink.cgs.dispatchdatabase;

public class StoredProcedure {

	private String name;
	private String procedure;
	
	
	public StoredProcedure() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProcedure() {
		return procedure;
	}

	public void setProcedure(String procedure) {
		this.procedure = procedure;
	}

}
