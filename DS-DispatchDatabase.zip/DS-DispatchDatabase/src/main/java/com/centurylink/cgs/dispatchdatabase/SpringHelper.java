package com.centurylink.cgs.dispatchdatabase;

import java.net.MalformedURLException;
import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
/***
 * Helper class for working with spring beans resources 
 * @author wmiddle
 *
 */
public class SpringHelper {

	private static final Logger logger = Logger.getLogger(SpringHelper.class);
	/***
	 * Helper method to create a BeanFactory object from a resource
	 * 	Will first attempt to load the resource path from a URL.
	 *  if the URL load fails, tries to load from the classpath. 
	 * @param pResource A URL, file name or path to a file
	 * @return BeanFactory if successful, otherwise null
	 */
	public static BeanFactory getBeanFactory(String pResource) {
		BeanFactory factory = null;
		try {
			Resource res = new UrlResource(pResource);
			GenericApplicationContext appContext = new GenericApplicationContext();
			XmlBeanDefinitionReader xbdr = new XmlBeanDefinitionReader(
					appContext);
			xbdr.setValidating(false);
			xbdr.loadBeanDefinitions(res);
			appContext.refresh();
			factory = appContext;
		} catch (MalformedURLException e) {
			logger.trace(e);
		}
		if (factory == null) { 
			try {
				@SuppressWarnings("resource")
				ApplicationContext context = new FileSystemXmlApplicationContext(pResource);
				factory = context;
			} catch(BeansException e) {
				logger.trace(e);
			}
		}
		if (factory == null) {
			@SuppressWarnings("resource")
			ApplicationContext context = new ClassPathXmlApplicationContext(
					pResource);
			factory = context;
		}
		((ConfigurableApplicationContext)factory).registerShutdownHook();
		return factory;

	}

}
