package com.centurylink.cgs.dispatchdatabase;

import java.io.InputStream;
import java.io.StringWriter;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.apache.commons.io.IOUtils;
import org.springframework.jdbc.core.RowMapper;

import oracle.sql.TIMESTAMPTZ;
import oracle.jdbc.OracleConnection;

public class DataRowMapper implements RowMapper<DataRow> {

	@Override
	public DataRow mapRow(ResultSet rs, int rowNum) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		DataRow<String, Object> row = new DataRow<String, Object>();
		for (int i = 1;i <= rsmd.getColumnCount(); ++i) {
			Object object = rs.getObject(i);
			if (object instanceof TIMESTAMPTZ)
				row.put(rsmd.getColumnName(i),  ((TIMESTAMPTZ)rs.getObject(i)).dateValue(rs.getStatement().getConnection().unwrap(OracleConnection.class)));
			else if (object instanceof Clob) {
				String stringValue = getString((Clob)object);
				row.put(rsmd.getColumnName(i), stringValue);
			}
			else if (rs.getObject(i) instanceof Blob) {
				Blob blob = (Blob)rs.getObject(i);
				int blobLength = (int) blob.length();  
				byte[] blobAsBytes = blob.getBytes(1, blobLength);
				row.put(rsmd.getColumnName(i), blobAsBytes);
				try { blob.free(); } catch (Exception e) {}
			}
			else	
				row.put(rsmd.getColumnName(i),  rs.getObject(i)); 
		}
		return row;

	}
	private String getString(Clob clob) throws SQLException {
		InputStream in = null;
		StringWriter w = null;
		try {
			in = clob.getAsciiStream();
			w = new StringWriter();
			IOUtils.copy(in, w);
			return  w.toString();
		} catch (Exception e) {
			return null;
		} finally {
			try {in.close();;} catch (Exception e) {e.printStackTrace();}
			try {w.close();} catch (Exception e) {e.printStackTrace();}
			//try {if(clob.isTemporary()) clob.freeTemporary();} catch (Exception e) {e.printStackTrace();}
			try {clob.free();} catch (Exception e) {e.printStackTrace();}
		}
	}

}
