package com.centurylink.cgs.dispatchdatabase;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

public class Parameter {

	public static final String DIRECTION_IN = "In";
	public static final String DIRECTION_OUT = "Out";
	public static final String DIRECTION_IN_OUT = "InOut";

	
	private String name;
	private int type;
	private String direction = DIRECTION_IN;
	private Object value;
	private String objectDescriptorName;
	private String arrayDescriptorName;
	private Class clazz;
	private Class arrayClazz;

	public String getName() {
		return name;
	}


	public Parameter setName(String name) {
		this.name = name;
		return this;
	}


	public int getType() {
		return type;
	}

	/**
	 * Sets the data type for the parameter
	 * @param type - Type as defined in java.sql.Types
	 * @return
	 */
	public Parameter setType(int type) {
		this.type = type;
		return this;
	}
	public String getDirection() {
		return direction;
	}


	public Parameter setDirection(String direction) {
		this.direction = direction;
		return this;
	}


	public Object getValue() {
		return value;
	}

	public Parameter setValue(long value) {
		this.value = value;
		this.type = Types.BIGINT;
		return this;
	}
	public Parameter setValue(int value) {
		this.value = value;
		this.type = Types.INTEGER;
		return this;
	}
	public Parameter setValue(String value) {
		this.value = value;
		this.type = Types.VARCHAR;
		return this;
	}
	public Parameter setValue(char [] value) {
		this.value = value;
		this.type = Types.CLOB;
		return this;
	}
	public Parameter setValue(byte [] value) {
		this.value = value;
		this.type = Types.BLOB;
		return this;
	}
	public Parameter setValue(Date value) {
		this.value = new java.sql.Date(((Date)value).getTime());
		this.type = Types.DATE;
		return this;
	}
	public Parameter setValue(java.sql.Date value) {
		this.value = value;
		this.type = Types.DATE;
		return this;
	}
	public Parameter setValue(java.sql.Timestamp value) {
		this.value = value;
		this.type = Types.TIMESTAMP;
		return this;
	}

	public Parameter setValue(DatabaseObjectArray value) {
		this.value = value;
		this.type = Types.ARRAY;
		this.clazz = value.getObjectClass();
		this.arrayClazz = value.getClass();
		this.arrayDescriptorName = value.getArrayDescriptorName();
		this.objectDescriptorName = value.getObjectDescriptorName();
		return this;
	}
	public Parameter setValue(DatabaseObject value) {
		this.value = value;
		this.type = Types.STRUCT;
		if (value != null) {
			this.clazz = value.getClass();
			this.objectDescriptorName = value.getObjectDescriptorName();
		}
		return this;
	}
	public Parameter setValue(Object value) {
		this.value = value;
		return this;
	}
	public String getObjectDescriptorName() {
		return objectDescriptorName;
	}


	public Parameter setObjectDescriptorName(String objectDescriptorName) {
		this.objectDescriptorName = objectDescriptorName;
		return this;
	}


	public String getArrayDescriptorName() {
		return arrayDescriptorName;
	}


	public Parameter setArrayDescriptorName(String arrayDescriptorName) {
		this.arrayDescriptorName = arrayDescriptorName;
		return this;
	}


	public Class getClazz() {
		return clazz;
	}


	public Parameter setClazz(Class clazz) {
		this.clazz = clazz;
		return this;
	}


	public Class getArrayClazz() {
		return arrayClazz;
	}


	public void setArrayClazz(Class arrayClazz) {
		this.arrayClazz = arrayClazz;
	}


	public Parameter() {
	
	}

}
