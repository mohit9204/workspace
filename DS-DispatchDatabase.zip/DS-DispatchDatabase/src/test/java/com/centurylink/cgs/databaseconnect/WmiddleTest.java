package com.centurylink.cgs.databaseconnect;

import java.math.BigDecimal;

import com.centurylink.cgs.dispatchdatabase.DatabaseObject;

public class WmiddleTest implements DatabaseObject {
	private int correlationId;
	private String jobStatus;

	public WmiddleTest() {
		
	}
	public int getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(int correlationId) {
		this.correlationId = correlationId;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public WmiddleTest(int correlationId, String jobStatus) {
		this.correlationId = correlationId;
		this.jobStatus = jobStatus;
	}
	public Object[] toObjects() {
		Object [] objects = new Object[2];
		objects[0] = correlationId;
		objects[1] = jobStatus.toCharArray();
		return objects;
	}

	public void init(Object[] objects) {
		correlationId = Integer.parseInt(((BigDecimal) objects[0]).toString());
		jobStatus = objects[1].toString();
	}
	public String getObjectDescriptorName() {
		return "WMIDDLE_TYPE";
	}

}
