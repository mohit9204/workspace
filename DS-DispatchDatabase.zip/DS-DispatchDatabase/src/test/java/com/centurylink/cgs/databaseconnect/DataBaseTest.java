package com.centurylink.cgs.databaseconnect;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;

import org.junit.Test;

import com.centurylink.cgs.dispatchdatabase.Database;
import com.centurylink.cgs.dispatchdatabase.DatabaseObject;
import com.centurylink.cgs.dispatchdatabase.Parameter;

public class DataBaseTest {

	public DataBaseTest() {

	}
	@Test
	public void testRunQuery() throws Exception {
		Database db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		ArrayList<Parameter> parameters = new ArrayList<Parameter>();
		parameters.add(new Parameter().setValue("JOBS"));
		parameters.add(new Parameter().setValue(5));
		System.out.println(db.runQuery("query", parameters));
		db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		System.out.println(db.runQuery("query2"));
		db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		parameters.clear();
		parameters.add(new Parameter().setValue(new java.sql.Date(new java.util.Date().getTime())));
		System.out.println(db.runQuery("query3", parameters));
		
		parameters.clear();
		parameters.add(new Parameter().setValue(new java.util.Date()));
		System.out.println(db.runQuery("query3", parameters));
		System.out.println(db.runQuery("wmiddle_test"));
	}
	@Test
	public void testRunNonQuery() throws Exception {
		Database db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		ArrayList<Parameter> parameters = new ArrayList<Parameter>();
		parameters.add(new Parameter().setValue(3));
		parameters.add(new Parameter().setValue("COMPLETE"));
		parameters.add(new Parameter().setValue(new Timestamp(System.currentTimeMillis())));
		db.runNonQuery("insert", parameters);
	}
	@Test
	public void testRunStoredProcedure() throws Exception {
		Database db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		ArrayList<Parameter> parameters = new ArrayList<Parameter>();
		parameters.add(new Parameter().setValue("Test1"));
		Parameter outputParameter = new Parameter().setDirection(Parameter.DIRECTION_OUT).setName("OUTPUT_VALUE").setType(Types.VARCHAR).setClazz(WmiddleTest.class);
		parameters.add(outputParameter);
		System.out.println(db.runStoredProcedure("test", parameters));
		System.out.println(String.format("Ouput Parameter Value: %s\n", outputParameter.getValue()));
		
		parameters.clear();
		parameters.add(new Parameter().setValue((String)null));
		parameters.add(new Parameter().setDirection(Parameter.DIRECTION_OUT).setName("OUTPUT_VALUE").setType(Types.VARCHAR));
		System.out.println(db.runStoredProcedure("test", parameters));
	}
	@Test
	public void testRunStoredProcedureWithObjectInput() throws Exception {
		Database db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		WmiddleTest test = new WmiddleTest(12345678,"Object 1");
		ArrayList<Parameter> parameters = new ArrayList<Parameter>();
		parameters.add(new Parameter().setValue(test));
		// Create the output parameter with an instance of the class type that will be returned in this parameter
		// This will set the associated values for type, data object descriptor, and class name
		Parameter out = new Parameter().setDirection(Parameter.DIRECTION_OUT).setValue(new WmiddleTest());
		parameters.add(out);
		db.runStoredProcedure("WMIDDLE_INSERT",parameters);
		WmiddleTest outValue = (WmiddleTest) out.getValue();
		System.out.println(outValue.getCorrelationId());
		System.out.println(outValue.getJobStatus());
				
	}
	@Test
	public void testRunStoredProcedureWithArrayInput() throws Exception {
		Database db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		WmiddleTestArray array = new WmiddleTestArray();
		array.add(new WmiddleTest(12345678,"Object 1"));
		array.add(new WmiddleTest(12345679,"Object 2"));
		ArrayList<Parameter> parameters = new ArrayList<Parameter>();
		parameters.add(new Parameter().setValue(array));
		// Create the output parameter with an instance of the class type that will be returned in this parameter
		// This will set the associated values for type, array descriptor, data object descriptor, and class name
		Parameter out = new Parameter().setDirection(Parameter.DIRECTION_OUT).setValue(new WmiddleTestArray());
		parameters.add(out);
		db.runStoredProcedure("WMIDDLE_INSERT_TABLE", parameters);
		WmiddleTestArray output = (WmiddleTestArray)out.getValue();
		for (DatabaseObject outValue : output) {
			WmiddleTest value = (WmiddleTest)outValue;
			System.out.println("\nRecord\n------");
			System.out.println(value.getCorrelationId());
			System.out.println(value.getJobStatus());
		}
	}
	@Test
	public void testRunHealthCheck() throws Exception {
		Database db = new Database("DatabaseConfigurationTest.xml", "jobsDataSource");
		db.runHealthCheck();
	}	
}
