package com.centurylink.cgs.databaseconnect;

import java.util.ArrayList;

import com.centurylink.cgs.dispatchdatabase.DatabaseObject;
import com.centurylink.cgs.dispatchdatabase.DatabaseObjectArray;

public class WmiddleTestArray extends ArrayList<DatabaseObject> implements DatabaseObjectArray {

	private static final long serialVersionUID = 1L;

	public String getArrayDescriptorName() {
		return "WMIDDLE_TYPE_TABLE";
	}
	public String getObjectDescriptorName() {
		return "WMIDDLE_TYPE";
	}

	public Class getObjectClass() {
		return WmiddleTest.class;
	}


}
