package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;

public interface SynchronizeErrorService {
	public void process() throws ClickSynchronizationException;
}
