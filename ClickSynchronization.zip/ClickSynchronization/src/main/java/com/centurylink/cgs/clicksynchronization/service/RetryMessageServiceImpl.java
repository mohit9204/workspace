package com.centurylink.cgs.clicksynchronization.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;

public class RetryMessageServiceImpl implements RetryMessageService {

	@Autowired
	JobsDao jobsDao;
	
	@Override
	public String retry(String correlationId) throws ClickSynchronizationException {
		List<Integer> list = jobsDao.getRetryMessages(correlationId);
		if (list.size() > 0) {
			jobsDao.retryMessage(correlationId);
			jobsDao.completeFailedError(correlationId);
			return String.format("Message set to retry for correlationId %s",correlationId);
		}
		else
			return String.format("No messages to retry for correlationId %s",correlationId);
	}

}
