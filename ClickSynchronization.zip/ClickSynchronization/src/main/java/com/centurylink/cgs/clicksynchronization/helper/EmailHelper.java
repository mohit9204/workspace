package com.centurylink.cgs.clicksynchronization.helper;

import java.util.HashMap;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Mailer;

public class EmailHelper {

	private static EmailHelper instance = new EmailHelper();

	private EmailHelper() {
	}

	public static EmailHelper getInstance() {
		return instance;
	}

	public void sendEmail(FailedMessage failure, HashMap<String, String> options) throws ClickSynchronizationException {
		Configuration config = Configuration.getInstance();
		Mailer mailer = Mailer.getInstance();
		String messageBodyTemplate = "The correlationId %s failed with the message \n\n\"%s\".  \n\nPlease resolve the issue in Click and retry using the link \n\n%s/%s";
		String subject = options.get("subject");
		String mailTo = options.get("mailTo");
		String mailFrom = options.get("mailFrom");
		String messageBody = String.format(messageBodyTemplate, failure.getCorrelationId(), failure.getErrorMessage(),
				config.getRetryEndpoint(), failure.getCorrelationId());
		String attachmentName = "Message.xml";
		String attachmentContent = failure.getMessage();
		mailer.send(subject, mailTo, mailFrom, messageBody, attachmentName, attachmentContent);
	}
}
