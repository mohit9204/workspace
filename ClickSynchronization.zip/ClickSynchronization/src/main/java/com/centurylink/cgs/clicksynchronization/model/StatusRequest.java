package com.centurylink.cgs.clicksynchronization.model;

public class StatusRequest {
	
	private String messageSource;
	private String taskStatus;
	private String message;
	private String jobsTaskStatus;
	private int correlationId;
	private String techId;
	private boolean inSync;
	
	public String getMessageSource() {
		return messageSource;
	}
	public void setMessageSource(String messageSource) {
		this.messageSource = messageSource;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getJobsTaskStatus() {
		return jobsTaskStatus;
	}
	public void setJobsTaskStatus(String jobsTaskStatus) {
		this.jobsTaskStatus = jobsTaskStatus;
	}
	public int getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(int correlationId) {
		this.correlationId = correlationId;
	}
	public String getTechId() {
		return techId;
	}
	public void setTechId(String techId) {
		this.techId = techId;
	}
	public boolean isInSync() {
		return inSync;
	}
	public void setInSync(boolean inSync) {
		this.inSync = inSync;
	}
}
