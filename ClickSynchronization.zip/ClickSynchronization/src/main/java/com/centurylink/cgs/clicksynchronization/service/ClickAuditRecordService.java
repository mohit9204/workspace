package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityDynamicAudit;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityLimitAuditRecord;

public interface ClickAuditRecordService {
	public void processCTLCapacityLimitAuditRecord(CTLCapacityLimitAuditRecord clickAuditRecord) throws ClickSynchronizationException;
	public void processCTLCapacityDynamicAudit(CTLCapacityDynamicAudit clickAuditRecord) throws ClickSynchronizationException;
	
}
