package com.centurylink.cgs.clicksynchronization.util;

import java.net.URL;
import java.net.URLClassLoader;

import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import net.openhft.compiler.CompilerUtils;

public class DynamicClass {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(DynamicClass.class);

	
	static {
		ClassLoader c = Thread.currentThread().getContextClassLoader();
		URLClassLoader u=(URLClassLoader)c;
		URL[] urls=u.getURLs();
		for (URL url : urls) {
			//System.out.println(url.toString());
			if (url.toString().startsWith("file:"))
				CompilerUtils.addClassPath(url.toString().replace("file:", ""));
			else
				CompilerUtils.addClassPath(url.toString());
		}
}
	
		
	public static Object getInstance(String className, String source) throws ClassNotFoundException, InstantiationException, IllegalAccessException {

		 Class aClass = CompilerUtils.CACHED_COMPILER.loadFromJava(Thread.currentThread().getContextClassLoader(), className, source);
		 Object object =  aClass.newInstance();

		 return object;
	}

}
