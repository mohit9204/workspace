package com.centurylink.cgs.clicksynchronization.client;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptorAdapter;
import org.springframework.ws.context.MessageContext;

import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;

public class ClickInterceptor extends ClientInterceptorAdapter {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ClickInterceptor.class);

	@Override
	public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {			
		return true;
	}

	@Override
	public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
		return true;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {
		try {
			ByteArrayOutputStream requestStream = new ByteArrayOutputStream();
			ByteArrayOutputStream responseStream = new ByteArrayOutputStream();
			messageContext.getRequest().writeTo(requestStream);
			LOG.debug("Request to click: "+requestStream.toString());

			messageContext.getResponse().writeTo(responseStream);
			LOG.debug("Response from click: "+responseStream.toString());
			requestStream.close();
			responseStream.close();
		} catch (IOException ignored) {
		}
	}

}
