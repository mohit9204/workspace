package com.centurylink.cgs.clicksynchronization.model;

public class StatusEvaluatorMapping {
	private String messageSource;
	private String taskStatus;
	private String evaluatorClass;
	
	public StatusEvaluatorMapping() {
		
	}

	public StatusEvaluatorMapping(String messageSource, String taskStatus, String evaluatorClass) {
		this.messageSource = messageSource;
		this.taskStatus = taskStatus;
		this.evaluatorClass = evaluatorClass;
	}

	public String getMessageSource() {
		return messageSource;
	}

	public void setMessageSource(String messageSource) {
		this.messageSource = messageSource;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getEvaluatorClass() {
		return evaluatorClass;
	}

	public void setEvaluatorClass(String evaluatorClass) {
		this.evaluatorClass = evaluatorClass;
	}

}
