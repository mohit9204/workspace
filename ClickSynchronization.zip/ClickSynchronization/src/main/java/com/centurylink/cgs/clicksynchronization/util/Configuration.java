package com.centurylink.cgs.clicksynchronization.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.dao.JobsDaoImpl;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.StatusEvaluatorMapping;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerMapping;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.reference.DispatchReference;


public class Configuration {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(Configuration.class);
	
	private static Object synchronizerMappingMutex = new Object();
	private static List<SynchronizerMapping> synchronizerMapping = new ArrayList<SynchronizerMapping>();
	private static HashMap<String, HashMap<String, String>> statusEvaluatorClassMap = new HashMap<String, HashMap<String, String>>();
	private static Object statusEvaluatorClassMapMutex = new Object();
	
	private static int secondsToPause = 0;
	
	private static HashMap<String, String> loadedTables = new HashMap<String, String>();
	
	private static Configuration instance = new Configuration();
	private Configuration() {
	}
	public static Configuration getInstance() {
		return instance;
	}
	
	@Value("${com.centurylink.cgs.clicksynchronization.retryendpoint}")
	private String retryEndpoint;
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected  DataSource dataSource; 
	

	JobsDao jobsDao = JobsDaoImpl.getInstance();
	
	private static DispatchReference ref = new DispatchReference();
	
	public String getRetryEndpoint() {
		return retryEndpoint;
	}
	public int getNumberOfStatusPublishThreads() throws ClickSynchronizationException {
		try {
			return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "numberOfStatusPublishThreads"));
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), 
						e, 
						AlarmId.CONFIGURATION_GET_NUMBER_OF_STATUS_PUBLISH_THREADS, 
						new LogContext().setMessage("isRunScheduledTasks"));
		}
	}
	public int getNumberOfUpdateTaskAssignmentExThreads() throws ClickSynchronizationException {
		try {
			return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "numberOfUpdateTaskAssignmentExThreads"));
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), 
						e, 
						AlarmId.CONFIGURATION_GET_NUMBER_OF_UPDATE_TASK_ASSIGNMENT_EX_THREADS, 
						new LogContext().setMessage("isRunScheduledTasks"));
		}
	}
	public int getNumberOfProcessTaskExThreads() throws ClickSynchronizationException {
		try {
			return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "numberOfProcessTaskExThreads"));
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), 
						e, 
						AlarmId.CONFIGURATION_GET_NUMBER_OF_PROCESS_TASK_EX_THREADS, 
						new LogContext().setMessage("isRunScheduledTasks"));
		}
	}
	public int getStatusPublishRowLimit() throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "statusPublishRowLimit"));
	}
	public int getClickMessageRowLimit() throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickMessageRowLimit"));
	}
	public int getFailedRowLimit() throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "failedRowLimit"));
	}

	public String getDispatchGroupEndpoint() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "dispatchGroupEndpoint");
	}
	public String getClickScheduleServiceEndpoint() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickScheduleServiceEndpoint");
	}
	public String getScheduledSynchronizerClass() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "scheduledSynchronizerClass");
	}
	public String getClickHealthScheme() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickHealthScheme");
	}
	public String getClickHealthHost() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickHealthHost");
	}
	public String getClickHealthPath() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickHealthPath");
	}
	public int getClickConnectionTimeout()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickConnectionTimeout"));
	}
	public int getClickReadTimeout()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickReadTimeout"));
	}
	public int getMaxConnections()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "maxConnections"));
	}
	public int getMaxConnectionsPerHost()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "maxConnectionsPerHost"));
	}
	public int getUpstreamStatusPublishDelayMilliseconds()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "upstreamStatusPublishDelayMilliseconds"));
	}
	public String getClickUserName() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickUserName");
	}
	public String getClickEncryptedPassword() throws Exception {
		return ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "clickEncryptedPassword");
	}
	public int getMaxRetryTimeoutDelaySeconds() throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "maxRetryTimeoutDelaySeconds"));
	}
	public boolean isUpstreamFailure(String message) throws Exception {
		HashMap<String, String> messages = ref.getReferenceMap(dataSource, Constants.CLICK_SYNCH_UPSTREAM_FAIL);
		for (String key : messages.keySet()) {
			if (message.contains(key)) {
				String value = messages.get(key);
				if (value != null && value.equalsIgnoreCase(Constants.TRUE))
					return true;
				else
					return false;				
			}
		}
		return false;
	}
	public boolean isRunScheduledTasks() throws ClickSynchronizationException {
		try {
		String runScheduledTasks = ref.get(dataSource, Constants.CLICK_SYNCHRONIZATION_OPTIONS, "runScheduledTasks");
		if (runScheduledTasks != null && runScheduledTasks.equalsIgnoreCase(Constants.TRUE))
			return true;
		else
			return false;
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), 
						e, 
						AlarmId.CONFIGURATION_IS_RUN_SCHEDULED_TASKS, 
						new LogContext().setMessage("isRunScheduledTasks"));
		}
	}
	public static void refresh() 
	{
	    LOG.info("Refreshing configuration settings");
	    ref.refreshTable(Constants.CLICK_SYNCHRONIZATION_OPTIONS);
	    ref.refreshTable(Constants.CLICK_SYNCH_UPSTREAM_FAIL);
	    synchronized (synchronizerMappingMutex) {
	    	synchronizerMapping.clear();
	    }
	    synchronized (statusEvaluatorClassMapMutex) {
	    	statusEvaluatorClassMap.clear();	
	    }
	    for(String tableName : loadedTables.keySet()) {
	    	ref.refreshTable(tableName);
	    }
	}
	public int getIncrementSecondsToPause() throws ClickSynchronizationException {
		try {
			int max = getMaxRetryTimeoutDelaySeconds();
			if (secondsToPause < max)
				return secondsToPause++;
			else
				return secondsToPause;
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), 
						e, 
						AlarmId.CONFIGURATION_GET_INCREMENT_SECONDS_TO_PAUSE, 
						new LogContext().setMessage("setSecondsToPause"));
		}
		
	}
	public void setSecondsToPause(int seconds) throws ClickSynchronizationException {
		try {
			int max = getMaxRetryTimeoutDelaySeconds();
			if (secondsToPause <= max)
				secondsToPause = seconds;
			else
				secondsToPause = max;
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), 
						e, 
						AlarmId.CONFIGURATION_SET_SECONDS_TO_PAUSE, 
						new LogContext().setMessage("setSecondsToPause"));
		}
	}
	public List<SynchronizerMapping> getSynchronizerMapping() throws ClickSynchronizationException {
		synchronized (synchronizerMappingMutex) {
			if (synchronizerMapping.size() == 0) {
				LOG.info("Loading CLICK_SYNC_ERROR_MAPPING_REF table");
				synchronizerMapping = jobsDao.getSynchronizerMapping();
			}
		}
		return synchronizerMapping;
	}
	public String getUpstreamStatusEvaluatorClass(String source, String taskStatus) throws ClickSynchronizationException {
		synchronized (statusEvaluatorClassMapMutex) {
			if (statusEvaluatorClassMap.get(source) != null && statusEvaluatorClassMap.get(source).get(taskStatus) != null) {
				return statusEvaluatorClassMap.get(source).get(taskStatus);
			}
			for (StatusEvaluatorMapping mapping : jobsDao.getStatusEvaluatorMapping()) {
				HashMap<String, String> sourceMap = statusEvaluatorClassMap.get(mapping.getMessageSource());
				if (sourceMap == null) {
					sourceMap = new HashMap<String, String>();
					statusEvaluatorClassMap.put(mapping.getMessageSource(), sourceMap);
				}
				sourceMap.put(mapping.getTaskStatus(), mapping.getEvaluatorClass());
			}
			if (statusEvaluatorClassMap.get(source) != null)
				return statusEvaluatorClassMap.get(source).get(taskStatus);
			else
				return null;
		}
	}
	public HashMap<String, String> getDispatchRefTable(String tableName) {
		try {
			if (!loadedTables.containsKey(tableName))
				loadedTables.put(tableName, tableName);
			return ref.getReferenceMap(dataSource, tableName);
		} catch(Exception e) {
			LOG.error(new ClickSynchronizationException(e.getMessage(), 
					e, 
					AlarmId.CONFIGURATION_GET_DISPATCH_REF_TABLE, 
					new LogContext().add("tableName",tableName)));
			return null;
		}
	}
	public DataSource getDataSource() {
		return dataSource;
	}
}
