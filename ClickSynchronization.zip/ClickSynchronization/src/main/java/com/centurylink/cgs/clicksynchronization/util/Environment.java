
package com.centurylink.cgs.clicksynchronization.util;

public class Environment {

	public static boolean isRunScheduledTasks() {
		return "YES_PLEASE".equalsIgnoreCase(System.getenv().get("RUN_SCHEDULED_TASKS"));
	}
	public static boolean isNotRunScheduledTasks() {
		return "NO_THANKS".equalsIgnoreCase(System.getenv().get("RUN_SCHEDULED_TASKS"));
	}
}
