package com.centurylink.cgs.clicksynchronization.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.clicksynchronization.model.SynchronizerMapping;

public class SynchronizerMappingRowMapper implements RowMapper<SynchronizerMapping> {
	@Override
	public SynchronizerMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
		SynchronizerMapping result = new SynchronizerMapping();
		result.setErrorMessage(rs.getString("ERROR_MESSAGE_VAL"));
		result.setSynchronizerClass(rs.getString("CLASS_NM"));

		return result;
	}
}