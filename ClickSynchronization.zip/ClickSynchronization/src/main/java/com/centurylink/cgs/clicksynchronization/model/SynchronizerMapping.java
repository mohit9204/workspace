package com.centurylink.cgs.clicksynchronization.model;

public class SynchronizerMapping {
	private String errorMessage;
	private String synchronizerClass;
	
	public SynchronizerMapping() {
		
	}
	public SynchronizerMapping(String errorMessage, String synchronizerClass) {
		super();
		this.errorMessage = errorMessage;
		this.synchronizerClass = synchronizerClass;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getSynchronizerClass() {
		return synchronizerClass;
	}
	public void setSynchronizerClass(String synchronizerClass) {
		this.synchronizerClass = synchronizerClass;
	}

}
