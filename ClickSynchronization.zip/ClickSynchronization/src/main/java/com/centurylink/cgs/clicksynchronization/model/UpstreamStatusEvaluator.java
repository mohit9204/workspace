package com.centurylink.cgs.clicksynchronization.model;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;

public interface UpstreamStatusEvaluator {
	public boolean sendStatus(StatusRequest request) throws ClickSynchronizationException;
}
