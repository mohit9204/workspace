package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.dispatchgroupinterface.AssignmentUpdateResult;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;

public interface AssignmentUpdateService {

	public AssignmentUpdateResult assignmentUpdate(CTLAssignmentUpdate assignment) throws ClickSynchronizationException;
}
