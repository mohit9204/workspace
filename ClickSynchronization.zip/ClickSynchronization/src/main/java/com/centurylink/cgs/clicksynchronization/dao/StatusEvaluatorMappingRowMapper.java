package com.centurylink.cgs.clicksynchronization.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.clicksynchronization.model.StatusEvaluatorMapping;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerMapping;

public class StatusEvaluatorMappingRowMapper implements RowMapper<StatusEvaluatorMapping> {
	@Override
	public StatusEvaluatorMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
		StatusEvaluatorMapping result = new StatusEvaluatorMapping();
		result.setMessageSource(rs.getString("MESSAGE_SOURCE_VAL"));
		result.setTaskStatus(rs.getString("TASK_STATUS"));
		result.setEvaluatorClass(rs.getString("CLASS_NM"));
		return result;
	}

}