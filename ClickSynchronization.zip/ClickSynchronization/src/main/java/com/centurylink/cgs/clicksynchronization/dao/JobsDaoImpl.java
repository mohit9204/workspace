package com.centurylink.cgs.clicksynchronization.dao;

import java.sql.Struct;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jdbc.support.oracle.SqlReturnArray;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.model.StatusEvaluatorMapping;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerMapping;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityDynamicAudit;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityLimitAuditRecord;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;
import oracle.jdbc.internal.OracleTypes;

@Repository
public class JobsDaoImpl extends NamedParameterJdbcDaoSupport implements JobsDao {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(JobsDaoImpl.class);
	
	
	// Implement as a singleton so instances created by Spring are available to the dynamic classes
	private static JobsDaoImpl instance = new JobsDaoImpl();
	protected JobsDaoImpl () {
		
	}
	public static JobsDaoImpl getInstance() {
		return instance;
	}
	
	private SimpleJdbcCall getClickStatusPublishIdsProcedure;
	private SimpleJdbcCall getClickSyncMessageIdsProcedure;
	private SimpleJdbcCall getClickFailedIdsProcedure;
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 
	
	@Autowired
	Configuration configuration;
	
	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
		setGetClickStatusPublishProcedure(new SimpleJdbcCall(dataSource));
		setGetClickSyncMessageIdsProcedure(new SimpleJdbcCall(dataSource));
		setGetClickFailedIdsProcedure(new SimpleJdbcCall(dataSource));
	}
	public void setGetClickStatusPublishProcedure(SimpleJdbcCall getClickStatusPublishIdsProcedure) {
		this.getClickStatusPublishIdsProcedure = getClickStatusPublishIdsProcedure;
		this.getClickStatusPublishIdsProcedure.withCatalogName(Constants.PACKAGE_GET_CLICK_SYNC)
		.withProcedureName(Constants.PROC_GET_STATUS_PUB_IDS)
		.withoutProcedureColumnMetaDataAccess()
		.declareParameters(new SqlParameter(Constants.PARAM_QUERY_LIMIT_IN, OracleTypes.INTEGER),
							new SqlOutParameter(Constants.PARAM_IDS_OUT, OracleTypes.ARRAY, Constants.TABLE_NUMBER_TYPE_TABLE, new SqlReturnArray()));
		this.getClickStatusPublishIdsProcedure.compile();
	}
	public void setGetClickSyncMessageIdsProcedure(SimpleJdbcCall getClickSyncMessageIdsProcedure) {
		this.getClickSyncMessageIdsProcedure = getClickSyncMessageIdsProcedure;
		this.getClickSyncMessageIdsProcedure.withCatalogName(Constants.PACKAGE_GET_CLICK_SYNC)
		.withProcedureName(Constants.PROC_GET_SYNC_MESSAGE_IDS)
		.withoutProcedureColumnMetaDataAccess()
		.declareParameters(new SqlParameter(Constants.PARAM_MESSAGE_TYPE_IN, OracleTypes.VARCHAR),
							new SqlParameter(Constants.PARAM_QUERY_LIMIT_IN, OracleTypes.INTEGER),
							new SqlOutParameter(Constants.PARAM_IDS_OUT, OracleTypes.ARRAY, Constants.TABLE_NUMBER_TYPE_TABLE, new SqlReturnArray()));
		this.getClickSyncMessageIdsProcedure.compile();
	}
	public void setGetClickFailedIdsProcedure(SimpleJdbcCall getClickSyncMessageIdsProcedure) {
		this.getClickFailedIdsProcedure = getClickSyncMessageIdsProcedure;
		this.getClickFailedIdsProcedure.withCatalogName(Constants.PACKAGE_GET_CLICK_SYNC)
		.withProcedureName(Constants.PROC_GET_FAILED_MESSAGE_IDS)
		.withoutProcedureColumnMetaDataAccess()
		.declareParameters(new SqlParameter(Constants.PARAM_QUERY_LIMIT_IN, OracleTypes.INTEGER),
							new SqlOutParameter(Constants.PARAM_IDS_OUT, OracleTypes.ARRAY, Constants.TABLE_NUMBER_TYPE_TABLE, new SqlReturnArray()));
		this.getClickFailedIdsProcedure.compile();
	}
	@Override
	public void insertCTLCapacityLimitAuditRecord(CTLCapacityLimitAuditRecord record)
			throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		if (record.getCTLCapacityLimitAudit() == null) {
			ClickSynchronizationException e = new ClickSynchronizationException("CTLCapacityLimitAudit is null",  AlarmId.JOBS_DAO_IMPL_INSERT_CTLCAPACITY_LIMIT_AUDIT_RECORD_NULL_RECORD,
					logContext);
			throw e;
		}
			
		Object [] values = {
				getActionCode(record.getCTLCapacityLimitAudit().getAuditAction()),
				record.getCTLCapacityLimitAudit().getName(),
				record.getCTLCapacityLimitAudit().getAuditTimeStamp().toGregorianCalendar().getTime(),
				record.getCTLCapacityLimitAudit().getMarket(),
				record.getCTLCapacityLimitAudit().getServiceArea(),
				record.getCTLCapacityLimitAudit().getTaskTypeCategory(),
				record.getCTLCapacityLimitAudit().getCategoryReservation(),
				record.getCTLCapacityLimitAudit().getReleaseBefore(),
				record.getCTLCapacityLimitAudit().isActive() ? "Y" : "N"
		};
		try {
			logContext.setMessage("Inserting data into CLICK_CTL_CAP_LMTS_AUD table");
			this.getJdbcTemplate().update(SQLQueries.INSERT_CLICK_CTL_CAP_LMTS_AUD, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_INSERT_CTLCAPACITY_LIMIT_AUDIT_RECORD,
					logContext);
			throw e;
		}

		
	}

	@Override
	public void insertCTLCapacityDynamicAudit(CTLCapacityDynamicAudit record) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		if (record.getCTLDynamicCapacityLimitAudit() == null) {
			ClickSynchronizationException e = new ClickSynchronizationException("CTLDynamicCapacityLimitAudit is null",  AlarmId.JOBS_DAO_IMPL_INSERT_CTLCAPACITY_DYNAMIC_AUDIT_NULL_RECORD,
					logContext);
			throw e;
		}
			
		Object [] values = {
				getActionCode(record.getCTLDynamicCapacityLimitAudit().getAuditAction()),
				record.getCTLDynamicCapacityLimitAudit().getName(),
				record.getCTLDynamicCapacityLimitAudit().getAuditTimeStamp().toGregorianCalendar().getTime(),
				record.getCTLDynamicCapacityLimitAudit().getMarket(),
				record.getCTLDynamicCapacityLimitAudit().getServiceArea(),
				record.getCTLDynamicCapacityLimitAudit().getTaskTypeCategory(),
				record.getCTLDynamicCapacityLimitAudit().getReservationDate().toGregorianCalendar().getTime(),
				record.getCTLDynamicCapacityLimitAudit().getReservationPercentage(),
				record.getCTLDynamicCapacityLimitAudit().getReleaseBefore(),
				record.getCTLDynamicCapacityLimitAudit().getCategoryCapacity(),
				record.getCTLDynamicCapacityLimitAudit().getAllowedCapacity(),
				record.getCTLDynamicCapacityLimitAudit().getBookedCapacity(),
				record.getCTLDynamicCapacityLimitAudit().getNetAvailableCapacity(),
				record.getCTLDynamicCapacityLimitAudit().getAreaSharedCapacity(),
				record.getCTLDynamicCapacityLimitAudit().getSharedCapacity(),
				record.getCTLDynamicCapacityLimitAudit().isActive() ? "Y" : "N",
				record.getCTLDynamicCapacityLimitAudit().isAllowed() ? "Y" : "N"
		};
		try {
			logContext.setMessage("Inserting data into CLICK_CTL_CAP_LMTS_AUD table");
			this.getJdbcTemplate().update(SQLQueries.INSERT_CLICK_CTL_CAP_LMTS_DYN_AUD, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_INSERT_CTLCAPACITY_LIMIT_AUDIT_RECORD,
					logContext);
			throw e;
		}

		
	}
	private String getActionCode(Integer auditAction) {
		switch(auditAction) {
		case 1:
			return "ADD";
		case 2:
			return "UPDATE";
		case 3:
			return "DELETE";
		default:
			return "?";
		}
	}
	
	@Override
	public List<Integer> getStatusPublishIds() throws ClickSynchronizationException {
		List<Integer> list = new ArrayList<Integer>();
		LogContext logContext = new LogContext().setMessage("Retrieving status publish message IDs");
		MapSqlParameterSource sqlparameter = new MapSqlParameterSource();
		try {
			// Adding IN parameters
			sqlparameter.addValue(Constants.PARAM_QUERY_LIMIT_IN, configuration.getStatusPublishRowLimit(), Types.INTEGER);
			Map<String, Object> rowData = getClickStatusPublishIdsProcedure.execute(sqlparameter);
			Object []  array = (Object []) rowData.get("IDS_OUT");
			for (int i = 0; i < array.length; ++i) {
				Struct struct = (Struct)array[i];
				int id = Integer.parseInt(struct.getAttributes()[0].toString());
				list.add(id);
			}
			return list;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_STATUS_PUBLISH_IDS,
					logContext);
			throw exception;
		}

	}
	@Override
	public List<Integer> getClickMessageIds(String messageType) throws ClickSynchronizationException {
		List<Integer> list = new ArrayList<Integer>();
		LogContext logContext = new LogContext().setMessage("Retrieving status publish message IDs");
		MapSqlParameterSource sqlparameter = new MapSqlParameterSource();
		try {
			// Adding IN parameters
			sqlparameter.addValue(Constants.PARAM_MESSAGE_TYPE_IN, messageType, Types.VARCHAR);
			sqlparameter.addValue(Constants.PARAM_QUERY_LIMIT_IN, configuration.getClickMessageRowLimit(), Types.INTEGER);
			Map<String, Object> rowData = getClickSyncMessageIdsProcedure.execute(sqlparameter);
			Object []  array = (Object []) rowData.get("IDS_OUT");
			for (int i = 0; i < array.length; ++i) {
				Struct struct = (Struct)array[i];
				int id = Integer.parseInt(struct.getAttributes()[0].toString());
				list.add(id);
			}
			return list;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_CLICK_MESSAGE_IDS,
					logContext);
			throw exception;
		}
	}
	@Override
	public List<Integer> getFailedMessageIds() throws ClickSynchronizationException {
		List<Integer> list = new ArrayList<Integer>();
		LogContext logContext = new LogContext().setMessage("Retrieving status publish message IDs");
		MapSqlParameterSource sqlparameter = new MapSqlParameterSource();
		try {
			// Adding IN parameters
			sqlparameter.addValue(Constants.PARAM_QUERY_LIMIT_IN, configuration.getFailedRowLimit(), Types.INTEGER);
			Map<String, Object> rowData = getClickFailedIdsProcedure.execute(sqlparameter);
			Object []  array = (Object []) rowData.get("IDS_OUT");
			for (int i = 0; i < array.length; ++i) {
				Struct struct = (Struct)array[i];
				int id = Integer.parseInt(struct.getAttributes()[0].toString());
				list.add(id);
			}
			return list;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_FAILED_MESSAGE_IDS,
					logContext);
			throw exception;
		}
	}
	@Override
	public StatusRequest getStatusPublishRequest(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("id", id);
			paramMap.put("completedStatus", Constants.MESSAGE_STATUS_COMPLETE);
			paramMap.put("pendingStatus", Constants.MESSAGE_STATUS_PENDING);
			paramMap.put("inProgressStatus", Constants.MESSAGE_STATUS_IN_PROGRESS);
			paramMap.put("retryStatus", Constants.MESSAGE_STATUS_RETRY);
			paramMap.put("failedStatus", Constants.MESSAGE_STATUS_FAILED);
			paramMap.put("updateTaskAssignmentEx", Constants.UPDATE_TASK_ASSIGNMENT_EX);
			
			List<StatusRequest> list =  this.getNamedParameterJdbcTemplate().query(SQLQueries.GET_STATUS_PUBLISH_REQUEST, paramMap, new StatusRequestRowMapper());
			if (list.size() > 0) {
				return list.get(0);
			}
			else
				return null;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_STATUS_PUBLISH_REQUEST,
					logContext);
			throw exception;
		}
	}
	@Override
	public String getClickSyncMessageRequest(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();
		try {
			logContext.add("messageId", id);
			List<Map<String, Object>> map =  this.getJdbcTemplate().queryForList(SQLQueries.GET_CLICK_SYNC_MESSAGE_REQUEST, id);
			if (map.size() == 1) 
				return (String) map.get(0).get("MESSAGE_VAL");
			else
				return null;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_CLICK_SYNC_MESSAGE_REQUEST,
					logContext);
			throw exception;
		}
	}
	@Override
	public void completeStatusPublishRequest(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("id",id);

		Object [] values = {
				Constants.MESSAGE_STATUS_COMPLETE,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_STATUS_PUB to Complete");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_STATUS_PUBLISH_REQUEST, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_COMPLETE_STATUS_PUBLISH_REQUEST,
					logContext);
			throw e;
		}
	}
	@Override
	public void retryStatusPublishRequest(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		Object [] values = {
				Constants.MESSAGE_STATUS_RETRY,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_STATUS_PUB to Complete");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_RETRY_STATUS_PUBLISH_REQUEST, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_RETRY_STATUS_PUBLISH_REQUEST,
					logContext);
			throw e;
		}
	}
	@Override
	public void failStatusPublishRequest(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		Object [] values = {
				Constants.MESSAGE_STATUS_FAILED,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_STATUS_PUB to Failed");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_STATUS_PUBLISH_REQUEST, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_FAIL_STATUS_PUBLISH_REQUEST,
					logContext);
			throw e;
		}
		
	}
	@Override
	public void ignoreStatusPublishRequest(Integer id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		Object [] values = {
				Constants.MESSAGE_STATUS_NOT_SENT,  
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_STATUS_PUB to Failed");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_STATUS_PUBLISH_REQUEST, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_IGNORE_CLICK_SYNC_MESSAGE,
					logContext);
			throw e;
		}
		
	}
	@Override
	public void insertClickStatusPublishMessage(CTLAssignmentUpdate message) throws ClickSynchronizationException {
		LogContext logContext = LogContextHelper.get(message);
		LOG.debug(logContext);
		try {
			Object [] values = {
					Constants.MESSAGE_STATUS_PENDING,
					"ClickSynchronization",
					message.getTask() != null ? message.getTask().getExternalRefID() : null,
					message.getTask() != null && message.getTask().getStatus() != null && message.getTask().getStatus().getName() != null ? message.getTask().getStatus().getName() : "Unscheduled",
					RequestMarshaller.marshall(message),
					0
			};
			logContext.setMessage("Inserting data into CLICK_SYNC_STATUS_PUB table");
			this.getJdbcTemplate().update(SQLQueries.INSERT_CLICK_SYNC_STATUS_PUB, values);
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.JOBS_DAO_IMPL_INSERT_CLICK_STATUS_PUBLISH_MESSAGE, logContext);
		}
		
	}
	@Override
	public void completeClickSyncMessage(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("id",id);

		Object [] values = {
				Constants.MESSAGE_STATUS_COMPLETE,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_MESSAGE to Complete");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_CLICK_SYNC_MESSAGE, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_COMPLETE_CLICK_SYNC_MESSAGE,
					logContext);
			throw e;
		}
		
	}
	@Override
	public void retryClickSyncMessage(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		Object [] values = {
				Constants.MESSAGE_STATUS_RETRY,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_MESSAGE to Retry");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_RETRY_CLICK_SYNC_MESSAGE, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_RETRY_CLICK_SYNC_MESSAGE,
					logContext);
			throw e;
		}
		
	}
	@Override
	public void failClickSyncMessage(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		Object [] values = {
				Constants.MESSAGE_STATUS_FAILED,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_MESSAGE to Failed");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_CLICK_SYNC_MESSAGE, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_FAIL_CLICK_SYNC_MESSAGE,
					logContext);
			throw e;
		}
	}
	@Override
	public void synchronizeClickSyncMessage(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();

		Object [] values = {
				Constants.MESSAGE_STATUS_SYNCHRONIZED,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_MESSAGE to S");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_CLICK_SYNC_MESSAGE, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_SYNCHRONIZE_CLICK_SYNC_MESSAGE,
					logContext);
			throw e;
		}
		
	}
	@Override
	public void insertClickSyncError(int id, String message) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("id",id).add("message",message);
		LOG.debug(logContext);
		try {
			Object [] values = {
					id,
					Constants.MESSAGE_STATUS_PENDING,
					message
			};
			logContext.setMessage("Inserting data into CLICK_SYNC_ERROR table");
			this.getJdbcTemplate().update(SQLQueries.INSERT_CLICK_SYNC_ERROR, values);
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.JOBS_DAO_IMPL_INSERT_CLICK_SYNC_ERROR, logContext);
		}
	}
	@Override
	public void synchronizeStatusRequest(String correlationId, String status) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("correlationId",correlationId).add("status",status);
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("syncStatus", Constants.MESSAGE_STATUS_SYNCHRONIZED);
			paramMap.put("completedStatus", Constants.MESSAGE_STATUS_COMPLETE);
			paramMap.put("taskStatus", status);
			paramMap.put("correlationId", correlationId);
			int result =  this.getNamedParameterJdbcTemplate().update(SQLQueries.SYNCHRONIZE_STATUS, paramMap);
			LOG.trace(new LogContext().add("result",result));
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_SYNCHRONIZE_STATUS_REQUEST,
					logContext);
			throw exception;
		}

	}
	@Override
	public FailedMessage getFailedMessage(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("id", id);
			List<FailedMessage> list =  this.getNamedParameterJdbcTemplate().query(SQLQueries.GET_FAILED_MESSAGE, paramMap, new FailedMessageRowMapper());
			if (list.size() > 0) {
				return list.get(0);
			}
			else
				return null;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_FAILED_MESSAGE,
					logContext);
			throw exception;
		}
	}
	@Override
	public void completeClickError(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("id", id);

		Object [] values = {
				Constants.MESSAGE_STATUS_COMPLETE,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_MESSAGE to Complete");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_CLICK_SYNC_ERROR, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_COMPLETE_CLICK_ERROR,
					logContext);
			throw e;
		}
		
	}
	@Override
	public void failClickError(int id) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("id", id);

		Object [] values = {
				Constants.MESSAGE_STATUS_FAILED,
				id
		};
		try {
			logContext.setMessage("Updating CLICK_SYNC_MESSAGE to Failed");
			this.getJdbcTemplate().update(SQLQueries.UPDATE_CLICK_SYNC_ERROR, values);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_FAIL_CLICK_ERROR,
					logContext);
			throw e;
		}
		
	}
	@Override
	public List<SynchronizerMapping> getSynchronizerMapping() throws ClickSynchronizationException {
		LogContext logContext = new LogContext();
		try {
			List<SynchronizerMapping> list =  this.getJdbcTemplate().query(SQLQueries.GET_CLICK_SYNC_ERROR_MAPPING, new SynchronizerMappingRowMapper());
			return list;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_SYNCHRONIZER_MAPPING,
					logContext);
			throw exception;
		}
	}
	@Override
	public String getDynamicClassSource(String name) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("name", name);
			
			List<Map<String, Object>> list =  this.getNamedParameterJdbcTemplate().queryForList(SQLQueries.GET_DYNAMIC_CLASS_SOURCE, paramMap);
			if (list.size() > 0) {
				return (String) list.get(0).get("CLASS_SOURCE_VAL");
			}
			else
				return null;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_SYNCHRONIZER_SOURCE,
					logContext);
			throw exception;
		}
	}
	@Override
	public List<StatusEvaluatorMapping> getStatusEvaluatorMapping() throws ClickSynchronizationException {
		LogContext logContext = new LogContext();
		try {
			List<StatusEvaluatorMapping> list =  this.getJdbcTemplate().query(SQLQueries.GET_CLICK_SYNC_STAT_EVAL_MAP, new StatusEvaluatorMappingRowMapper());
			return list;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_STATUS_EVALUATOR_MAPPING,
					logContext);
			throw exception;
		}
	}
	@Override
	public List<Integer> getRetryMessages(String correlationId) throws ClickSynchronizationException {
		LogContext logContext = new LogContext();
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("correlationId", correlationId);
			List<Integer> list =  this.getNamedParameterJdbcTemplate().query(SQLQueries.CHECK_FAILED_MESSAGE, paramMap, new IntegerRowMapper());
			return list;
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_RETRY_MESSAGES,
					logContext);
			throw exception;
		}
	}
	@Override
	public void retryMessage(String correlationId) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("correlationId", correlationId);

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);

		try {
			logContext.setMessage("Updating CLICK_SYNC_MESSAGES to Retry");
			this.getNamedParameterJdbcTemplate().update(SQLQueries.RETRY_MESSAGE, paramMap);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_RETRY_MESSAGE,
					logContext);
			throw e;
		}
		
	}
	@Override
	public void completeFailedError(String correlationId) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("correlationId", correlationId);

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);

		try {
			logContext.setMessage("Updating CLICK_SYNC_ERROR to Complete");
			this.getNamedParameterJdbcTemplate().update(SQLQueries.COMPLETE_FAILED_ERROR_BY_CORRELATION_ID, paramMap);
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_COMPLETE_FAILED_ERROR,
					logContext);
			throw e;
		}
		
	}
	@Override
	public List<Map<String, Object>> getTechDetailsByCorrelationId(String correlationId) throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("correlationId", correlationId);

		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);

		try {
			logContext.setMessage("Fetching Tech Details For CorrelationId");
			List<Map<String, Object>> list = this.getNamedParameterJdbcTemplate().queryForList(SQLQueries.FETCH_DATA_FOR_ALLOCATION, paramMap);
			return list;
		} catch (Exception ex) {
			ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_TECH_DETAILS_BY_CORRELATION_ID,
					logContext);
			throw e;
		}
	}


}
