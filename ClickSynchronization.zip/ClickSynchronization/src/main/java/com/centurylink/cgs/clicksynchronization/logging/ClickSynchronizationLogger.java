package com.centurylink.cgs.clicksynchronization.logging;

import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.dispatchcommon.logging.DispatchLogger;


public class ClickSynchronizationLogger extends DispatchLogger {
	
	private static final String SERVICE_NAME = Constants.APPLICATION_SERVICE_NAME; 
	
	private ClickSynchronizationLogger(Class clazz, String serviceName) {
		super(clazz, serviceName);
	}
	public static ClickSynchronizationLogger getLogger(Class clazz) {
		ClickSynchronizationLogger instance = new ClickSynchronizationLogger(clazz, SERVICE_NAME);
		return instance;
	}
}
