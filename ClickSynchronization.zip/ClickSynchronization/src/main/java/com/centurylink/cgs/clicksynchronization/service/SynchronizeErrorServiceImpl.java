package com.centurylink.cgs.clicksynchronization.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerCache;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerMapping;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.DynamicClass;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

@Service
public class SynchronizeErrorServiceImpl implements SynchronizeErrorService {

	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(SynchronizeErrorServiceImpl.class);
	@Autowired
	JobsDao jobsDao;
	
	@Autowired
	Configuration configuration;
	
	@Autowired
	Util util;
	
	@Autowired 
	SynchronizerCache synchronizerCache;
	
	@Override
	public void process() throws ClickSynchronizationException {
		
		List<Integer> failureIds = jobsDao.getFailedMessageIds();
		for (int id : failureIds) {
			LogContext context = null;
			
			FailedMessage failure = null;
			try {
				failure = jobsDao.getFailedMessage(id);
				context = LogContextHelper.get(failure);
				ClickSynchronizer synchronizer = getSynchronizer(failure);
				context.add("synchronizer", synchronizer.getClass().toString());
				LOG.info(context);;
				synchronizer.synchronize(failure);
			} catch (ClickSynchronizationException e) {
				if (failure != null) {
					e.getContext().add("correlationId",failure.getCorrelationId());
				}
				LOG.error(e);
				util.saveDispatchLog(e);
				if (failure != null) {
					jobsDao.failClickError(failure.getErrorMessageId());
					int pause = configuration.getIncrementSecondsToPause();
					util.pause(pause);
					// If synchronization fails, create a new record to try again
					if (!Constants.ERROR_NO_SYNCHRONIZER.equals(e.getMessage()))
						jobsDao.insertClickSyncError(failure.getId(), e.getMessage());
				}
			}
		}
	}

	private ClickSynchronizer getSynchronizer(FailedMessage failure) throws ClickSynchronizationException {
		LogContext context = new LogContext().add("id",failure.getId()).add("errorMessage",failure.getErrorMessage());
		ClickSynchronizer synchronizer = null;
		try {
			for (SynchronizerMapping config : configuration.getSynchronizerMapping()) {
				if ("*".equals(config.getErrorMessage())) {
					synchronizer = synchronizerCache.getSynchronizerObject(config.getSynchronizerClass());
					break;
				}
				else if (failure.getErrorMessage() != null && failure.getErrorMessage().contains(config.getErrorMessage())) {
					synchronizer = synchronizerCache.getSynchronizerObject(config.getSynchronizerClass());
					break;
				}
			}
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.SYNCHRONIZE_ERROR_SERVICE_IMPL_GET_SYNCHRONIZER, context);
		}
		if (synchronizer != null) {
			return synchronizer;
		}
		throw new ClickSynchronizationException(Constants.ERROR_NO_SYNCHRONIZER, AlarmId.SYNCHRONIZE_ERROR_SERVICE_IMPL_GET_SYNCHRONIZER, context);
	}


}
