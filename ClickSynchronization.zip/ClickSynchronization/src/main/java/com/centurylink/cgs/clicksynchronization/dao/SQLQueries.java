package com.centurylink.cgs.clicksynchronization.dao;

public class SQLQueries {
	public static final String INSERT_CLICK_CTL_CAP_LMTS_AUD = 
									"INSERT INTO CLICK_CTL_CAP_LMTS_AUD_ST (ACTION_CD," +
									"                                       CLICK_USER_NAME," +
									"                                       AUDIT_TMSTMP," +
									"                                       REGION," +
									"                                       DISTRICT," +
									"                                       CS_PRODUCT_TYP," +
									"                                       CATEGORY_RESERVATION_VAL," +
									"                                       RELEASE_BEFORE_VAL," +
									"                                       ACTIVE_IND," +
									"                                       CREATE_DT)" +
									"     VALUES (?,?,?,?,?,?,?,?,?,SYSTIMESTAMP)";
													
	public static final String INSERT_CLICK_CTL_CAP_LMTS_DYN_AUD = 
									"INSERT INTO CLICK_CTL_CAP_LMTS_DYN_AUD_ST (ACTION_CD, " +
									"                                           CLICK_USER_NAME, " +
									"                                           AUDIT_TMSTMP, " +
									"                                           REGION, " +
									"                                           DISTRICT, " +
									"                                           CS_PRODUCT_TYP, " +
									"                                           RESERVATION_DT, " +
									"                                           RESERVATION_PCT, " +
									"                                           RELEASE_BEFORE_VAL, " +
									"                                           CATEGORY_CAPACITY_VAL, " +
									"                                           ALLOWED_CAPACITY_VAL, " +
									"                                           BOOKED_CAPACITY_VAL, " +
									"                                           NET_AVAILABLE_CAPACITY_VAL, " +
									"                                           AREA_SHARED_CAPACITY_VAL, " +
									"                                           SHARED_CAPACITY_VAL, " +
									"                                           ACTIVE_IND, " +
									"                                           ALLOWED_IND, " +
									"                                           CREATE_DT) " +
									"     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,SYSTIMESTAMP) ";

	
	public static final String GET_STATUS_PUBLISH_REQUEST = 
								"SELECT MESSAGE_SOURCE_VAL,   " +
										"       MESSAGE_VAL,   " +
										"       V.CORRELATION_ID,   " +
										"       V.TASK_STATUS,   " +
										"       J.TASK_STATUS JOBS_TASK_STATUS,   " +
										"       J.TECH_ID, " +
										"       CASE WHEN EXISTS (SELECT 1   " +
										"                            FROM CLICK_SYNC_MESSAGE_V   " +
										"                            WHERE MESSAGE_STATUS_VAL IN (:completedStatus, :pendingStatus, :inProgressStatus, :retryStatus, :failedStatus) AND CORRELATION_ID = V.CORRELATION_ID and message_typ = :updateTaskAssignmentEx) " +
										"                 THEN 'N' ELSE 'Y' END SYNCED     " +
										"  FROM CLICK_SYNC_STATUS_PUB_V V   " +
										"       LEFT OUTER JOIN JOBS_DETAIL J ON J.CORRELATION_ID = V.CORRELATION_ID   " +
										" WHERE MESSAGE_STATUS_PUB_ID = :id   " +
										"UNION ALL   " +
										"SELECT MESSAGE_SOURCE_VAL,   " +
										"       MESSAGE_VAL,   " +
										"       V.CORRELATION_ID,   " +
										"       V.TASK_STATUS,   " +
										"       J.TASK_STATUS JOBS_TASK_STATUS,   " +
										"       J.TECH_ID, " +
										"       CASE WHEN EXISTS (SELECT 1   " +
										"                            FROM CLICK_SYNC_MESSAGE_V   " +
										"                            WHERE MESSAGE_STATUS_VAL IN (:completedStatus, :pendingStatus, :inProgressStatus, :retryStatus, :failedStatus) AND CORRELATION_ID = V.CORRELATION_ID and message_typ = :updateTaskAssignmentEx) " +
										"                 THEN 'N' ELSE 'Y' END SYNCED             " +
										"  FROM CLICK_SYNC_STATUS_PUB_V V   " +
										"       INNER JOIN DISPATCH_GROUP_DETAILS G   " +
										"          ON V.CORRELATION_ID = G.CORRELATION_ID   " +
										"       LEFT OUTER JOIN JOBS_DETAIL J ON J.CORRELATION_ID = G.PARENT_CORRELATION_ID   " +
										" WHERE MESSAGE_STATUS_PUB_ID = :id  ";

	public static final String GET_CLICK_SYNC_MESSAGE_REQUEST = "SELECT MESSAGE_VAL FROM CLICK_SYNC_MESSAGE_V WHERE MESSAGE_ID = ?";

	public static final String UPDATE_STATUS_PUBLISH_REQUEST = "UPDATE CLICK_SYNC_STATUS_PUB_V SET MESSAGE_STATUS_VAL = ?, UPDATE_DT=SYSTIMESTAMP WHERE MESSAGE_STATUS_PUB_ID = ?";

	public static final String UPDATE_RETRY_STATUS_PUBLISH_REQUEST = "UPDATE CLICK_SYNC_STATUS_PUB_V SET MESSAGE_STATUS_VAL = ?, RETRY_CNT=RETRY_CNT+1, UPDATE_DT=SYSTIMESTAMP WHERE MESSAGE_STATUS_PUB_ID = ?";

	public static final String INSERT_CLICK_SYNC_STATUS_PUB = 
									"INSERT INTO CLICK_SYNC_STATUS_PUB_V (MESSAGE_STATUS_PUB_ID, " +
									"                                   MESSAGE_STATUS_VAL, " +
									"                                   MESSAGE_SOURCE_VAL, " +
									"                                   CORRELATION_ID, " +
									"                                   TASK_STATUS, " +
									"                                   MESSAGE_VAL, " +
									"                                   RETRY_CNT, " +
									"                                   CREATE_DT, " +
									"                                   UPDATE_DT) " +
									"     VALUES (MESSAGE_STATUS_PUB_ID_SEQ.NEXTVAL, ?, ?, ?, ?, ?, ?, SYSTIMESTAMP, SYSTIMESTAMP) ";

	public static final String UPDATE_CLICK_SYNC_MESSAGE = "UPDATE CLICK_SYNC_MESSAGE_V SET MESSAGE_STATUS_VAL = ?, UPDATE_DT=SYSTIMESTAMP WHERE MESSAGE_ID = ?";

	public static final String UPDATE_RETRY_CLICK_SYNC_MESSAGE = "UPDATE CLICK_SYNC_MESSAGE_V SET MESSAGE_STATUS_VAL = ?, RETRY_CNT=RETRY_CNT+1, UPDATE_DT=SYSTIMESTAMP WHERE MESSAGE_ID = ?";

	public static final String INSERT_CLICK_SYNC_ERROR = "INSERT INTO CLICK_SYNC_ERROR_V (ERROR_MESSAGE_ID, MESSAGE_ID, MESSAGE_STATUS_VAL, ERROR_MESSAGE_VAL) VALUES (ERROR_MESSAGE_ID_SEQ.NEXTVAL, ?, ?, ?)";
	
	public static final String SYNCHRONIZE_STATUS = 
									"UPDATE CLICK_SYNC_MESSAGE_V " +
											"   SET MESSAGE_STATUS_VAL = :syncStatus " +
											" WHERE MESSAGE_ID = " +
											"          (SELECT MIN (MESSAGE_ID) " +
											"             FROM CLICK_SYNC_MESSAGE_V " +
											"            WHERE     MESSAGE_STATUS_VAL = :completedStatus " +
											"                  AND TASK_STATUS = :taskStatus " +
											"                  AND CORRELATION_ID = :correlationId)";
	
	public static final String GET_FAILED_MESSAGE = 
			"SELECT E.ERROR_MESSAGE_ID, E.MESSAGE_ID, E.ERROR_MESSAGE_VAL, M.MESSAGE_TYP, M.MESSAGE_VAL, M.CORRELATION_ID " +
					"  FROM CLICK_SYNC_ERROR_V E" +
					"  INNER JOIN CLICK_SYNC_MESSAGE_V M ON E.MESSAGE_ID = M.MESSAGE_ID" +
					" WHERE E.ERROR_MESSAGE_ID = :id ";

	public static final String UPDATE_CLICK_SYNC_ERROR = "UPDATE CLICK_SYNC_ERROR_V SET MESSAGE_STATUS_VAL = ?, UPDATE_DT=SYSTIMESTAMP WHERE ERROR_MESSAGE_ID = ?";

	public static final String GET_CLICK_SYNC_ERROR_MAPPING = "SELECT ERROR_MESSAGE_VAL, CLASS_NM FROM CLICK_SYNC_ERROR_MAPPING_REF ORDER BY SEQUENCE_NO";

	public static final String GET_DYNAMIC_CLASS_SOURCE = "SELECT CLASS_SOURCE_VAL  FROM CLICK_SYNC_DYNAMIC_CLASS WHERE CLASS_NM = :name";

	public static final String GET_CLICK_SYNC_STAT_EVAL_MAP = "SELECT MESSAGE_SOURCE_VAL, TASK_STATUS, CLASS_NM FROM CLICK_SYNC_STAT_EVAL_MAP_REF";		

	public static final String CHECK_FAILED_MESSAGE = "SELECT MESSAGE_ID FROM CLICK_SYNC_MESSAGE_V WHERE MESSAGE_STATUS_VAL NOT IN ('Completed','Synchronized') AND CORRELATION_ID = :correlationId";
	
	public static final String RETRY_MESSAGE = "UPDATE CLICK_SYNC_MESSAGE_V set MESSAGE_STATUS_VAL = 'Retry' WHERE MESSAGE_STATUS_VAL NOT IN ('Completed','Synchronized') AND CORRELATION_ID = :correlationId";

	public static final String COMPLETE_FAILED_ERROR_BY_CORRELATION_ID = "UPDATE CLICK_SYNC_ERROR_V set MESSAGE_STATUS_VAL = 'Complete' WHERE MESSAGE_STATUS_VAL = 'Failed' AND CORRELATION_ID = :correlationId";
	//public static final String FETCH_DATA_FOR_ALLOCATION= "select DISTINCT UPDATE_DT, asd.TECH_ID,ASSIGNMENT_START,ASSIGNMENT_FINISH,ctv.district,UPDATE_DT from assignment_details_hist asd,  CLICK_TECHNICIAN_V ctv where asd.TECH_ID=ctv.TECH_ID and asd.CORRELATION_ID=:correlationId and ROWNUM<2 ORDER BY asd.UPDATE_DT desc";
	public static final String FETCH_DATA_FOR_ALLOCATION = "select TECH_ID, DISTRICT, ASSIGNMENT_START, ASSIGNMENT_FINISH from( select adh.TECH_ID, ctv.DISTRICT, ctv.CREATE_DT, adh.ASSIGNMENT_START, adh.ASSIGNMENT_FINISH, max(ctv.CREATE_DT) OVER (PARTITION BY ctv.TECH_ID) max_dt from assignment_details_hist adh inner join click_technician_v ctv on adh.TECH_ID = ctv.TECH_ID where adh.CORRELATION_ID = :correlationId and adh.UPDATE_DT = (select max(UPDATE_DT) from assignment_details_hist where CORRELATION_ID = :correlationId and TECH_ID is not null) ) where CREATE_DT = max_dt";
}
