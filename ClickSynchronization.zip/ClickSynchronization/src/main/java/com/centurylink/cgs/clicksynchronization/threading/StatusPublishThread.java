package com.centurylink.cgs.clicksynchronization.threading;

import java.util.HashMap;
import java.util.List;

import com.centurylink.cgs.clicksynchronization.client.DispatchGroupClient;
import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.dao.JobsDaoImpl;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.StatusEvaluatorCache;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;
import com.centurylink.cgs.clicksynchronization.model.UpstreamStatusEvaluator;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchgroupinterface.AssignmentUpdateResult;

public class StatusPublishThread implements Runnable{
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(StatusPublishThread.class);

	Util util = Util.getInstance();
	
	JobsDao jobsDao = JobsDaoImpl.getInstance();
	
	Configuration configuration = Configuration.getInstance();
	
	StatusEvaluatorCache statusEvaluatorCache = StatusEvaluatorCache.getInstance();
	
	DispatchGroupClient group = DispatchGroupClient.getInstance();
	
	@Override
	public void run() {
		List<Integer> list;
		try {
			list = jobsDao.getStatusPublishIds();
		} catch (ClickSynchronizationException e1) {
			LOG.error(e1);
			return;
		}
		// After pulling the requests, sleep long enough to allow any DispatchTask transactions to complete
		if (list.size() > 0) {
			try { 
				int sleepTime = configuration.getUpstreamStatusPublishDelayMilliseconds();
				LOG.info(new LogContext().setMessage("Sleeping before sending status").add("sleepTime",sleepTime));
				Thread.sleep(sleepTime);
			} catch (Exception te) {}
		}
		
		HashMap<Integer, Integer> failedStatus = new HashMap<Integer, Integer>();
		int correlationId = 0;
		for (Integer id : list) {
			LogContext context = new LogContext().add("id",id);
			StatusRequest request = null;
			try {
				request = jobsDao.getStatusPublishRequest(id);
				if (request == null) {
					String errorDescription = "Correlation ID is not in JOBS";
					throw new ClickSynchronizationException(errorDescription, AlarmId.STATUS_PUBLISH_SERVICE_IMPL_PUBLISH_NO_JOBS, context.add("errorDescription",errorDescription).add("correlationId","0"));
				}
				correlationId = request.getCorrelationId();
				if (Constants.MESSAGE_SOURCE_CLICK_SYNCHRONIZATION.equals(request.getMessageSource()))
					jobsDao.synchronizeStatusRequest(correlationId+"", request.getTaskStatus());
				context.add(LogContextHelper.get(request));
				if (request == null || request.getTaskStatus() == null || failedStatus.containsKey(request.getCorrelationId())) {
					LOG.info(context.setMessage("Setting CLICK_SYNC_STATUS_PUB record to Retry"));
					jobsDao.retryStatusPublishRequest(id);
					continue;
				}
				
				String evaluatorClassName = configuration.getUpstreamStatusEvaluatorClass(request.getMessageSource(), request.getTaskStatus());
				UpstreamStatusEvaluator evaluator = null;
				if (evaluatorClassName != null)
					evaluator = statusEvaluatorCache.getUpstreamStatusEvaluatorObject(evaluatorClassName);
				if (evaluator == null || !evaluator.sendStatus(request)) {
					LOG.info(context.setMessage("CLICK_SYNC_STATUS_PUB record is ignored"));
					jobsDao.ignoreStatusPublishRequest(id);
					continue;
				} 
				context.add("messageId",id);
				AssignmentUpdateResult response = group.post(request.getMessage());
				if (response != null && response.getStatus() != null && response.getStatus() == Constants.ASSIGNMENT_STATUS_SUCCESS) {
					LOG.info(context.setMessage("CLICK_SYNC_STATUS_PUB record sent upstream and set to Completed"));
					// Mark as complete
					jobsDao.completeStatusPublishRequest(id);
					continue;
				}
				String errorMessage = "Bad response from DispatchGroup";
				if (response != null) {
					context.add("status",response.getStatus());
					if (response.getError() != null) {
						context.add("errorDescription",response.getError().getErrorDescription());
						errorMessage = response.getError().getErrorDescription();
					}
				}
				throw new ClickSynchronizationException(errorMessage, AlarmId.STATUS_PUBLISH_SERVICE_IMPL_PUBLISH, context);
			} catch (ClickSynchronizationException e) {
				try {
					if (request != null) 
						failedStatus.put(request.getCorrelationId(), id);
					e.getContext().add(context);
					LOG.error(e);
					util.saveDispatchLog(e);
					String error = e.getContext().getValue("errorDescription");
					if (error != null && configuration.isUpstreamFailure(error))
						jobsDao.failStatusPublishRequest(id);
					else
						jobsDao.retryStatusPublishRequest(id);
				} catch (Exception ex) {
					ClickSynchronizationException exception =  new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.STATUS_PUBLISH_SERVICE_IMPL_PUBLISH, context);
					LOG.error(exception);
				}
			}
		}

		
	}

}
