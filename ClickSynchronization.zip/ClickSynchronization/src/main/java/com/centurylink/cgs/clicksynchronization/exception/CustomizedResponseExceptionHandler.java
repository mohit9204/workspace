package com.centurylink.cgs.clicksynchronization.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;

@ControllerAdvice(basePackages = {"com.centurylink.cgs.clicksynchronization"} )
@RestController
public class CustomizedResponseExceptionHandler extends ResponseEntityExceptionHandler{

	@Autowired 
	private Util util;
	
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(CustomizedResponseExceptionHandler.class);

	
	private void createResponseEntityAndStoreException(String message, 
			BaseResponse.responseStatusValues responseStatus, HttpStatus httpStatus, Exception ex, int alarmId) {
		ClickSynchronizationException exception = new ClickSynchronizationException(message, ex, alarmId,	new LogContext().setMessage(message));
		LOG.error(exception);
		util.saveDispatchLog(exception);
	}
	private void createResponseEntityAndStoreException(int reasonCode, String message, 
			BaseResponse.responseStatusValues responseStatus, HttpStatus httpStatus, ClickSynchronizationException exception) {
		LOG.error(exception);
		util.saveDispatchLog(exception);

	}
	@ExceptionHandler(ClickSynchronizationException.class)
	public final void  handleClickDataRetrievalServiceException(ClickSynchronizationException ex) {
		
 		createResponseEntityAndStoreException(ex.getAlarmId(), ex.getMessage(), BaseResponse.responseStatusValues.Failure,
 				HttpStatus.INTERNAL_SERVER_ERROR, ex);
 
	}
	@ExceptionHandler(Exception.class)
	public final void handleAllExceptions(Exception ex)  {

		createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_ALL_EXCEPTIONS);
	}
	
	
}
