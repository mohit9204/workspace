package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;

public interface StatusPublishService {
	public void publish() throws ClickSynchronizationException;
}
