package com.centurylink.cgs.clicksynchronization.client;

import java.io.IOException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.GetTask;
import com.clicksoftware.GetTaskResponse;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.ProcessTaskExResponse;
import com.clicksoftware.TaskReference;
import com.clicksoftware.serviceoptimizeservice.OptionalParameters;

public class GetTaskClient extends WebServiceGatewaySupport {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(GetTaskClient.class);

	private static GetTaskClient instance = new GetTaskClient();
	
	private GetTaskClient() {
		
	}
	public static GetTaskClient getInstance() {
		return instance;
	}

	@Value("${click.gettask.soap.action}")
	private String clickSoapAction;
	
	public GetTaskResponse getTask(String correlationId) throws ClickSynchronizationException {
		LogContext context = new LogContext().add("correlationId",correlationId);
		try {
			GetTask getTask = getRequest(correlationId);
			WebServiceTemplate wsTemplate = getWebServiceTemplate();		
			GetTaskResponse response = (GetTaskResponse) wsTemplate.marshalSendAndReceive(getTask, 
					new WebServiceMessageCallback() {
				@Override
				public void doWithMessage(WebServiceMessage requestMessage) throws IOException, TransformerException {
					try {
						SoapMessage soapMsg = ((SoapMessage) requestMessage);
						// get the header from the SOAP message		
						SoapHeader soapHeader = soapMsg.getSoapHeader();
						soapMsg.setSoapAction(clickSoapAction);					
						// create the header element
						OptionalParameters optionalParameters = new OptionalParameters();
						optionalParameters.setCallerIdentity(Constants.CALLER_IDENTY); 
						optionalParameters.setErrorOnNonExistingDictionaries(true);
						// create a marshaller
						JAXBContext context = JAXBContext.newInstance(OptionalParameters.class);
						Marshaller marshaller = context.createMarshaller();
						// marshal the headers into the specified result
						marshaller.marshal(optionalParameters, soapHeader.getResult());
					} catch (JAXBException  e) {
						throw new TransformerException("Error while marshalling");
					}
				}
			});
			return response;
		} catch (Exception e) {
			ClickSynchronizationException exception = new ClickSynchronizationException(e.getMessage(), e, AlarmId.PROCESS_TASK_EX_CLICK_CLIENT_PROCESS_TASK_EX, context);
			throw exception;
		}
	}
	private GetTask getRequest(String correlationId) {
		GetTask request = new GetTask();
		TaskReference task = new TaskReference();
		request.setTask(task);
		task.setExternalRefID(correlationId);
		task.setNumber(1);
		request.setGetAssignment(true);
		return request;
	}
}
