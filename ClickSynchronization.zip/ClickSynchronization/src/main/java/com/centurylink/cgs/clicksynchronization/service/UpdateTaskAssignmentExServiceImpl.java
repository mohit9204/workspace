package com.centurylink.cgs.clicksynchronization.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.threading.UpdateTaskAssignmentExThread;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

public class UpdateTaskAssignmentExServiceImpl implements UpdateTaskAssignmentExService {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(UpdateTaskAssignmentExService.class);
	
	@Autowired
	Configuration configuration;
	
	private static boolean isRunning = false;

	@Override
	public void process() throws ClickSynchronizationException {
		if (isRunning) {
			LOG.info("Previous process is still running");
			return;
		}
		try {
			isRunning = true;
			int numberOfThreads = configuration.getNumberOfUpdateTaskAssignmentExThreads();
			List<Thread> threads = new ArrayList<Thread>();
			LOG.info(new LogContext().setMessage("Starting UpdateTaskAssignmentEx threads").add("numberOfThreads",numberOfThreads));
			for (int i = 0; i < numberOfThreads; ++i) {
				Thread thread = new Thread(new UpdateTaskAssignmentExThread());
				thread.start();
				threads.add(thread);
			}
			for (Thread thread : threads) {
				try {thread.join();} catch (InterruptedException e) {}
			}
		} finally {
			isRunning = false;
		}
	}

}
