package com.centurylink.cgs.clicksynchronization.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.clicksynchronization.model.StatusRequest;

public class StatusRequestRowMapper implements RowMapper<StatusRequest> {
	@Override
	public StatusRequest mapRow(ResultSet rs, int rowNum) throws SQLException {
		StatusRequest result = new StatusRequest();
		result.setMessageSource(rs.getString("MESSAGE_SOURCE_VAL"));
		result.setMessage(rs.getString("MESSAGE_VAL"));
		result.setTaskStatus(rs.getString("TASK_STATUS"));
		result.setJobsTaskStatus(rs.getString("JOBS_TASK_STATUS"));
		result.setCorrelationId(Integer.parseInt(rs.getString("CORRELATION_ID")));
		result.setTechId(rs.getString("TECH_ID"));
		String synced = rs.getString("SYNCED");
		if ("Y".equals(synced))
			result.setInSync(true);
		else
			result.setInSync(false);
		return result;
	}
}