package com.centurylink.cgs.clicksynchronization.util;

public class Constants {

	public static final String APPLICATION_SERVICE_NAME = "ClickSynchronization";
	public static final String PACKAGE_GET_CLICK_SYNC = "GET_CLICK_SYNC";
	public static final String PROC_GET_STATUS_PUB_IDS = "GET_STATUS_PUB_IDS";
	public static final String PROC_GET_SYNC_MESSAGE_IDS = "GET_SYNC_MESSAGE_IDS";
	public static final String PROC_GET_FAILED_MESSAGE_IDS = "GET_FAILED_MESSAGE_IDS";
	public static final String PARAM_IDS_OUT = "IDS_OUT";
	public static final String PARAM_MESSAGE_TYPE_IN = "PARAM_MESSAGE_TYPE_IN";
	public static final String TABLE_NUMBER_TYPE_TABLE = "NUMBER_TYPE_TABLE";
	public static final String PARAM_QUERY_LIMIT_IN = "QUERY_LIMIT_IN";
	public static final String CLICK_SYNCHRONIZATION_OPTIONS = "CLICK_SYNCHRONIZATION_OPTIONS";
	public static final String CLICK_SYNCH_UPSTREAM_FAIL = "CLICK_SYNCH_UPSTREAM_FAIL";
	public static final int ASSIGNMENT_STATUS_SUCCESS = 1;
	public static final String CALLER_IDENTY = "DGWAPP";
	public static final String PROCESS_TASK_EX = "ProcessTaskEx";
	public static final String UPDATE_TASK_ASSIGNMENT_EX = "UpdateTaskAssignmentEx";
	public static final String STATUS_COMPLETED = "Completed";
	public static final String STATUS_ALLOCATED = "Allocated";
	public static final String STATUS_ASSIGNED = "Assigned";
	public static final String STATUS_ENROUTE = "EnRoute";
	public static final String STATUS_ONSITE = "On-Site";
	public static final String STATUS_NOTREADY = "Not Ready";
	public static final String STATUS_NONCOMPLETE = "Non Complete";
	public static final String STATUS_CANCELLED = "Cancelled";
	public static final String STATUS_UNSCHEDULED = "Unscheduled";
	public static final String MESSAGE_SOURCE_DISPATCH_SCHEDULE = "DispatchSchedule";
	public static final String MESSAGE_SOURCE_CLICK_SYNCHRONIZATION = "ClickSynchronization";
	public static final String TRUE = "true";
	public static final String MESSAGE_STATUS_COMPLETE = "Complete";
	public static final String MESSAGE_STATUS_RETRY = "Retry";
	public static final String MESSAGE_STATUS_PENDING = "Pending";
	public static final String MESSAGE_STATUS_FAILED = "Failed";
	public static final String MESSAGE_STATUS_NOT_SENT = "Ignored";
	public static final String MESSAGE_STATUS_IN_PROGRESS = "In-Progress";
	public static final String MESSAGE_STATUS_SYNCHRONIZED = "Synchronized";
	public static final String ERROR_NO_SYNCHRONIZER = "No Synchronizer is defined";
	public static final String ERROR_UPSTREAM_STATUS_EVALUATOR = "No upstream status evaluator is defined";
	
}
