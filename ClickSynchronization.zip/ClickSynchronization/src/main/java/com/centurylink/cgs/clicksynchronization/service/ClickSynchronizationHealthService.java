package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;

public interface ClickSynchronizationHealthService {
	public VersionHealthResponse getHealthDetails();
}
