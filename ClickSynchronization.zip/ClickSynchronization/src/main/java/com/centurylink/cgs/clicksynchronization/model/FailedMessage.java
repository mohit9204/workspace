package com.centurylink.cgs.clicksynchronization.model;

public class FailedMessage {
	private int errorMessageId;
	private int id;
	private String errorMessage;
	private String messageType;
	private String message;
	private String correlationId;
	
	public int getErrorMessageId() {
		return errorMessageId;
	}
	public void setErrorMessageId(int errorMessageId) {
		this.errorMessageId = errorMessageId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
}
