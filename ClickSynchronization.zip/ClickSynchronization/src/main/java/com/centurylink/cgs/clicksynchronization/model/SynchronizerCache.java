package com.centurylink.cgs.clicksynchronization.model;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.DynamicClass;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

@Component
public class SynchronizerCache {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(SynchronizerCache.class);

	
	@Autowired
	private JobsDao jobsDao;

	private static HashMap<String, ClickSynchronizer> map = new HashMap<String, ClickSynchronizer>();
	private static Object mapMutex = new Object();
	

	public  ClickSynchronizer getSynchronizerObject(String synchronizerClass) throws ClickSynchronizationException {
		LogContext context = new LogContext().add("synchronizerClass", synchronizerClass);
		if (synchronizerClass == null)
			return null;
		
		synchronized (mapMutex) {
			
			if (map.get(synchronizerClass) != null)
				return map.get(synchronizerClass);
			
			String source = jobsDao.getDynamicClassSource(synchronizerClass);
			if (source == null)
				throw new ClickSynchronizationException(Constants.ERROR_NO_SYNCHRONIZER, AlarmId.SYNCHRONIZER_CACHE_GET_SYNCHRONIZER_OBJECT_NO_SYNC, context);
			try {
				LOG.info(context.setMessage("Loading class from table"));
				ClickSynchronizer object = (ClickSynchronizer) DynamicClass.getInstance(synchronizerClass, source);
				map.put(synchronizerClass, object);
				return object;
			} catch (Exception e) {
				throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.SYNCHRONIZER_CACHE_GET_SYNCHRONIZER_OBJECT, context);			
			}
		}
	}
	public static void refresh() {
		synchronized (mapMutex) {
			map.clear();
		}
	}
	
}
