package com.centurylink.cgs.clicksynchronization.helper;

import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.Task;
import com.clicksoftware.UpdateTaskAssignmentEx;

public class LogContextHelper {

	public static LogContext get(UpdateTaskAssignmentEx updateTaskAssignmentEx) {
		LogContext context = new LogContext();
		if (updateTaskAssignmentEx != null && updateTaskAssignmentEx.getTask() != null) {
			Task task = updateTaskAssignmentEx.getTask();
			context.add("correlationId",task.getExternalRefID());
			if (task.getStatus() != null) {
				context.add("status",task.getStatus().getName());
			}
		}
		return context;
	}
	public static LogContext get(CTLAssignmentUpdate request) {
		LogContext context = new LogContext();
		if (request != null && request.getTask() != null)
			context.add("correlationId",request.getTask().getExternalRefID());
		return context;
	}
	public static LogContext get(ProcessTaskEx processTaskEx) {
		LogContext context = new LogContext();
		if (processTaskEx != null && processTaskEx.getTask() != null) {
			context.add("correlationId",processTaskEx.getTask().getExternalRefID());
			context.add("aggregationId",processTaskEx.getTask().getCTLAggregationID());
			context.add("CTLDispatchCallID",processTaskEx.getTask().getCTLDispatchCallID());
		}
		return context;
	}
	public static LogContext get(FailedMessage failure) {
		return get(failure, true);
	}
	public static LogContext get(FailedMessage failure, boolean includeErrorMessage) {
		LogContext context = new LogContext();
		if (failure != null) {
			context.add("correlationId",failure.getCorrelationId());
			context.add("id",failure.getId());
			context.add("errorMessageId",failure.getErrorMessageId());
			context.add("messageType",failure.getMessageType());
			if (includeErrorMessage)
				context.add("error",failure.getErrorMessage());
		}
		return context;
	}
	public static LogContext get(StatusRequest request) {
		LogContext context = new LogContext();
		if (request != null) {
			context.add("correlationId",request.getCorrelationId());
			context.add("taskStatus",request.getTaskStatus());
			context.add("jobsTaskStatus",request.getJobsTaskStatus());
			context.add("messageSource",request.getMessageSource());
			context.add("inSync",request.isInSync());
		}
		return context;
	}
}
