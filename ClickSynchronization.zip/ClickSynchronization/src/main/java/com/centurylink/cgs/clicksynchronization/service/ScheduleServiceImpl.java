package com.centurylink.cgs.clicksynchronization.service;

import java.util.HashMap;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.StatusEvaluatorCache;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerCache;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.DynamicClass;
import com.centurylink.cgs.clicksynchronization.util.Environment;
import com.centurylink.cgs.clicksynchronization.util.Mailer;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;



@Service
public class ScheduleServiceImpl implements ScheduleService {
	public static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ScheduleServiceImpl.class);
	
	@Autowired
	private JobsDao jobsDao;
	
	@Autowired
	private Util util;
	
	@Autowired
	StatusPublishService statusPublishService;
	
	@Autowired
	UpdateTaskAssignmentExService updateTaskAssignmentExService;
	
	@Autowired 
	ProcessTaskExService processTaskExService;
	
	@Autowired 
	SynchronizeErrorService synchronizeErrorService;
	
	@Autowired 
	Configuration configuration;
	

	
	@Scheduled(fixedRate = 60000*5) // 1 minute 
	@Override
	public void refreshConfiguration() {
		configuration.refresh();
		SynchronizerCache.refresh();
		StatusEvaluatorCache.refresh();
	}
	
	@Scheduled(fixedRate = 1000) // 1 second 
	@Override
	public void publishStatus() throws ClickSynchronizationException {
		try {
			if ((configuration.isRunScheduledTasks() 
						|| Environment.isRunScheduledTasks()) 
						&& !Environment.isNotRunScheduledTasks())
				statusPublishService.publish();
		} catch (ClickSynchronizationException e) {
			LOG.error(e);
			util.saveDispatchLog(e);
		}

	}
	@Scheduled(fixedRate = 2000) // 2 second 
	@Override
	public void updateTaskAssignment() throws ClickSynchronizationException {
		try {
			if ((configuration.isRunScheduledTasks() 
					|| Environment.isRunScheduledTasks()) 
					&& !Environment.isNotRunScheduledTasks())
				updateTaskAssignmentExService.process();
		} catch (ClickSynchronizationException e) {
			LOG.error(e);
			util.saveDispatchLog(e);
		}

	}
	@Scheduled(fixedRate = 2000) // 2 second 
	@Override
	public void processTask() throws ClickSynchronizationException {
		try {
			if ((configuration.isRunScheduledTasks() 
					|| Environment.isRunScheduledTasks()) 
					&& !Environment.isNotRunScheduledTasks())
				processTaskExService.process();
		} catch (ClickSynchronizationException e) {
			LOG.error(e);
			util.saveDispatchLog(e);
		}

	}
	@Scheduled(fixedRate = 5000) // 5 seconds 
	@Override
	public void synchronizeErrors() throws ClickSynchronizationException {
		try {
			if ((configuration.isRunScheduledTasks() 
					|| Environment.isRunScheduledTasks()) 
					&& !Environment.isNotRunScheduledTasks())
				synchronizeErrorService.process();
		} catch (ClickSynchronizationException e) {
			LOG.error(e);
			util.saveDispatchLog(e);
		}

	}
	@Scheduled(fixedRate = 60000) // 1 minute 
	@Override
	public void scheduledSynchronizer() throws ClickSynchronizationException {
		String className = null;
		try {
			if ((configuration.isRunScheduledTasks() 
					|| Environment.isRunScheduledTasks()) 
					&& !Environment.isNotRunScheduledTasks()) {
				className = configuration.getScheduledSynchronizerClass();
				String source = jobsDao.getDynamicClassSource(className);
				ClickSynchronizer synchronizer = (ClickSynchronizer) DynamicClass.getInstance(className, source);
				synchronizer.synchronize(null);
			}
		} catch (ClickSynchronizationException e) {
				LOG.error(e);
				util.saveDispatchLog(e);
			
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), 
																		ex, 
																		AlarmId.SCHEDULE_SERVICE_IMPL_SCHEDULED_SYNCHRONIZER, 
																		new LogContext().add("className",className));
			LOG.error(exception);
		} 

	}
}
