package com.centurylink.cgs.clicksynchronization.exception;

import com.centurylink.cgs.dispatchcommon.exception.DispatchException;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

public class ClickSynchronizationException extends DispatchException {
	/**
	 *  Common Exception class for ClickSynchronization service
	 */
	private static final long serialVersionUID = 1L;

	public ClickSynchronizationException(String message, int alarmId, LogContext context) {
		super(message, alarmId, context);
	}
	public ClickSynchronizationException(String message, Throwable cause, int alarmId, LogContext context) {
		super(message, cause, alarmId, context);
	}

}
