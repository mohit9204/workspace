package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;

public interface RetryMessageService {
	public String retry(String correlationId) throws ClickSynchronizationException ;
	
}
