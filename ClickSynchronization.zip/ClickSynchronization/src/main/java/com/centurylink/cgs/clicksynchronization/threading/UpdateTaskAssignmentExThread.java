package com.centurylink.cgs.clicksynchronization.threading;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.centurylink.cgs.clicksynchronization.client.UpdateTaskAssignmentExClickClient;
import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.dao.JobsDaoImpl;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.UpdateTaskAssignmentEx;
import com.clicksoftware.UpdateTaskAssignmentExResponse;

public class UpdateTaskAssignmentExThread implements Runnable {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(UpdateTaskAssignmentExThread.class);
	
	Util util = Util.getInstance();
	
	JobsDao jobsDao = JobsDaoImpl.getInstance();
	
	UpdateTaskAssignmentExClickClient updateTaskAssignmentExClickClient = UpdateTaskAssignmentExClickClient.getInstance();
	
	Configuration configuration = Configuration.getInstance();

	@Override
	public void run() {
		List<Integer> list;
		try {
			list = jobsDao.getClickMessageIds(Constants.UPDATE_TASK_ASSIGNMENT_EX);
		} catch (ClickSynchronizationException e1) {
			LOG.error(e1);
			return;
		}
		HashMap<String, String> failedCorrelationIds = new HashMap<String, String>();
		String correlationId = null;
		for (Integer id : list) {
			LogContext context = new LogContext().add("id",id);
			try {
				String request = jobsDao.getClickSyncMessageRequest(id);
				UpdateTaskAssignmentEx clickRequest = RequestMarshaller.unMarshallUpdateTaskAssignmentEx(request);
				context.add(LogContextHelper.get(clickRequest));
				if (clickRequest != null && clickRequest.getTask() != null) {
					correlationId = clickRequest.getTask().getExternalRefID();
					if (failedCorrelationIds.containsKey(correlationId)) {
						LOG.info(context.setMessage("Skipping request prior failure"));
						jobsDao.retryClickSyncMessage(id);
						continue;
					}
				}
				UpdateTaskAssignmentExResponse response = updateTaskAssignmentExClickClient.updateTaskAssignmentEx(clickRequest);
				jobsDao.completeClickSyncMessage(id);
				LOG.info(context.setMessage("UpdateTaskAssignmentEx request sent to Click and CLICK_SYNC_MESSAGE record set to Completed"));
				configuration.setSecondsToPause(0); // Successful transaction, reset the delay value
			} catch (ClickSynchronizationException e) {
				if (correlationId != null)
					failedCorrelationIds.put(correlationId, correlationId);
				e.getContext().add(context);
				LOG.error(e);	
				util.saveDispatchLog(e);
				try {
				jobsDao.failClickSyncMessage(id);
				jobsDao.insertClickSyncError(id, e.getMessage());
				} catch (ClickSynchronizationException ex) {
					LOG.error(ex);
			}
		}
	}


	}

}
