package com.centurylink.cgs.clicksynchronization.client;

import java.io.IOException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.ProcessTaskExResponse;
import com.clicksoftware.UpdateTaskAssignmentEx;
import com.clicksoftware.UpdateTaskAssignmentExResponse;
import com.clicksoftware.serviceoptimizeservice.OptionalParameters;

@Component
public class UpdateTaskAssignmentExClickClient extends WebServiceGatewaySupport {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(UpdateTaskAssignmentExClickClient.class);
	
	private static UpdateTaskAssignmentExClickClient instance = new UpdateTaskAssignmentExClickClient();
	
	private UpdateTaskAssignmentExClickClient() {
		
	}
	public static UpdateTaskAssignmentExClickClient getInstance() {
		return instance;
	}

	@Value("${click.updatetaskassignmentex.soap.action}")
	private String clickSoapAction;
	
	public UpdateTaskAssignmentExResponse updateTaskAssignmentEx(String request) throws ClickSynchronizationException {
		LogContext context = new LogContext().add("request",request);
		try {
			return updateTaskAssignmentEx(RequestMarshaller.unMarshallUpdateTaskAssignmentEx(request));
		} catch (Exception e) {
			ClickSynchronizationException exception = new ClickSynchronizationException(e.getMessage(), e, AlarmId.UPDATE_TASK_ASSIGNMENT_EX_CLICK_CLIENT_UPDATE_TASK_ASSIGNMENT_EX, context);
			throw exception;
		}

	}
	public UpdateTaskAssignmentExResponse updateTaskAssignmentEx(UpdateTaskAssignmentEx request) throws ClickSynchronizationException {
		LogContext context = LogContextHelper.get(request);
		try {
			WebServiceTemplate wsTemplate = getWebServiceTemplate();		
			UpdateTaskAssignmentExResponse response = (UpdateTaskAssignmentExResponse) wsTemplate.marshalSendAndReceive(request, 
					new WebServiceMessageCallback() {
				@Override
				public void doWithMessage(WebServiceMessage requestMessage) throws IOException, TransformerException {
					try {
						SoapMessage soapMsg = ((SoapMessage) requestMessage);
						// get the header from the SOAP message		
						SoapHeader soapHeader = soapMsg.getSoapHeader();
						soapMsg.setSoapAction(clickSoapAction);					
						// create the header element
						OptionalParameters optionalParameters = new OptionalParameters();
						optionalParameters.setCallerIdentity(Constants.CALLER_IDENTY); 
						optionalParameters.setErrorOnNonExistingDictionaries(true);
						// create a marshaller
						JAXBContext context = JAXBContext.newInstance(OptionalParameters.class);
						Marshaller marshaller = context.createMarshaller();
						// marshal the headers into the specified result
						marshaller.marshal(optionalParameters, soapHeader.getResult());
					} catch (JAXBException  e) {
						throw new TransformerException("Error while marshalling");
					}
				}
			});
			LOG.trace("UpdateTaskAssignmentExClickClient::updateTaskAssignmentEx::end");	
			return response;
		} catch (Exception e) {
			ClickSynchronizationException exception = new ClickSynchronizationException(e.getMessage(), e, AlarmId.UPDATE_TASK_ASSIGNMENT_EX_CLICK_CLIENT_UPDATE_TASK_ASSIGNMENT_EX, context);
			throw exception;
		}
	}
}
