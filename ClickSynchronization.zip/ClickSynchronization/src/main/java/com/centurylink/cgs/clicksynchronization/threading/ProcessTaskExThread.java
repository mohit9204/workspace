package com.centurylink.cgs.clicksynchronization.threading;

import java.util.HashMap;
import java.util.List;

import com.centurylink.cgs.clicksynchronization.client.ProcessTaskExClickClient;
import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.dao.JobsDaoImpl;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.ProcessTaskExResponse;

public class ProcessTaskExThread implements Runnable {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ProcessTaskExThread.class);


	Util util = Util.getInstance();
	
	JobsDao jobsDao = JobsDaoImpl.getInstance();
	
	ProcessTaskExClickClient processTaskExClickClient = ProcessTaskExClickClient.getInstance();
	
	Configuration configuration = Configuration.getInstance();
	
	@Override
	public void run() {
		List<Integer> list;
		try {
			list = jobsDao.getClickMessageIds(Constants.PROCESS_TASK_EX);
		} catch (ClickSynchronizationException e1) {
			LOG.error(e1);
			return;
		}
		
		HashMap<String, String> failedCorrelationIds = new HashMap<String, String>();
		String correlationId = null;
		for (Integer id : list) {
			LogContext context = new LogContext();
			ProcessTaskEx processTaskEx = null;
			try {
				String request = jobsDao.getClickSyncMessageRequest(id);
				processTaskEx = RequestMarshaller.unMarshallProcessTaskEx(request);
				context = LogContextHelper.get(processTaskEx);
				if (processTaskEx != null && processTaskEx.getTask() != null) {
					correlationId = processTaskEx.getTask().getExternalRefID();
					if (failedCorrelationIds.containsKey(correlationId)) {
						LOG.info(context.setMessage("Skipping request prior failure"));
						jobsDao.retryClickSyncMessage(id);
						continue;
					}
				}
				ProcessTaskExResponse response = processTaskExClickClient.processTaskEx(processTaskEx);
				if (response != null && response.getSchedulingError() != null && response.getSchedulingError().getError() != null && response.getSchedulingError().getError().getErrorDescription() != null) {
					String message = response.getSchedulingError().getError().getErrorDescription();
					throw new ClickSynchronizationException(message, AlarmId.PROCESS_TASK_EX_SERVICE_IMPL_PROCESS, context);
				}
				
				if (processTaskEx != null 
						&& processTaskEx.getTask() != null 
						&& processTaskEx.getTask().getStatus() != null 
						&& processTaskEx.getTask().getStatus().getName() != null
						&& processTaskEx.getTask().getStatus().getName().equals(Constants.STATUS_CANCELLED)) {
					LOG.info(context.setMessage("ProcessTaskEx request sent to Click and CLICK_SYNC_MESSAGE record set to Complete"));
					jobsDao.completeClickSyncMessage(id);
				}
				else {
					LOG.info(context.setMessage("ProcessTaskEx request sent to Click and CLICK_SYNC_MESSAGE record set to Synchronized"));
					jobsDao.synchronizeClickSyncMessage(id);
				}
				configuration.setSecondsToPause(0); // Successful transaction, reset the delay value
			} catch (ClickSynchronizationException e) {
				if (correlationId != null)
					failedCorrelationIds.put(correlationId, correlationId);
				e.getContext().add(context);
				LOG.error(e);	
				util.saveDispatchLog(e);
				try {
				jobsDao.failClickSyncMessage(id);
				jobsDao.insertClickSyncError(id, e.getMessage());
				} catch (ClickSynchronizationException ex) {
					LOG.error(ex);
				}
			}
		}


	}

}
