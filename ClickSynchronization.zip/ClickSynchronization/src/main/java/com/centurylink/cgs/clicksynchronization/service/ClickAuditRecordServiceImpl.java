package com.centurylink.cgs.clicksynchronization.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityDynamicAudit;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityLimitAuditRecord;

@Service
public class ClickAuditRecordServiceImpl implements ClickAuditRecordService {

	@Autowired 
	private JobsDao jobsDao;
	
	public void processCTLCapacityDynamicAudit(CTLCapacityDynamicAudit clickAuditRecord)
			throws ClickSynchronizationException {
		jobsDao.insertCTLCapacityDynamicAudit(clickAuditRecord);
	}
	public void processCTLCapacityLimitAuditRecord(CTLCapacityLimitAuditRecord clickAuditRecord)
			throws ClickSynchronizationException {
		jobsDao.insertCTLCapacityLimitAuditRecord(clickAuditRecord);
	}
}
