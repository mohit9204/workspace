package com.centurylink.cgs.clicksynchronization.service;

import org.apache.commons.dbcp2.BasicDataSource;

import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.dispatchcommon.healthcheck.VersionHealthInfo;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;

public class ClickSynchronizationHealthServiceImpl implements ClickSynchronizationHealthService {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ClickSynchronizationHealthServiceImpl.class);

	@Override
	public VersionHealthResponse getHealthDetails() {
		

		VersionHealthResponse healthResponse = new VersionHealthResponse();
		BaseResponse base = new BaseResponse();
		healthResponse.setBaseResponse(base);
		boolean success = true;

		LogContext context = new LogContext().appendMessage("Health Check");
		LOG.info(context);

		if (!VersionHealthInfo.setVersionInfo(healthResponse, Constants.APPLICATION_SERVICE_NAME))
			success = false;	


		if (!success) {
			base.setResponseStatus(BaseResponse.responseStatusValues.Failure);
			base.setMessage("Health Check Failed");
			base.setReasonCode(-1);
		} else {
			base.setResponseStatus(BaseResponse.responseStatusValues.Success);
			base.setMessage("Health Check Succeeded");
			base.setReasonCode(1);
		}
		context.add("status", base.getMessage());
		LOG.info(context);
		return healthResponse;	

	}

}
