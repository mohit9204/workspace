package com.centurylink.cgs.clicksynchronization.model;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.DynamicClass;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

@Component
public class StatusEvaluatorCache {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(StatusEvaluatorCache.class);

	private static StatusEvaluatorCache instance = new StatusEvaluatorCache();
	
	private StatusEvaluatorCache() {
		
	}
	public static StatusEvaluatorCache getInstance() {
		return instance;
	}
	
	@Autowired
	private  JobsDao jobsDao;

	private static HashMap<String, UpstreamStatusEvaluator> map = new HashMap<String, UpstreamStatusEvaluator>();
	private static Object mapMutex = new Object();
	

	public UpstreamStatusEvaluator getUpstreamStatusEvaluatorObject(String statusEvaluatorClass) throws ClickSynchronizationException {
		LogContext context = new LogContext().add("synchronizerClass", statusEvaluatorClass);
		
		synchronized (mapMutex) {
			if (map.get(statusEvaluatorClass) != null)
				return map.get(statusEvaluatorClass);
			String source = null;
			if (statusEvaluatorClass != null)
				source = jobsDao.getDynamicClassSource(statusEvaluatorClass);
			if (statusEvaluatorClass == null || source == null)
				throw new ClickSynchronizationException(Constants.ERROR_UPSTREAM_STATUS_EVALUATOR, AlarmId.STATUS_EVALUATOR_CACHE_GET_UPSTREAM_STATUS_EVALUATOR_OBJECT_NO_CLASS, context);
			try {
				LOG.info(context.setMessage("Loading class from table"));
				UpstreamStatusEvaluator object = (UpstreamStatusEvaluator) DynamicClass.getInstance(statusEvaluatorClass, source);
				map.put(statusEvaluatorClass, object);
				return object;
			} catch (Exception e) {
				throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.STATUS_EVALUATOR_CACHE_GET_UPSTREAM_STATUS_EVALUATOR_OBJECT, context);			
			}
			
		}
	}
	public static void refresh() {
		synchronized (mapMutex) {
			map.clear();
		}
	}
}
