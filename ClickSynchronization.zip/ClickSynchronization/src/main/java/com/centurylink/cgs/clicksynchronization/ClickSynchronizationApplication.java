package com.centurylink.cgs.clicksynchronization;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.sql.DataSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import org.springframework.ws.transport.http.HttpComponentsMessageSender.RemoveSoapHeadersInterceptor;

import com.centurylink.cgs.clicksynchronization.client.ClickInterceptor;
import com.centurylink.cgs.clicksynchronization.client.DispatchGroupClient;
import com.centurylink.cgs.clicksynchronization.client.GetTaskClient;
import com.centurylink.cgs.clicksynchronization.client.ProcessTaskExClickClient;
import com.centurylink.cgs.clicksynchronization.client.UpdateTaskAssignmentExClickClient;
import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.dao.JobsDaoImpl;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.StatusEvaluatorCache;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerCache;
import com.centurylink.cgs.clicksynchronization.service.ClickAuditRecordService;
import com.centurylink.cgs.clicksynchronization.service.ClickAuditRecordServiceImpl;
import com.centurylink.cgs.clicksynchronization.service.ClickSynchronizationHealthService;
import com.centurylink.cgs.clicksynchronization.service.ClickSynchronizationHealthServiceImpl;
import com.centurylink.cgs.clicksynchronization.service.ClickSynchronizationVersionService;
import com.centurylink.cgs.clicksynchronization.service.ClickSynchronizationVersionServiceImpl;
import com.centurylink.cgs.clicksynchronization.service.ProcessTaskExService;
import com.centurylink.cgs.clicksynchronization.service.ProcessTaskExServiceImpl;
import com.centurylink.cgs.clicksynchronization.service.RetryMessageService;
import com.centurylink.cgs.clicksynchronization.service.RetryMessageServiceImpl;
import com.centurylink.cgs.clicksynchronization.service.StatusPublishService;
import com.centurylink.cgs.clicksynchronization.service.StatusPublishServiceImpl;
import com.centurylink.cgs.clicksynchronization.service.SynchronizeErrorService;
import com.centurylink.cgs.clicksynchronization.service.SynchronizeErrorServiceImpl;
import com.centurylink.cgs.clicksynchronization.service.UpdateTaskAssignmentExService;
import com.centurylink.cgs.clicksynchronization.service.UpdateTaskAssignmentExServiceImpl;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Mailer;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.encryption.EncryptedPasswordDataSource;
import com.centurylink.cgs.dispatchcommon.encryption.EncryptionHelper;
import com.centurylink.cgs.dispatchcommon.reference.DispatchReference;



@EnableScheduling
@ComponentScan(basePackages = "com.centurylink.cgs.clicksynchronization")
@SpringBootApplication
public class ClickSynchronizationApplication extends SpringBootServletInitializer  {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ClickSynchronizationApplication.class);
	
	@Value("${jobs.datasource.username}")
	private String jobsUsername;

	@Value("${jobs.datasource.encryptedPassword}")
	private String jobsPassword;
	
	@Value("${client.ssl.trust-store}")
	private Resource trustStore;

	@Value("${client.ssl.trust-store-password}")
	private String trustStorePassword;
	
	
	public static void main(String[] args) {
		LOG.trace("ClickSynchronization::main::start");
		SpringApplication.run(ClickSynchronizationApplication.class, args);

		LOG.info("  >>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		LOG.info("  >>    Click Synchronization Service is STARTED   <<");
		LOG.info("  >>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
	}

	@Primary
	@Bean(name = "jobsDataSource")
	@ConfigurationProperties(prefix = "jobs.datasource")
	public DataSource dataSource() {
		EncryptedPasswordDataSource source = new EncryptedPasswordDataSource();
		source.setUsername(jobsUsername);
		source.setEncryptedPassword(jobsPassword);
		return source;
	}

	@Bean(name = "jobsJdbc") 
	public JdbcTemplate jdbcTemplate(DataSource jobsDataSource) { 
		return new JdbcTemplate(jobsDataSource); 
	} 
	@Bean
	public ClickAuditRecordService clickAuditRecordService() {
		return new ClickAuditRecordServiceImpl();
	}
	@Bean
	@DependsOn("jobsDataSource")
	public JobsDao jobsDao() {
		return JobsDaoImpl.getInstance();
	}
	@Bean
    @DependsOn("jobsDataSource")
	public Configuration configuration() {
		return  Configuration.getInstance();
	}
	@Bean
	public Util util() {
		return Util.getInstance();
	}
	@Bean 
	public DispatchGroupClient dispatchGroupClient() throws Exception {
		DispatchGroupClient client =  DispatchGroupClient.getInstance();
		client.setEndpoint(configuration().getDispatchGroupEndpoint());
		return client;
	}
	@Bean
	public StatusPublishService statusPublishService() {
		return new StatusPublishServiceImpl();
	}
	@Bean
	public UpdateTaskAssignmentExService updateTaskAssignmentExService() {
		return new UpdateTaskAssignmentExServiceImpl();
	}
	@Bean
	public ProcessTaskExService processTaskExService() {
		return new ProcessTaskExServiceImpl();
	}
	@Bean
	public SynchronizeErrorService synchronizeErrorService() {
		return new SynchronizeErrorServiceImpl();
	}
	@Bean
	public ClickSynchronizationHealthService clickSynchronizationHealthService() {
		return new ClickSynchronizationHealthServiceImpl();
	}
	@Bean
	public ClickSynchronizationVersionService clickSynchronizationVersionService() {
		return new ClickSynchronizationVersionServiceImpl();
	}
	@Bean 
	public RetryMessageService retryMessageService() {
		return new RetryMessageServiceImpl();
	}
	@Bean
	public GetTaskClient getTaskClient(Jaxb2Marshaller clickScheduleMarshaller) throws Exception {
		GetTaskClient client = GetTaskClient.getInstance();	
		client.setMarshaller(clickScheduleMarshaller);
		client.setUnmarshaller(clickScheduleMarshaller);
		client.setMessageSender(messageSender());	
		client.setDefaultUri(configuration().getClickScheduleServiceEndpoint());
		ClientInterceptor[] interceptors  = client.getInterceptors();
		interceptors =  (ClientInterceptor[]) ArrayUtils.add(interceptors, new ClickInterceptor());
		client.setInterceptors(interceptors);
		return client;
	}
	@Bean
	public ProcessTaskExClickClient processTaskExClickClient(Jaxb2Marshaller clickScheduleMarshaller) throws Exception {
		ProcessTaskExClickClient client = ProcessTaskExClickClient.getInstance();	
		client.setMarshaller(clickScheduleMarshaller);
		client.setUnmarshaller(clickScheduleMarshaller);
		client.setMessageSender(messageSender());	
		client.setDefaultUri(configuration().getClickScheduleServiceEndpoint());
		ClientInterceptor[] interceptors  = client.getInterceptors();
		interceptors =  (ClientInterceptor[]) ArrayUtils.add(interceptors, new ClickInterceptor());
		client.setInterceptors(interceptors);
		return client;
	}
	@Bean
	public UpdateTaskAssignmentExClickClient updateTaskAssignmentExClickClient(Jaxb2Marshaller clickScheduleMarshaller) throws Exception {
		UpdateTaskAssignmentExClickClient client = UpdateTaskAssignmentExClickClient.getInstance();	
		client.setMarshaller(clickScheduleMarshaller);
		client.setUnmarshaller(clickScheduleMarshaller);
		client.setMessageSender(messageSender());	
		client.setDefaultUri(configuration().getClickScheduleServiceEndpoint());
		ClientInterceptor[] interceptors  = client.getInterceptors();
		interceptors =  (ClientInterceptor[]) ArrayUtils.add(interceptors, new ClickInterceptor());
		client.setInterceptors(interceptors);
		return client;
	}
	@Bean
	public Jaxb2Marshaller clickScheduleMarshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPaths("com.clicksoftware");
		return marshaller;
	}
	@Bean(name = "clickMessageSender")
	public HttpComponentsMessageSender messageSender() throws Exception {
		HttpComponentsMessageSender httpComponentsMessageSender = new HttpComponentsMessageSender();
		httpComponentsMessageSender.setHttpClient(httpClient());
		return httpComponentsMessageSender;
	}
	@Bean
	public SynchronizerCache synchronizerCache() {
		return new SynchronizerCache();
	}
	@Bean
	public StatusEvaluatorCache statusEvaluatorCache () {
		return  StatusEvaluatorCache.getInstance();
	}
	@Bean
	public Mailer mailer() {
		return  Mailer.getInstance();
	}
	public HttpClient httpClient() throws Exception {
		new DispatchReference();
		int connectTimeout = configuration().getClickConnectionTimeout();
		int readTimeout = configuration().getClickReadTimeout();
		int maxConnection = configuration().getMaxConnections();
		int maxConnectPerHost = configuration().getMaxConnectionsPerHost();
		LOG.info("Max connection Value at startUp "+maxConnection);
		LOG.info("Read Time out Value  at startUp "+readTimeout);
		CredentialsProvider provider = new BasicCredentialsProvider();
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(configuration().getClickUserName(), EncryptionHelper.decrypt(configuration().getClickEncryptedPassword()));
		provider.setCredentials(AuthScope.ANY, credentials);	
		RequestConfig requestConfig = RequestConfig.custom()
				   .setConnectTimeout(connectTimeout)
				   .setConnectionRequestTimeout(connectTimeout)
				   .setSocketTimeout(readTimeout)
				   .build();
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
	    connectionManager.setMaxTotal(maxConnection);
	    connectionManager.setDefaultMaxPerRoute(maxConnectPerHost);
		HttpClient httpclient = HttpClientBuilder.create().setConnectionManager(connectionManager).setDefaultCredentialsProvider(provider).setSSLSocketFactory(sslConnectionSocketFactory())
				.addInterceptorFirst(new RemoveSoapHeadersInterceptor()).setDefaultRequestConfig(requestConfig).build();
		return httpclient;
	}
	public SSLConnectionSocketFactory sslConnectionSocketFactory() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException  {
		// NoopHostnameVerifier essentially turns hostname verification off as otherwise following error
		// is thrown: java.security.cert.CertificateException: No name matching localhost found
		return new SSLConnectionSocketFactory(sslContext(), NoopHostnameVerifier.INSTANCE);
	}
	public SSLContext sslContext() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException  {
		File tempFile = File.createTempFile("truststore", "jks");
		tempFile.deleteOnExit();
		FileOutputStream out = new FileOutputStream(tempFile);
		IOUtils.copy(trustStore.getInputStream(), out);
		return SSLContextBuilder.create()
				.loadTrustMaterial(tempFile, trustStorePassword.toCharArray()).build();
	}

}
