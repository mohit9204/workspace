package com.centurylink.cgs.clicksynchronization.service;

import java.net.URI;
import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.dispatchcommon.encryption.EncryptionHelper;
import com.centurylink.cgs.dispatchcommon.healthcheck.VersionHealthInfo;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;

public class ClickSynchronizationVersionServiceImpl implements ClickSynchronizationVersionService {

	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(VersionHealthResponse.class);

	private final static String ENVIRONMENT_KEY = "SPRING_PROFILES_ACTIVE";

	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 

	@Value("${client.timeout}")
	private int timeout;

	@Autowired
	private Configuration configuration;
		
	public VersionHealthResponse getVersionDetails() throws Exception{
		

		VersionHealthResponse healthResponse = new VersionHealthResponse();
		BaseResponse base = new BaseResponse();
		healthResponse.setBaseResponse(base);
		boolean success = true;
		BasicDataSource basicDataSrc  = (BasicDataSource) dataSource; 

		LogContext context = new LogContext().appendMessage("Version and Health Check").add("DB", "jobsDataSource");
		LOG.info(context);

		if (!VersionHealthInfo.setVersionInfo(healthResponse, Constants.APPLICATION_SERVICE_NAME))
			success = false;	

		if (!VersionHealthInfo.addDBConnection(healthResponse, basicDataSrc))
			success = false;

		if (!success) {
			base.setResponseStatus(BaseResponse.responseStatusValues.Failure);
			base.setMessage("Health Check Failed");
			base.setReasonCode(-1);
		} else {
			base.setResponseStatus(BaseResponse.responseStatusValues.Success);
			base.setMessage("Health Check Succeeded");
			base.setReasonCode(1);
		}

		String clickStatus = "NOT CHECKED";

		try {
			if (checkClickService()) {
				clickStatus = "SUCCESS";
			} else {
				clickStatus = "FAILED";
				success = false;
			}
		} catch (Exception e) {
			clickStatus = "FAILED: " + e.getMessage();
			success = false;
		}
		String clickEndpoint = String.format("%s://%s/%s", 
													configuration.getClickHealthScheme(), 
													configuration.getClickHealthHost(),
													configuration.getClickHealthPath());
		if (!VersionHealthInfo.addServiceEndpoint(healthResponse, 
													clickEndpoint,
													configuration.getClickUserName(), 
													clickStatus))
			success = false;
		
		LOG.info("VersionHealthCheck output: \n" + healthResponse.toJSONString());
		return healthResponse;	
	}

	private boolean checkClickService() throws Exception {

		URI clickURI = new URIBuilder()
				.setScheme(configuration.getClickHealthScheme())
				.setHost(configuration.getClickHealthHost())
				.setPath(configuration.getClickHealthPath())
				.setUserInfo(configuration.getClickUserName(),EncryptionHelper.decrypt(configuration.getClickEncryptedPassword()))
				.build();
				
		HttpGet httpget = new HttpGet(clickURI);
		RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectTimeout(timeout)
				.setSocketTimeout(timeout).setConnectionRequestTimeout(timeout).build();

		HttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(defaultRequestConfig).build();
		HttpResponse response = httpClient.execute(httpget);

		String responseString = new BasicResponseHandler().handleResponse(response);
		LOG.info("Click HealthCheck Response: " + responseString);
		StatusLine statusLine = response.getStatusLine();
		if (statusLine.getStatusCode() >= 300) {
			return false;
		}
		return true;
	}
	


}
