package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;

public interface ProcessTaskExService {
	public void process() throws ClickSynchronizationException;
}
