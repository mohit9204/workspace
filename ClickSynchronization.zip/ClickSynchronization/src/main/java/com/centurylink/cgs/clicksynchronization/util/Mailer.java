package com.centurylink.cgs.clicksynchronization.util;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;


public class Mailer {
	
	@Autowired
    private JavaMailSender sender;

	private static Mailer instance = new Mailer();
	
	private Mailer() {
	}
	
	public static Mailer getInstance() {
		return instance;
	}


	public void send(	String subject, 
						String mailTo, 
						String mailFrom, 
						String messageBody,
						String attachmentName, 
						String attachmentContent) throws ClickSynchronizationException {
		 MimeMessage message = sender.createMimeMessage();

	     
	        try {
	   	     	MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED, "UTF-8");
	            helper.setTo(InternetAddress.parse(mailTo));
	            helper.setText(messageBody);
	            helper.setSubject(subject);
	            helper.setFrom(mailFrom);
	            BodyPart messageBodyPart = new MimeBodyPart();
	            messageBodyPart.setText(messageBody);
	            Multipart multipart = new MimeMultipart();
	            multipart.addBodyPart(messageBodyPart);
	            messageBodyPart = new MimeBodyPart();
	            messageBodyPart.setFileName(attachmentName);
	            messageBodyPart.setText(attachmentContent);
	            multipart.addBodyPart(messageBodyPart);
	            message.setContent(multipart);
	            sender.send(message);
	        } catch (MessagingException ex) {
				LogContext logContext = new LogContext().add("mailTo",mailTo);
				ClickSynchronizationException e = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.MAILER_SEND,
						logContext );
				throw e;
			}
	}

}
