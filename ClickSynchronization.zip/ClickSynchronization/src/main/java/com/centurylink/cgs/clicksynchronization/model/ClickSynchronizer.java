package com.centurylink.cgs.clicksynchronization.model;

import com.centurylink.cgs.clicksynchronization.client.ProcessTaskExClickClient;
import com.centurylink.cgs.clicksynchronization.client.UpdateTaskAssignmentExClickClient;
import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.dao.JobsDaoImpl;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.ClickHelper;
import com.centurylink.cgs.clicksynchronization.helper.EmailHelper;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;

public abstract class ClickSynchronizer {
	
	protected UpdateTaskAssignmentExClickClient updateTaskAssignmentExClickClient = UpdateTaskAssignmentExClickClient.getInstance();
	
	protected ProcessTaskExClickClient processTaskExClickClient = ProcessTaskExClickClient.getInstance();
	
	protected JobsDao jobsDao = JobsDaoImpl.getInstance();

	protected Configuration configuration = Configuration.getInstance();
	
	protected Util util = Util.getInstance();
	
	protected ClickHelper clickHelper = ClickHelper.getInstance();
	
	protected EmailHelper emaliHelper = EmailHelper.getInstance();
	
	public abstract void synchronize(FailedMessage failure) throws ClickSynchronizationException;


}
