package com.centurylink.cgs.clicksynchronization.helper;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.centurylink.cgs.clicksynchronization.client.ProcessTaskExClickClient;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.Assignment;
import com.clicksoftware.Assignment.Engineers;
import com.clicksoftware.DistrictReference;
import com.clicksoftware.EngineerReference;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.ProcessTaskExResponse;
import com.clicksoftware.Task;
import com.clicksoftware.TaskStatusReference;
import com.clicksoftware.UpdateTaskAssignmentEx;

public class ClickHelper {
	
private static ClickHelper instance = new ClickHelper();
	
	private ClickHelper() {
	}
	
	public static ClickHelper getInstance() {
		return instance;
	}
	
	ProcessTaskExClickClient processTaskExClickClient;
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ClickHelper.class);
	
public UpdateTaskAssignmentEx convertProcessTaskExToUpdateTaskAssignmentExForCancel(ProcessTaskEx cancelMessage) throws ClickSynchronizationException {
		
		
	UpdateTaskAssignmentEx statusMessage = new UpdateTaskAssignmentEx();
		Task task = new Task();

		task.setCallID(cancelMessage.getTask().getCallID());
		task.setNumber(cancelMessage.getTask().getNumber());
		task.setExternalRefID(cancelMessage.getTask().getExternalRefID());
		task.setCTLDispatchReady(cancelMessage.getTask().isCTLDispatchReady());
		task.setCTLDispatchCallID(cancelMessage.getTask().getCTLDispatchCallID());
		task.setCTLOnHold(cancelMessage.getTask().isCTLOnHold());
		task.setStatus(new TaskStatusReference());

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			String updateTimestamp = sdf.format(new Date());
			XMLGregorianCalendar xmlGregorianCalendarUpdateTime;
			xmlGregorianCalendarUpdateTime = DatatypeFactory.newInstance().newXMLGregorianCalendar(updateTimestamp);
			statusMessage.setUpdateTime(xmlGregorianCalendarUpdateTime);
		} catch (DatatypeConfigurationException e) {
			LogContext context = new LogContext().setMessage("DatatypeConfigurationException exception occured").add("exception", e.getMessage());
			LOG.info(context);
		}

		statusMessage.setTask(task);
		statusMessage.setDispatchNextAssignment(false);
		statusMessage.setDispatchHorizon(14400);

		return statusMessage;
	}
	
	public  ProcessTaskExResponse allocateTask(UpdateTaskAssignmentEx message,List<Map<String, Object>> techDetailList) throws ClickSynchronizationException {
		processTaskExClickClient = ProcessTaskExClickClient.getInstance();
				Date startDate = (Date)techDetailList.get(0).get("ASSIGNMENT_START");
				Date finishDate = (Date)techDetailList.get(0).get("ASSIGNMENT_FINISH");
				String techId = (String) techDetailList.get(0).get("TECH_ID");
				String district = (String) techDetailList.get(0).get("DISTRICT");
				LOG.info(new LogContext().setMessage("Allocate task").add("correlationId",message.getTask().getCallID()).add("TechId",techId));
				ProcessTaskEx request = createAllocateTaskRequest(message, startDate, finishDate, techId, district);
				ProcessTaskExResponse result = processTaskExClickClient.processTaskEx(request);
				return result;
		
	}
	public ProcessTaskEx createAllocateTaskRequest(UpdateTaskAssignmentEx message, Date startDate, Date EndDate, String tech, String district) throws ClickSynchronizationException {
		ProcessTaskEx processEx = new ProcessTaskEx();
		Task task = new Task();
		task.setNumber(message.getTask().getNumber());
		task.setExternalRefID(message.getTask().getExternalRefID());

		XMLGregorianCalendar xmlGregorianCalendarStart =null;
		XMLGregorianCalendar xmlGregorianCalendarFinish =null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			xmlGregorianCalendarStart = DatatypeFactory.newInstance().newXMLGregorianCalendar(sdf.format(startDate));
			xmlGregorianCalendarFinish = DatatypeFactory.newInstance().newXMLGregorianCalendar(sdf.format(EndDate));
		} catch (DatatypeConfigurationException e) {
			LogContext context = new LogContext().setMessage("DatatypeConfigurationException exception occured").add("exception", e.getMessage());
			LOG.info(context);
		}
		
		Assignment assignment = new Assignment();
		assignment.setStart(xmlGregorianCalendarStart);
		assignment.setFinish(xmlGregorianCalendarFinish);
		
		Engineers engineers = new Engineers();
		EngineerReference engineerRef = new EngineerReference();
		engineerRef.setID(tech);
		DistrictReference disRef = new DistrictReference();
		disRef.setName(district);
		engineerRef.setDistrict(disRef);
		engineers.getEngineer().add(engineerRef);
		assignment.setEngineers(engineers);
		
		processEx.setTask(task);
		processEx.setAssignment(assignment);
		processEx.setReturnAssignment(true);
		processEx.setReturnSchedulingError(true);

		return processEx;
	}

}
