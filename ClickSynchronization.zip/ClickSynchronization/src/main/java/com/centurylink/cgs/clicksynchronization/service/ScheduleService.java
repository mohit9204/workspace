package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;

public interface ScheduleService {
	public void refreshConfiguration();
	public void publishStatus() throws ClickSynchronizationException;
	public void updateTaskAssignment() throws ClickSynchronizationException;
	public void processTask() throws ClickSynchronizationException;
	public void synchronizeErrors() throws ClickSynchronizationException;
	public void scheduledSynchronizer() throws ClickSynchronizationException;
}
