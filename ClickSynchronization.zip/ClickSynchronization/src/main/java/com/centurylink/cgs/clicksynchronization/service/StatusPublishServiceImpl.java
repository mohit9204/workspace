package com.centurylink.cgs.clicksynchronization.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.threading.StatusPublishThread;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

@Service
public class StatusPublishServiceImpl implements StatusPublishService {

	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(StatusPublishServiceImpl.class);


	@Autowired
	private Configuration configuration;
	
	private static boolean isRunning = false;
	
	@Override
	public void publish() throws ClickSynchronizationException {
		if (isRunning) {
			LOG.info("Previous process is still running");
			return;
		}
		try {
			isRunning = true;
			int numberOfThreads = configuration.getNumberOfStatusPublishThreads();
			List<Thread> threads = new ArrayList<Thread>();
			LOG.info(new LogContext().setMessage("Starting StatusPublish threads").add("numberOfThreads",numberOfThreads));
			for (int i = 0; i < numberOfThreads; ++i) {
				Thread thread = new Thread(new StatusPublishThread());
				thread.start();
				threads.add(thread);
			}
			for (Thread thread : threads) {
				try {thread.join();} catch (InterruptedException e) {}
			}
		} finally {
			isRunning = false;
		}

	}
}
