package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;

public interface UpdateTaskAssignmentExService {
	public void process() throws ClickSynchronizationException;
}
