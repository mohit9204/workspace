package com.centurylink.cgs.clicksynchronization.client;

import org.springframework.web.client.RestTemplate;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchgroupinterface.AssignmentUpdateResult;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;

public class DispatchGroupClient {
	public static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(DispatchGroupClient.class);

	private String endpoint;
	
	private static DispatchGroupClient instance = new DispatchGroupClient();
	
	private DispatchGroupClient() {

	}
	
	public static DispatchGroupClient getInstance() {
		return instance;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public AssignmentUpdateResult post(CTLAssignmentUpdate request) throws ClickSynchronizationException {		
		try {
			RestTemplate restTemplate = new RestTemplate();
			String requestString = RequestMarshaller.marshall(request);
			// TODO - set timeouts
			AssignmentUpdateResult result = restTemplate.postForObject(endpoint, requestString, AssignmentUpdateResult.class);
	        return result;
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.DISPATCH_GROUP_CLIENT_POST, LogContextHelper.get(request));
		} 
	}
	public AssignmentUpdateResult post(String request) throws ClickSynchronizationException {		
		try {
			RestTemplate restTemplate = new RestTemplate();
			// TODO - set timeouts
			String result = restTemplate.postForObject(endpoint, request, String.class);
	        return RequestMarshaller.unmarshallAssignmentUpdateResult(result);
		} catch (Exception e) {
			throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.DISPATCH_GROUP_CLIENT_POST, new LogContext().add("request",request));
		} 
	}
}
