package com.centurylink.cgs.clicksynchronization.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;

public class FailedMessageRowMapper implements RowMapper<FailedMessage> {
	@Override
	public FailedMessage mapRow(ResultSet rs, int rowNum) throws SQLException {
		FailedMessage result = new FailedMessage();
		result.setErrorMessageId(rs.getInt("ERROR_MESSAGE_ID"));
		result.setId(rs.getInt("MESSAGE_ID"));
		result.setErrorMessage(rs.getString("ERROR_MESSAGE_VAL"));
		result.setMessageType(rs.getString("MESSAGE_TYP"));
		result.setMessage(rs.getString("MESSAGE_VAL"));
		result.setCorrelationId(rs.getString("CORRELATION_ID"));
		return result;
	}
}