package com.centurylink.cgs.clicksynchronization.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchlog.DispatchLog;

public class Util {
	
	private static Util instance = new Util();
	
	private Util() {
	}
	
	public static Util getInstance() {
		return instance;
	}
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected  DataSource dataSource; 
	
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(Util.class);
	
	public String getStackTraceString(Exception e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}
	public void saveDispatchLog(ClickSynchronizationException exception) {
		DispatchLog log = new DispatchLog();
		log.setServiceName(Constants.APPLICATION_SERVICE_NAME);
		if (exception != null) {
			String correlationId = exception.getContext().getValue("correlationId");
			log.setAlarmId(exception.getAlarmId());
			log.setAlarmMessage(exception.getMessage());
			log.setCorrelationId(correlationId+"");
			if (exception.getContext() != null){
				log.setAlarmContext(exception.getContext().toString());
			}
			log.setErrorMessage(exception.getMessage());
			log.setErrorNumber(exception.getAlarmId());
			log.setStackTrace(getStackTraceString(exception));
		}
		log.setErrorNumber(exception.getAlarmId());

		try {
			log.save(dataSource);
		} catch (Exception e) {
			LogContext context = new LogContext().add("exception",exception);
			ClickSynchronizationException dtex = new ClickSynchronizationException("Unable to save to dispatch log", e,
					AlarmId.UTIL_SAVE_DISPATCH_LOG, context);
			LOG.error(dtex);
		}
	}
	public void pause(int seconds) {
		LOG.info(new LogContext().setMessage("Sleeping").add("pause",seconds));
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException ignore) {}
	}
	
	/** Method is used to check, List is null or Empty.
	 * @param list
	 * @return returns true if List is null or empty, otherwise false.
	 */
	public static boolean isListNullOrEmpty(List<? extends Object> list) {
		return (list == null || list.isEmpty());
	}
}
