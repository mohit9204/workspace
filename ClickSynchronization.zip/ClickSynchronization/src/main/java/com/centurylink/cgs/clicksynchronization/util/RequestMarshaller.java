package com.centurylink.cgs.clicksynchronization.util;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.bind.Unmarshaller;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchgroupinterface.AssignmentUpdateResult;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.UpdateTaskAssignmentEx;
import com.clicksoftware.UpdateTaskAssignmentExResponse;

public class RequestMarshaller {
	public static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(RequestMarshaller.class);

	
	private static JAXBContext jaxbContext;

	static {
		try {
			jaxbContext = JAXBContext.newInstance(	UpdateTaskAssignmentEx.class, 
													UpdateTaskAssignmentEx.class, 
													UpdateTaskAssignmentExResponse.class,
													ProcessTaskEx.class,
													CTLAssignmentUpdate.class,
													AssignmentUpdateResult.class);
		} catch (JAXBException e) {
			ClickSynchronizationException exception = new ClickSynchronizationException(e.getMessage(), e, AlarmId.REQUEST_MARSHALLER_JAXBCONTEXT_NEW_INSTANCE, new LogContext().setMessage("Static startup failure"));
			LOG.error(exception);
			Util.getInstance().saveDispatchLog(exception);
		}
	}
	public static String marshall(UpdateTaskAssignmentEx message) throws Exception {
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		StringWriter sw = new StringWriter();
		marshaller.marshal(message, sw);
		String xml = sw.toString();
		return xml;

	}
	public static UpdateTaskAssignmentEx unMarshallUpdateTaskAssignmentEx(String message) throws ClickSynchronizationException {
		try {
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			StringReader sr = new StringReader(message);
			return (UpdateTaskAssignmentEx) unmarshaller.unmarshal(sr);
		} catch (JAXBException e) {
			ClickSynchronizationException exception = new ClickSynchronizationException(e.getMessage(), e, AlarmId.REQUEST_MARSHALLER_UN_MARSHALL_UPDATE_TASK_ASSIGNMENT_EX, new LogContext().setMessage("Static startup failure"));
			throw exception;
		}
	}
	public static String marshall(ProcessTaskEx message) throws Exception {
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		StringWriter sw = new StringWriter();
		marshaller.marshal(message, sw);
		String xml = sw.toString();
		return xml;

	}
	public static ProcessTaskEx unMarshallProcessTaskEx(String message) throws ClickSynchronizationException {
		try {
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			StringReader sr = new StringReader(message);
			return (ProcessTaskEx) unmarshaller.unmarshal(sr);
		} catch (JAXBException e) {
			ClickSynchronizationException exception = new ClickSynchronizationException(e.getMessage(), e, AlarmId.REQUEST_MARSHALLER_UN_MARSHALL_PROCESS_TASK_EX, new LogContext().setMessage("Static startup failure"));
			throw exception;
		}

	}
	public static String marshall(CTLAssignmentUpdate request) throws Exception {
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		StringWriter sw = new StringWriter();
		marshaller.marshal(request, sw);
		String xml = sw.toString();
		return xml;
	}
	public static AssignmentUpdateResult unmarshallAssignmentUpdateResult(String message) throws Exception {
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		StringReader sr = new StringReader(message);
		return (AssignmentUpdateResult) unmarshaller.unmarshal(sr);
	}
	public static String marshall(AssignmentUpdateResult result) throws Exception {
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		StringWriter sw = new StringWriter();
		marshaller.marshal(result, sw);
		String xml = sw.toString();
		return xml;
		
	}
	public static CTLAssignmentUpdate unmarshallCTLAssignmentUpdate(String assignmentRecord)  throws ClickSynchronizationException {
		LogContext logContext = new LogContext().add("assignmentRecord",assignmentRecord);
		try {
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			StringReader sr = new StringReader(assignmentRecord);
			return (CTLAssignmentUpdate) unmarshaller.unmarshal(sr);
			} catch (Exception e) {
				throw new ClickSynchronizationException(e.getMessage(), e, AlarmId.REQUEST_MARSHALLER_UNMARSHALL_CTLASSIGNMENT_UPDATE, logContext);
			}
	}
	
}
