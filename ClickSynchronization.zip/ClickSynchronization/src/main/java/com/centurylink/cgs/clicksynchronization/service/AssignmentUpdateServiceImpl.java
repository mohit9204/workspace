package com.centurylink.cgs.clicksynchronization.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchgroupinterface.AssignmentUpdateResult;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;

@Service
public class AssignmentUpdateServiceImpl implements AssignmentUpdateService{
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(AssignmentUpdateServiceImpl.class);
	@Autowired
	JobsDao jobsDao;
	
	@Override
	public AssignmentUpdateResult assignmentUpdate(CTLAssignmentUpdate assignment)
			throws ClickSynchronizationException {
		LOG.debug(new LogContext().setMessage("Saving incoming message").add(LogContextHelper.get(assignment)));
		jobsDao.insertClickStatusPublishMessage(assignment);
		AssignmentUpdateResult result = new AssignmentUpdateResult();
		result.setStatus(1);
		return result;
	}

}
