package com.centurylink.cgs.clicksynchronization.dao;

import java.util.List;
import java.util.Map;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.model.StatusEvaluatorMapping;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;
import com.centurylink.cgs.clicksynchronization.model.SynchronizerMapping;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityDynamicAudit;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityLimitAuditRecord;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;

public interface JobsDao {
	public void insertCTLCapacityLimitAuditRecord(CTLCapacityLimitAuditRecord record) throws ClickSynchronizationException;
	public void insertCTLCapacityDynamicAudit(CTLCapacityDynamicAudit record) throws ClickSynchronizationException;
	public List<Integer> getStatusPublishIds() throws ClickSynchronizationException;
	public List<Integer> getClickMessageIds(String messageType) throws ClickSynchronizationException;
	public StatusRequest getStatusPublishRequest(int id) throws ClickSynchronizationException;
	public String getClickSyncMessageRequest(int id) throws ClickSynchronizationException;
	public void completeStatusPublishRequest(int id) throws ClickSynchronizationException;
	public void retryStatusPublishRequest(int id) throws ClickSynchronizationException;
	public void failStatusPublishRequest(int id) throws ClickSynchronizationException;
	public void insertClickStatusPublishMessage(CTLAssignmentUpdate message) throws ClickSynchronizationException;
	public void completeClickSyncMessage(int id) throws ClickSynchronizationException;
	public void retryClickSyncMessage(int id) throws ClickSynchronizationException;
	public void failClickSyncMessage(int id) throws ClickSynchronizationException;
	public void synchronizeClickSyncMessage(int id) throws ClickSynchronizationException;
	public void ignoreStatusPublishRequest(Integer id) throws ClickSynchronizationException;
	public void insertClickSyncError(int id, String message) throws ClickSynchronizationException;
	public void synchronizeStatusRequest(String correlationId, String status) throws ClickSynchronizationException;
	public List<Integer> getFailedMessageIds() throws ClickSynchronizationException;
	public FailedMessage getFailedMessage(int id) throws ClickSynchronizationException;
	public void completeClickError(int id) throws ClickSynchronizationException;
	public void failClickError(int id) throws ClickSynchronizationException;
	public List<SynchronizerMapping> getSynchronizerMapping() throws ClickSynchronizationException;
	public List<StatusEvaluatorMapping> getStatusEvaluatorMapping() throws ClickSynchronizationException;
	public String getDynamicClassSource(String name)  throws ClickSynchronizationException;
	public List<Integer> getRetryMessages(String correlationId) throws ClickSynchronizationException;
	public void retryMessage(String correlationId) throws ClickSynchronizationException;
	public void completeFailedError(String correlationId) throws ClickSynchronizationException;
	public List<Map<String,Object>> getTechDetailsByCorrelationId(String correlationId) throws ClickSynchronizationException;
	
}
