package com.centurylink.cgs.clicksynchronization.service;

import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;

public interface ClickSynchronizationVersionService {
	public VersionHealthResponse getVersionDetails() throws Exception;
}
