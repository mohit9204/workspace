package com.centurylink.cgs.clicksynchronization;

import java.io.File;
import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.service.AssignmentUpdateService;
import com.centurylink.cgs.clicksynchronization.service.ClickAuditRecordService;
import com.centurylink.cgs.clicksynchronization.service.ClickSynchronizationHealthService;
import com.centurylink.cgs.clicksynchronization.service.ClickSynchronizationVersionService;
import com.centurylink.cgs.clicksynchronization.service.RetryMessageService;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityDynamicAudit;
import com.centurylink.cgs.clicksynchronizationinterface.CTLCapacityLimitAuditRecord;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;
import com.centurylink.cgs.dispatchgroupinterface.AssignmentUpdateResult;
import com.centurylink.cgs.dispatchgroupinterface.CTLAssignmentUpdate;


@RestController
public class ClickSynchronizationController {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ClickSynchronizationController.class);
	@Autowired
	private ClickAuditRecordService clickAuditRecordService;
	
	@Autowired
	private AssignmentUpdateService assignmentUpdateService;
	
	@Autowired
	private ClickSynchronizationHealthService clickSynchronizationHealthService;
	
	@Autowired
	private ClickSynchronizationVersionService clickSynchronizationVersionService;
	
	@Autowired
	private RetryMessageService retryMessageService;
	
	@PostMapping(value = "/dynamicaudit", consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
	public String dynamicaudit(@RequestBody CTLCapacityDynamicAudit clickAuditRecord) throws Exception {
		clickAuditRecordService.processCTLCapacityDynamicAudit(clickAuditRecord);
		return null;
    }
	@PostMapping(value = "/audit", consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
	public String audit(@RequestBody CTLCapacityLimitAuditRecord clickAuditRecord) throws Exception {
		clickAuditRecordService.processCTLCapacityLimitAuditRecord(clickAuditRecord);
		return null;
    }
	@PostMapping(value = "/assignment", consumes = {MediaType.APPLICATION_XML_VALUE, MediaType.TEXT_XML_VALUE}, produces = MediaType.APPLICATION_XML_VALUE)
	public String assignment(@RequestBody String assignmentRecord) throws Exception {
		LOG.debug(assignmentRecord);
		CTLAssignmentUpdate assignment = RequestMarshaller.unmarshallCTLAssignmentUpdate(assignmentRecord);
		AssignmentUpdateResult result =  assignmentUpdateService.assignmentUpdate(assignment);
		return RequestMarshaller.marshall(result);
    }
	@GetMapping(value = "/retry/{correlationId}",  produces = MediaType.TEXT_PLAIN_VALUE)
	public String retry(@PathVariable String correlationId) throws Exception {
		LOG.info(new LogContext().setMessage("Retry Request").add("correlationId",correlationId));
		return retryMessageService.retry(correlationId);
    }
	@GetMapping(value = "/healthz", produces = "application/json")
	public VersionHealthResponse healthz() throws Exception {
		
		return clickSynchronizationHealthService.getHealthDetails();
    }
	@GetMapping(value = "/version", produces = "application/json")
	public VersionHealthResponse version() throws Exception {
		
		return clickSynchronizationVersionService.getVersionDetails();
    }
}
