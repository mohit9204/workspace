package com.centurylink.cgs.clicksynchronization.service.synchronizers.v1;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

public class ChangeFromCompletedSynchronizer extends ClickSynchronizer {

	private static final String GET_TASK_STATUS = 
			"SELECT S.TASK_STATUS " +
					"  FROM DISPATCH_GROUP_STATUS S " +
					"       INNER JOIN DISPATCH_GROUP_DETAILS G ON S.GROUP_ID = G.GROUP_ID " +
					" WHERE G.CORRELATION_ID = :correlationId " +
					"UNION ALL " +
					"SELECT TASK_STATUS " +
					"  FROM JOBS_DETAIL " +
					" WHERE CORRELATION_ID = :correlationId ";			
	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ChangeFromCompletedSynchronizer.class);
		LogContext context = new LogContext().add(LogContextHelper.get(failure, false));

		String taskStatus = getTaskStatus(failure.getCorrelationId());
		if (taskStatus != null && (Constants.STATUS_COMPLETED.equals(taskStatus) || Constants.STATUS_CANCELLED.equals(taskStatus))) {
			LOG.info(context.setMessage("Ignoring UpdateTaskAssignmentEx record").add("taskStatus",taskStatus));
			LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record set to Synchronized"));
			jobsDao.synchronizeClickSyncMessage(failure.getId());
			LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
			jobsDao.completeClickError(failure.getErrorMessageId());
			return;
		}
		LOG.info(context.setMessage("Unable to synchronize").add("taskStatus",taskStatus));
		jobsDao.retryClickSyncMessage(failure.getId());
		LOG.info(context.setMessage("CLICK_SYNC_ERROR record failed"));
		jobsDao.failClickError(failure.getErrorMessageId());
	}

	private String getTaskStatus(String correlationId) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);
		List<Map<String, Object>> map =  dao.getNamedParameterJdbcTemplate().queryForList(GET_TASK_STATUS, paramMap);
		if (map.size() > 0 && map.get(0).get("TASK_STATUS") != null)
			return map.get(0).get("TASK_STATUS").toString();
		else
			return null;
	}
}
