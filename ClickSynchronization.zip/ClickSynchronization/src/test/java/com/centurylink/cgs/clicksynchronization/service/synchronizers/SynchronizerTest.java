package com.centurylink.cgs.clicksynchronization.service.synchronizers;

import javax.sql.DataSource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.centurylink.cgs.clicksynchronization.ClickSynchronizationApplication;
import com.centurylink.cgs.clicksynchronization.dao.JobsDao;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.AllocatedToCompletedSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.AllocatedToEnrouteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.AllocatedToNonCompleteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.AllocatedToNotReadySynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.AllocatedToOnSiteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.AssignedToOnSiteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.AssignedToUnscheduledSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.ChangeFromCompletedSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.EnRouteToCompletedSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.IgnoreStatusError;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NonCompleteToCancelledSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NonCompleteToCompletedSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NonCompleteToOnSiteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NotReadyToAnotherSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NotReadyToCancelledSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NotReadyToCompletedSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NotReadyToEnRouteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NotReadyToNonCompleteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.NotReadyToOnsiteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.ObjectNotFoundSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.ScheduleTaskWithAssignedEnRouteOnSiteStatusSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.StartShouldPrecedeFinishSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v1.WireCenterLongerThanMaxSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v2.PreferredEngineerInvalidSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v2.StartTimeOnSiteSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v4.PreferredRequiredEngineerSynchronizer;
import com.centurylink.cgs.clicksynchronization.service.synchronizers.v6.TaskHasNoAssignmentSynchronizer;
import com.centurylink.cgs.clicksynchronization.testutils.Requests;
import com.centurylink.cgs.clicksynchronization.testutils.TestUtil;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ClickSynchronizationApplication.class)
public class SynchronizerTest {
	ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(SynchronizerTest.class);

	@Autowired
	JobsDao jobsDao;
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 
	
	@Autowired
	TestUtil testUtil;
	
	@Test
	public void testAssignedToOnSiteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.assignTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "On-Site");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		AssignedToOnSiteSynchronizer sync = new AssignedToOnSiteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testAllocatedToEnrouteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "EnRoute");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		AllocatedToEnrouteSynchronizer sync = new AllocatedToEnrouteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	
	@Test
	public void testAllocatedToOnSiteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "On-Site");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		AllocatedToOnSiteSynchronizer sync = new AllocatedToOnSiteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId", correlationId));
		sync.synchronize(failedMessage);
	}
	
	@Test
	public void testAllocatedToNonCompleteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Non Complete");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		AllocatedToNonCompleteSynchronizer sync = new AllocatedToNonCompleteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	
	@Test
	public void testAllocatedToNotReadySynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Not Ready");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		AllocatedToNotReadySynchronizer sync = new AllocatedToNotReadySynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	
	@Test
	public void testAllocatedToCompletedSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Completed");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		AllocatedToCompletedSynchronizer sync = new AllocatedToCompletedSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testEnRouteToCompletedSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.assignTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "Completed");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		EnRouteToCompletedSynchronizer sync = new EnRouteToCompletedSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	
	@Test
	public void testFinishTimeCompletedSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.assignTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Completed");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		//FinishTimeCompletedSynchronizer sync = new FinishTimeCompletedSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		//sync.synchronize(failedMessage);
		
	

	}
	
	@Test
	public void testNotReadyToCancelledSynchronizer() throws Exception {
		String correlationId;
		correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.cancelTask(correlationId);
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NotReadyToCancelledSynchronizer sync = new NotReadyToCancelledSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId", correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testTestUtil() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Completed");
	}
	
	@Test
	public void testNonCompleteToCancelledSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Non Complete");
		testUtil.cancelTask(correlationId);
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NonCompleteToCancelledSynchronizer sync = new NonCompleteToCancelledSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testNonCompleteToCompletedSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Non Complete");
		testUtil.statusTask(correlationId, "Completed");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NonCompleteToCompletedSynchronizer sync = new NonCompleteToCompletedSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testNonCompleteToOnSiteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Non Complete");
		testUtil.statusTask(correlationId, "On-Site");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NonCompleteToOnSiteSynchronizer sync = new NonCompleteToOnSiteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testNotReadyToCompletedSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.statusTask(correlationId, "Completed");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NotReadyToCompletedSynchronizer sync = new NotReadyToCompletedSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testNotReadyToEnrouteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.statusTask(correlationId, "EnRoute");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NotReadyToEnRouteSynchronizer sync = new NotReadyToEnRouteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testNotReadyToNonCompletedSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.statusTask(correlationId, "Non Complete");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NotReadyToNonCompleteSynchronizer sync = new NotReadyToNonCompleteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testNotReadyToOnsiteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.statusTask(correlationId, "On-Site");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NotReadyToOnsiteSynchronizer sync = new NotReadyToOnsiteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testObjectNotFoundSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.statusTask(correlationId, "On-Site");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		ObjectNotFoundSynchronizer sync = new ObjectNotFoundSynchronizer();
		sync.synchronize(failedMessage);
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
	}
	@Test
	public void testTaskHasNoAssignmentSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.statusTask(correlationId, "Unscheduled");
		Thread.sleep(1000);
		testUtil.allocateTask(correlationId, "WMIDDLE", "Des Moines West IA", false);
		testUtil.statusTask(correlationId, "Unscheduled");
		testUtil.statusTask(correlationId, "EnRoute"); 
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		TaskHasNoAssignmentSynchronizer sync = new TaskHasNoAssignmentSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage); // EnRoute should show AB64460 as the tech

	}
	@Test
	public void testTaskHasNoAssignmentSynchronizerGrouped() throws Exception {
		String correlationId = testUtil.createGroupedTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.statusTask(correlationId, "Unscheduled");
		Thread.sleep(1000);
		testUtil.allocateTask(correlationId, "WMIDDLE", "Des Moines West IA", false);
		testUtil.statusTask(correlationId, "Unscheduled");
		testUtil.statusTask(correlationId, "EnRoute"); 
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		TaskHasNoAssignmentSynchronizer sync = new TaskHasNoAssignmentSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage); // EnRoute should show AB64460 as the tech

	}
	@Test
	public void testTaskHasNoAssignmentSynchronizerAllocatedToCompleted() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Completed");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		TaskHasNoAssignmentSynchronizer sync = new TaskHasNoAssignmentSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testStartShouldPrecedeFinishSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.assignTask(correlationId, "AB64460", "Main NV", 0);
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		StartShouldPrecedeFinishSynchronizer sync = new StartShouldPrecedeFinishSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testScheduleTaskWithAssignedStatusSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.assignTask(correlationId, "AB64460", "Main NV");
		testUtil.assignTask(correlationId, "AB64460", "Main NV");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		ScheduleTaskWithAssignedEnRouteOnSiteStatusSynchronizer sync = new ScheduleTaskWithAssignedEnRouteOnSiteStatusSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
	@Test
	public void testWireCenterLongerThanMaxSynchronizer() throws Exception {
		String correlationId = testUtil.createTask(Requests.NTM_REQUEST_LONG_WIRE_CENTER);
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		WireCenterLongerThanMaxSynchronizer sync = new WireCenterLongerThanMaxSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);	
	}
	@Test
	public void testPreferredEngineerInvalidSynchronizer() throws Exception {
		// This error is random, so testing with a correlationId from prod
		FailedMessage failedMessage = testUtil.getFailedMessage("5788150");
		PreferredEngineerInvalidSynchronizer sync = new PreferredEngineerInvalidSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId","5788150"));
		sync.synchronize(failedMessage);	
	}
	@Test
	public void testStartTimeOnSiteSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "EnRoute");
		testUtil.statusTask(correlationId, "On-Site");
		Thread.sleep(1000);
		testUtil.statusTask(correlationId, "On-Site");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		StartTimeOnSiteSynchronizer sync = new StartTimeOnSiteSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId","5788150"));
		sync.synchronize(failedMessage);	
	}
	@Test
	public void testChangeFromCompletedSynchronizer() throws Exception {
		// This error is difficult to reproduce, so testing with a correlationId from prod
		String correlationId = "5766210";
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		ChangeFromCompletedSynchronizer sync = new ChangeFromCompletedSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);	
	}

	@Test
	public void testNotReadyToAnotherSynchronizer() throws Exception {
		String correlationId = testUtil.createTask();
		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
		testUtil.statusTask(correlationId, "Assigned");
		testUtil.statusTask(correlationId, "Not Ready");
		testUtil.statusTask(correlationId, "EnRoute");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		NotReadyToAnotherSynchronizer sync = new NotReadyToAnotherSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);	
	}
	@Test
	public void testAssignedToUnscheduledSynchronizer() throws Exception {
//		String correlationId = testUtil.createTask();
		// SB2 allows Assigned to Unscheduled, so test with prod
		String correlationId = "5802737";
//		testUtil.allocateTask(correlationId, "AB64460", "Main NV");
//		testUtil.statusTask(correlationId, "Assigned");
//		testUtil.statusTask(correlationId, "Unscheduled");
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		AssignedToUnscheduledSynchronizer sync = new AssignedToUnscheduledSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);	
	}
	@Test
	public void testPreferredRequiredEngineerSynchronizer() throws Exception {
		String correlationId = testUtil.createTaskIncompleteRequiredPreferred("AB17845",null,"AB17845",null);
		FailedMessage failedMessage = testUtil.getFailedMessage(correlationId);
		PreferredRequiredEngineerSynchronizer sync = new PreferredRequiredEngineerSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
		correlationId = testUtil.createTaskIncompleteRequiredPreferred("AB17845","South South NV","AB17845",null);
		failedMessage = testUtil.getFailedMessage(correlationId);
		sync = new PreferredRequiredEngineerSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
		correlationId = testUtil.createTaskIncompleteRequiredPreferred("AB1785","South South NV","AB17845",null);
		failedMessage = testUtil.getFailedMessage(correlationId);
		sync = new PreferredRequiredEngineerSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
		correlationId = testUtil.createTaskIncompleteRequiredPreferred("AB17845","South South NV","AB1845",null);
		failedMessage = testUtil.getFailedMessage(correlationId);
		sync = new PreferredRequiredEngineerSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
		correlationId = testUtil.createTaskIncompleteRequiredPreferred("AB1845","South South NV","AB1845",null);
		failedMessage = testUtil.getFailedMessage(correlationId);
		sync = new PreferredRequiredEngineerSynchronizer();
		LOG.info(new LogContext().setMessage("Starting synchronizer").add("correlationId",correlationId));
		sync.synchronize(failedMessage);
	}
}
