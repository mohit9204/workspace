package com.centurylink.cgs.clicksynchronization.testutils;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.centurylink.cgs.clicksynchronization.client.GetTaskClient;
import com.centurylink.cgs.clicksynchronization.client.ProcessTaskExClickClient;
import com.centurylink.cgs.clicksynchronization.dao.FailedMessageRowMapper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.GetTaskResponse;
import com.clicksoftware.ProcessTaskExResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class TestUtil {
	ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(TestUtil.class);
	
	@Value("${dispatchtask.endpoint}")
	private String taskEndpoint;
	
	@Value("${selfassign.endpoint}")
	private String selfassignEndpoint;
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 
	
	@Autowired
	ProcessTaskExClickClient processTaskExClickClient;
	
	@Autowired
	GetTaskClient getTaskClient;
	
	public  String createTask() throws Exception {
		return createTask(Requests.TRACS_REQUEST);
	}
	public  String createTask(String content) throws Exception {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		String url = String.format("%s/task", taskEndpoint);
		HttpPost httpPost = new HttpPost(new URI(url));
		StringEntity params =new StringEntity(content,"UTF-8");
		httpPost.addHeader("Accept", "*/*");
		httpPost.addHeader("Content-Type", "application/json");
		httpPost.setEntity(params);
		CloseableHttpResponse response = httpClient.execute(httpPost);
		String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
		ObjectMapper mapper = new ObjectMapper();
		DispatchTaskResponse taskResponse = mapper.readValue(responseString, DispatchTaskResponse.class);
		LOG.info(new LogContext().add("correlationId",taskResponse.getCorrelationId()).add("responseStatus",taskResponse.getBaseResponse().getResponseStatus()));
		return taskResponse.getCorrelationId();
	}
	public  String createGroupedTask() throws Exception {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		String url = String.format("%s/task", taskEndpoint);
		HttpPost httpPost = new HttpPost(new URI(url));
		String order = getOrderNumber();
		String content = getCreateRequestGrouped(order);
		StringEntity params =new StringEntity(content,"UTF-8");
		httpPost.addHeader("Accept", "*/*");
		httpPost.addHeader("Content-Type", "application/json");
		httpPost.setEntity(params);
		CloseableHttpResponse response = httpClient.execute(httpPost);
		String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
		ObjectMapper mapper = new ObjectMapper();
		DispatchTaskResponse taskResponse = mapper.readValue(responseString, DispatchTaskResponse.class);
		LOG.info(new LogContext().add("correlationId",taskResponse.getCorrelationId()).add("responseStatus",taskResponse.getBaseResponse().getResponseStatus()));
		Thread.sleep(1000);
		content = getCreateRequestGrouped(order);
		params =new StringEntity(content,"UTF-8");
		httpPost.setEntity(params);
		response = httpClient.execute(httpPost);
		responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
		mapper = new ObjectMapper();
		taskResponse = mapper.readValue(responseString, DispatchTaskResponse.class);
		LOG.info(new LogContext().add("correlationId",taskResponse.getCorrelationId()).add("responseStatus",taskResponse.getBaseResponse().getResponseStatus()));
		String correlationId = getCorrelationId(taskResponse.getCorrelationId());
		return correlationId;
	}

	private String getCorrelationId(String correlationId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);
		NamedParameterJdbcDaoSupport jdbc = new NamedParameterJdbcDaoSupport();
		jdbc.setDataSource(dataSource);
		String query = "SELECT G.CORRELATION_ID FROM DISPATCH_GROUP_DETAILS G INNER JOIN DISPATCH_GROUP_MEMBERS M ON M.GROUP_ID = G.GROUP_ID WHERE M.CORRELATION_ID = :correlationId ";
		List<Map<String, Object>> list =  jdbc.getNamedParameterJdbcTemplate().queryForList(query, paramMap);
		return list.get(0).get("CORRELATION_ID").toString();

	}
	public String cancelTask(String correlationId) throws Exception {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		String url = String.format("%s/task/%s", taskEndpoint, correlationId);
		HttpPatch httpPatch = new HttpPatch(new URI(url));
		String content = getCancelRequest();
		StringEntity params = new StringEntity(content, "UTF-8");
		httpPatch.addHeader("Accept", "*/*");
		httpPatch.addHeader("Content-Type", "application/json");
		httpPatch.setEntity(params);
		CloseableHttpResponse response = httpClient.execute(httpPatch);
		String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
		ObjectMapper mapper = new ObjectMapper();
		DispatchTaskResponse taskResponse = mapper.readValue(responseString, DispatchTaskResponse.class);
		LOG.info(new LogContext().add("correlationId", taskResponse.getCorrelationId()).add("responseStatus",
				taskResponse.getBaseResponse().getResponseStatus()));
		return taskResponse.getCorrelationId();
	}

	private String getCancelRequest() {
		return "{ " +
				"  \"callingSystem\" : \"TEST\", " +
				"  \"originatingSystem\" : \"TRACS\" " +
				"} ";
	}
	public  String assignTask(String correlationId, String tech, String district) throws Exception {
		return assignTask(correlationId, tech, district, 3600);
	}
	public  String assignTask(String correlationId, String tech, String district, int duration) throws Exception {
		String request = getTaskAssignRequest(tech, district, duration);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		String url = String.format("%s/assign/%s", selfassignEndpoint, correlationId);
		
		HttpPut httpPut = new HttpPut(new URI(url));
		StringEntity params =new StringEntity(request,"UTF-8");
		httpPut.addHeader("Accept", "*/*");
		httpPut.addHeader("Content-Type", "application/json");
		httpPut.setEntity(params);
		CloseableHttpResponse response = httpClient.execute(httpPut);
		String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
		ObjectMapper mapper = new ObjectMapper();
		DispatchTaskResponse assignResponse = mapper.readValue(responseString, DispatchTaskResponse.class);
		LOG.info(new LogContext().setMessage("Assign task").add("correlationId",correlationId).add("responseStatus",assignResponse.getBaseResponse().getResponseStatus()));
		return assignResponse.getBaseResponse().getResponseStatus().toString();
	}
	public  String allocateTask(String correlationId, String tech, String district) throws Exception {
		return allocateTask(correlationId, tech, district, 3600, true);
	}
	public  String allocateTask(String correlationId, String tech, String district, boolean wait) throws Exception {
		return allocateTask(correlationId, tech, district, 3600, wait);
	}

	public  String allocateTask(String correlationId, String tech, String district, int duration, boolean wait) throws Exception {
		GetTaskResponse task = null;
		do {
			LOG.info(new LogContext().setMessage("Waiting for task to appear in Click").add("correlationId",correlationId));
			try {Thread.sleep(1000);} catch (InterruptedException e) {}			
			try {
				task = getTaskClient.getTask(correlationId);
			} catch (Exception e) {
			}
		} while ( task == null);
		String request = getProcessTaskExAllocate(correlationId, tech, district, duration);
		ProcessTaskExResponse result = processTaskExClickClient.processTaskEx(request);
		LOG.info(new LogContext().setMessage("Allocate task").add("correlationId",correlationId).add("returnCode",result.getReturnCode().name()));
		boolean isAllocated = false;
		do {
			LOG.info(new LogContext().setMessage("Waiting for task to allocate in JOBS").add("correlationId",correlationId));
			try {Thread.sleep(1000);} catch (InterruptedException e) {}			
			try {
				isAllocated = isAllocated(correlationId);
			} catch (Exception e) {
			}
		} while ( !isAllocated && wait);
		return result.getReturnCode().name();
	}


	public  String statusTask(String correlationId, String status) throws Exception {
		return statusTask(correlationId, status, new Date());
	}
	public  String statusTask(String correlationId, String status, Date statusUpdateTimestamp) throws Exception {
		String request = getStatusRequest(status,statusUpdateTimestamp);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		String url = String.format("%s/task/%s/status", taskEndpoint, correlationId);
		HttpPut httpPut = new HttpPut(new URI(url));
		StringEntity params =new StringEntity(request,"UTF-8");
		httpPut.addHeader("Accept", "*/*");
		httpPut.addHeader("Content-Type", "application/json");
		httpPut.setEntity(params);
		CloseableHttpResponse response = httpClient.execute(httpPut);
		String responseString = EntityUtils.toString(response.getEntity(), "UTF-8");
		ObjectMapper mapper = new ObjectMapper();
		DispatchTaskResponse assignResponse = mapper.readValue(responseString, DispatchTaskResponse.class);
		LOG.info(new LogContext().add("correlationId",correlationId).add("status",status).add("responseStatus",assignResponse.getBaseResponse().getResponseStatus()));
		return assignResponse.getBaseResponse().getResponseStatus().toString();
	}
	public FailedMessage getFailedMessage(String correlationId) {
		FailedMessage message = null;
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);
		NamedParameterJdbcDaoSupport jdbc = new NamedParameterJdbcDaoSupport();
		jdbc.setDataSource(dataSource);
		String query = 			
				"SELECT E.ERROR_MESSAGE_ID, E.MESSAGE_ID, E.ERROR_MESSAGE_VAL, M.MESSAGE_TYP, M.MESSAGE_VAL, M.CORRELATION_ID " +
				"  FROM CLICK_SYNC_ERROR_V E" +
				"  INNER JOIN CLICK_SYNC_MESSAGE_V M ON E.MESSAGE_ID = M.MESSAGE_ID" +
				" WHERE M.CORRELATION_ID = :correlationId AND E.MESSAGE_STATUS_VAL = 'Failed'";
		do {
			LOG.info(new LogContext().setMessage("Waiting for message to fail").add("correlationId",correlationId));
			try {Thread.sleep(1000);} catch (InterruptedException e) {}
			List<FailedMessage> list =  jdbc.getNamedParameterJdbcTemplate().query(query, paramMap, new FailedMessageRowMapper());
			if (list.size() > 0)
				message = list.get(0);
		} while (message == null);
		LOG.info(new LogContext().setMessage("Message failed").add("correlationId",correlationId).add("errorMessage", message.getErrorMessage()));
		return message;
	}
	private String getCreateRequestGrouped(String orderNumber) {
		SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
		String dateTime = sdf.format(new Date());
		String hostTrackingNumber = String.format("MRNC%sA00", dateTime);
		String request = "{ " +
				"  \"callingSystem\" : \"DGW\", " +
				"  \"originatingSystem\" : \"MARTENS\", " +
				"  \"statusBackEndpoint\" : \"\", " +
				"  \"transactionId\" : \"151769610\", " +
				"  \"altCorrelationId\" : \"%s.0001\", " +
				"  \"numberEngineers\" : 1, " +
				"  \"statusBackServiceType\" : \"REST\", " +
				"  \"priority\" : 5, " +
				"  \"wireCenter\" : \"HLBONC\", " +
				"  \"serviceType\" : \"PROVISIONING\", " +
				"  \"jobLocation\" : { " +
				"    \"street\" : \"3427 LEES CHAPEL RD\", " +
				"    \"city\" : \"CEDAR GROVE\", " +
				"    \"state\" : \"NC\", " +
				"    \"zipCode\" : \"272319702\", " +
				"    \"country\" : \"US\", " +
				"    \"geoLocation\" : { " +
				"      \"longitude\" : -79.180707, " +
				"      \"latitude\" : 36.175478 " +
				"    } " +
				"  }, " +
				"  \"customerInfo\" : { " +
				"    \"customerName\" : \"\", " +
				"    \"maintenancePlan\" : \"\" " +
				"  }, " +
				"  \"appointment\" : { " +
				"    \"earlyStart\" : \"2019-06-14T08:00:00\", " +
				"    \"dueDate\" : \"2019-06-14T17:00:00\", " +
				"    \"futureAppt\" : false " +
				"  }, " +
				"  \"taskType\" : \"CAXXXXXXDCXXX\", " +
				"  \"productType\" : \"VOICE\", " +
				"  \"downstreamSpeed\" : \"0\", " +
				"  \"aggregationId\" : \"R/%s\", " +
				"  \"onHold\" : false, " +
				"  \"isNicOne\" : \"false\", " +
				"  \"isInside\" : false, " +
				"  \"durationSec\" : 0, " +
				"  \"features\" : [ { " +
				"    \"featureCode\" : \"DST-DST\", " +
				"    \"featureQuantity\" : 1, " +
				"    \"featureAction\" : \"DIS\" " +
				"  } ], " +
				"  \"taskCodes\" : [ ], " +
				"  \"hostTrackingNum\" : \"%s\", " +
				"  \"altTrackingNum\" : \"%s.0001\", " +
				"  \"manualScheduleFlag\" : false, " +
				"  \"order\" : { " +
				"    \"remarks\" : [ { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"SO TYPE: CABDIS SO: 1544711287 SR: 0003002 LCI: 0001 DD: 06/14/19 C:Y A:  P:\" " +
				"    }, { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"                                                     FEEDER PAIR: CAB01-00195\" " +
				"    }, { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"             TJUR: F/NC/0135\" " +
				"    }, { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"DISCONNECT CO: HLBONC   AC PT: C68                  STAT: P\" " +
				"    }, { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"AP ADDR: 00000110126-EFLAND CEDAR GROVE RD1357\" " +
				"    }, { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"DISTR:    CA-00537 (S) PAIR COLOR: BK-O  BP: 00036\" " +
				"    }, { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"------------------------------------------------------------------------------\" " +
				"    }, { " +
				"      \"remarkType\" : \"Ticket01\", " +
				"      \"remarkText\" : \"DISTR:   X03-00107 (S) PAIR COLOR:  R-O  BP: 00107\" " +
				"    } ] " +
				"  }, " +
				"  \"repair\" : { " +
				"    \"urls\" : [ ] " +
				"  }, " +
				"  \"openDate\" : \"2019-06-14T06:55:00\", " +
				"  \"csProductType\" : \"Res(IN)\", " +
				"  \"nextDayCancel\" : \"N\", " +
				"  \"clickTaskTypeDescription\" : \"CABLE - - Disconnect - -\", " +
				"  \"autoCancel\" : \"N\" " +
				"} ";
		return String.format(request, orderNumber, orderNumber, hostTrackingNumber,orderNumber);
	}
	private String getOrderNumber() {
		SimpleDateFormat sdf = new SimpleDateFormat("MMddHHmmss");
		
		return sdf.format(new Date());
	}
	private String getTaskAssignRequest(String techId, String district, int duration) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		String timestamp =  sdf.format(new Date());
		String request = "{ " +
				"	\"callingSystem\" : \"ANDROID\", " +
				"	\"technicianId\" : \"%s\", " +
				"	\"district\" : \"%s\", " +
				"	\"statusUpdateTimestamp\" : \"%s\", " +
				"	\"duration\" : %d " +
				"} ";
		return String.format(request, techId, district, timestamp, duration);
		
	}

	private String getStatusRequest(String status, Date updateTimestamp) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		String timestamp =  sdf.format(updateTimestamp);
		String content = "{"+
				"  \"callingSystem\" : \"TEST\","+
				"  \"taskStatus\" : {"+
				"    \"taskStatus\" : \"%s\","+
				"    \"statusUpdateTimestamp\" : \"%s\""+
				"  }"+
				"}";
		return String.format(content, status,timestamp);
	}
	private String getProcessTaskExAllocate(String correlationId, String tech, String district, int duration) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		String startTimestamp =  sdf.format(new Date());
		Calendar endDate = Calendar.getInstance();
		endDate.add(Calendar.SECOND, duration);
		String endTimestamp =  sdf.format(endDate.getTime());
		String request = "<ProcessTaskEx xmlns=\"http://www.clicksoftware.com\"> " +
				"    <Task> " +
				"        <Number>1</Number> " +
				"        <ExternalRefID>%s</ExternalRefID> " +
				"    </Task> " +
				"    <Assignment> " +
				"        <Start>%s</Start> " +
				"        <Finish>%s</Finish> " +
				"        <Engineers> " +
				"            <Engineer> " +
				"                <ID>%s</ID> " +
				"                <District> " +
				"                    <Name>%s</Name> " +
				"                </District> " +
				"            </Engineer> " +
				"        </Engineers> " +
				"    </Assignment> " +
				"    <ReturnAssignment>true</ReturnAssignment> " +
				"    <ReturnSchedulingError>true</ReturnSchedulingError> " +
				"</ProcessTaskEx> ";
		return String.format(request, correlationId,  startTimestamp, endTimestamp, tech, district);
	}
	private boolean isAllocated(String correlationId) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(Configuration.getInstance().getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);
		String query = 
				"SELECT TASK_STATUS " +
				"  FROM JOBS_DETAIL " +
				" WHERE CORRELATION_ID = :correlationId " +
				"UNION ALL " +
				"SELECT S.TASK_STATUS " +
				"  FROM DISPATCH_GROUP_STATUS S " +
				"       INNER JOIN DISPATCH_GROUP_DETAILS G ON S.GROUP_ID = G.GROUP_ID " +
				" WHERE G.CORRELATION_ID = :correlationId ";
		List<Map<String, Object>> map =  dao.getNamedParameterJdbcTemplate().queryForList(query, paramMap);
		if (map.size() > 0 && map.get(0).containsKey("TASK_STATUS") && "Allocated".equals(map.get(0).get("TASK_STATUS"))) 
			return true;
		else 
			return false;
	}
	public String createTaskIncompleteRequiredPreferred() throws Exception {
		return createTaskIncompleteRequiredPreferred("AB17845",null,"AB17845",null);
	}

	public String createTaskIncompleteRequiredPreferred(String requiredEngineer, String requiredDistrict, String preferredEngineer, String preferredDistrict) throws Exception {
		String requiredDistrictString = "";
		String preferredDistrictString = "";
		if (requiredDistrict != null) {
			requiredDistrictString = String.format(",\n    \"districtName\" : \"%s\"", requiredDistrict);
		}
		if (preferredDistrict != null) {
			preferredDistrictString = String.format(",\n    \"districtName\" : \"%s\"", preferredDistrict);
		}

		String request = "{ \n" +
				"  \"callingSystem\" : \"DSP_PORTAL\", \n" +
				"  \"originatingSystem\" : \"DSP_PORTAL\", \n" +
				"  \"transactionId\" : \"DPAA859881560796688\", \n" +
				"  \"altCorrelationId\" : \"\", \n" +
				"  \"requiredEngineerInfo\" : { \n" +
				"    \"engineerID\" : \"%s\"%s \n" +
				"  }, \n" +
				"  \"preferredEngineerInfo\" : { \n" +
				"    \"engineerID\" : \"%s\"%s \n" +
				"  }, \n" +
				"  \"numberEngineers\" : 1, \n" +
				"  \"priority\" : 6, \n" +
				"  \"wireCenter\" : \"NPRRWI\", \n" +
				"  \"serviceType\" : \"PROVISIONING\", \n" +
				"  \"jobLocation\" : { \n" +
				"    \"street\" : \"W336 S8455 COUNTY RD E\", \n" +
				"    \"city\" : \"MUKWONAGO\", \n" +
				"    \"state\" : \"WI\", \n" +
				"    \"zipCode\" : \"53149\", \n" +
				"    \"country\" : \"United States\", \n" +
				"    \"geoLocation\" : { \n" +
				"      \"longitude\" : -105.907924, \n" +
				"      \"latitude\" : 37.807232 \n" +
				"    } \n" +
				"  }, \n" +
				"  \"customerInfo\" : { \n" +
				"    \"customerName\" : \"MONTESSORI SCHOOL NORTH PRAIRIE\" \n" +
				"  }, \n" +
				"  \"appointment\" : { \n" +
				"    \"earlyStart\" : \"2019-06-19T07:14:00\", \n" +
				"    \"apptStart\" : \"2019-06-19T07:14:00\", \n" +
				"    \"apptFinish\" : \"2019-06-19T17:14:00\", \n" +
				"    \"dueDate\" : \"2019-06-19T17:14:00\", \n" +
				"    \"futureAppt\" : false \n" +
				"  }, \n" +
				"  \"taskType\" : \"PDNIBXXXXXXIN\", \n" +
				"  \"productType\" : \"COMPANY_DEMAND\", \n" +
				"  \"customerType\" : \"None\", \n" +
				"  \"onHold\" : false, \n" +
				"  \"isInside\" : false, \n" +
				"  \"durationSec\" : 0, \n" +
				"  \"features\" : [ ], \n" +
				"  \"taskCodes\" : [ ], \n" +
				"  \"hostTrackingNum\" : \"DPAA859881560796688\", \n" +
				"  \"altTrackingNum\" : \"\", \n" +
				"  \"manualScheduleFlag\" : false, \n" +
				"  \"order\" : { \n" +
				"    \"remarks\" : [ { \n" +
				"      \"remarkType\" : \"TECH\", \n" +
				"      \"remarkText\" : \"WT06050149 sap S278WSTBN1\" \n" +
				"    } ] \n" +
				"  }, \n" +
				"  \"repair\" : { \n" +
				"    \"urls\" : [ ] \n" +
				"  }, \n" +
				"  \"tncktId\" : \"\" \n" +
				"} \n";
		String formattedRequest = String.format(request, requiredEngineer, requiredDistrictString, preferredEngineer, preferredDistrictString);
		return createTask(formattedRequest);
	}
}
