package com.centurylink.cgs.clicksynchronization.service.statusevaluators.v1;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;
import com.centurylink.cgs.clicksynchronization.model.UpstreamStatusEvaluator;
import com.centurylink.cgs.clicksynchronization.util.Constants;

public class DispatchScheduleNotReady implements UpstreamStatusEvaluator {

	@Override
	public boolean sendStatus(StatusRequest request) throws ClickSynchronizationException {
		if (!Constants.STATUS_NOTREADY.equals(request.getJobsTaskStatus()))
			return true;
		else
			return false;
	}

}
