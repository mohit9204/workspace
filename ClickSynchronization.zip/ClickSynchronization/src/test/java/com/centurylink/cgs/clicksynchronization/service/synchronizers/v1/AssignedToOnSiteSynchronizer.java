package com.centurylink.cgs.clicksynchronization.service.synchronizers.v1;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.UpdateTaskAssignmentEx;
import com.clicksoftware.UpdateTaskAssignmentExResponse;

public class AssignedToOnSiteSynchronizer extends ClickSynchronizer {

	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(AssignedToOnSiteSynchronizer.class);
		LogContext context = new LogContext().add(LogContextHelper.get(failure, false));
		UpdateTaskAssignmentEx message = RequestMarshaller.unMarshallUpdateTaskAssignmentEx(failure.getMessage());
		message.getTask().getStatus().setName(Constants.STATUS_ENROUTE);
		message.getTask().getStatus().setDisplayString(Constants.STATUS_ENROUTE);
		UpdateTaskAssignmentExResponse result = updateTaskAssignmentExClickClient.updateTaskAssignmentEx(message);
		LOG.info(context.setMessage("EnRoute message sent to Click"));
		LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record set to Retry"));
		jobsDao.retryClickSyncMessage(failure.getId());
		LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
		jobsDao.completeClickError(failure.getErrorMessageId());
	}
}
