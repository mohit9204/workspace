package com.centurylink.cgs.clicksynchronization.service.synchronizers.v2;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;

public class ScheduledSynchronizer extends ClickSynchronizer {
	private static final ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ScheduledSynchronizer.class);
	
	
	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		LOG.info("Nothing to do yet");
	}
}
