package com.centurylink.cgs.clicksynchronization.service.synchronizers.v1;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.UpdateTaskAssignmentEx;
import com.clicksoftware.UpdateTaskAssignmentExResponse;

public class ScheduleTaskWithAllocatedSynchronizer extends ClickSynchronizer {

	
	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(ScheduleTaskWithAllocatedSynchronizer.class);
		LogContext context = new LogContext().add(LogContextHelper.get(failure, false));
		ProcessTaskEx message = RequestMarshaller.unMarshallProcessTaskEx(failure.getMessage());
		message.getTask().setCTLManualSchedule(false);
		LOG.info(context.setMessage("Sending CLICK_SYNC_MESSAGE with manual schedule flag as false"));
		processTaskExClickClient.processTaskEx(message);
		LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record set to Synchronized"));
		jobsDao.synchronizeClickSyncMessage(failure.getId());
		LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
		jobsDao.completeClickError(failure.getErrorMessageId());
	}
}
