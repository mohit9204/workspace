package com.centurylink.cgs.clicksynchronization.service.statusevaluators.v1;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.model.StatusRequest;
import com.centurylink.cgs.clicksynchronization.model.UpstreamStatusEvaluator;

public class ClickEnRoute implements UpstreamStatusEvaluator {

	@Override
	public boolean sendStatus(StatusRequest request) throws ClickSynchronizationException {
		if (request.isInSync())
			return true;
		else
			return false;
	}

}
