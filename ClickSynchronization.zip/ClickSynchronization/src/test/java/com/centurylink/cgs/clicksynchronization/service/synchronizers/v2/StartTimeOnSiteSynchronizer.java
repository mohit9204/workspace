package com.centurylink.cgs.clicksynchronization.service.synchronizers.v2;

import com.centurylink.cgs.clicksynchronization.client.GetTaskClient;
import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.GetTaskResponse;
import com.clicksoftware.UpdateTaskAssignmentEx;


public class StartTimeOnSiteSynchronizer extends ClickSynchronizer {

    @Override
    public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
        ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(StartTimeOnSiteSynchronizer.class);
        LogContext context = new LogContext().add(LogContextHelper.get(failure, false));
        UpdateTaskAssignmentEx message = RequestMarshaller.unMarshallUpdateTaskAssignmentEx(failure.getMessage());
        if (Constants.STATUS_ONSITE.equals(message.getTask().getStatus().getName())) {
            LOG.info(context.setMessage("Ignoring message on On-Site task"));
            LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record set to Synchronized"));
            jobsDao.synchronizeClickSyncMessage(failure.getId());
            LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
            jobsDao.completeClickError(failure.getErrorMessageId());
            return;
        } else {
        	GetTaskClient getTaskClient = GetTaskClient.getInstance();
            GetTaskResponse task = getTaskClient.getTask(failure.getCorrelationId());
            if (task != null && task.getAssignment() != null) {
            	message.setUpdateTime(task.getAssignment().getStart());
            	LOG.info(context.setMessage("Sending CLICK_SYNC_MESSAGE record with updated UpdateTime"));
            	updateTaskAssignmentExClickClient.updateTaskAssignmentEx(message);
            	LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record set to Retry"));
            	jobsDao.retryClickSyncMessage(failure.getId());
            	LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
            	jobsDao.completeClickError(failure.getErrorMessageId());
            	return;
            }
        } 
    	throw new ClickSynchronizationException("Unexpected condition in StartTimeOnSiteSynchronizer",
                AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_ALL_EXCEPTIONS, 
                context);
        
    }
}

