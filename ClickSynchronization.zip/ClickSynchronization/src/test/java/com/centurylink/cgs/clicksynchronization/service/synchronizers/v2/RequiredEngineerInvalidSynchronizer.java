package com.centurylink.cgs.clicksynchronization.service.synchronizers.v2;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.EngineerReference;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.Task.RequiredEngineers;

public class RequiredEngineerInvalidSynchronizer extends ClickSynchronizer {

	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(RequiredEngineerInvalidSynchronizer.class);
		LogContext context = new LogContext().add(LogContextHelper.get(failure, false));

		ProcessTaskEx message = RequestMarshaller.unMarshallProcessTaskEx(failure.getMessage());
		
		if (message != null && message.getTask() != null && message.getTask().getRequiredEngineers() != null) {
			RequiredEngineers requiredEngineers = message.getTask().getRequiredEngineers();
			for (EngineerReference engineer : requiredEngineers.getRequiredEngineer()) {
				if (engineer.getDistrict() != null && isValidTechnicianDistrict(engineer.getID(), engineer.getDistrict().getName())) {
					LOG.info(context.setMessage("Engineer reference is valid"));
					LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record set to Retry"));
					jobsDao.retryClickSyncMessage(failure.getId());
					LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
					jobsDao.completeClickError(failure.getErrorMessageId());	
					return;
				}
			}
		}
		LOG.info(context.setMessage("Unable to synchronize"));
		LOG.info(context.setMessage("CLICK_SYNC_ERROR record set to Failed"));
		jobsDao.failClickError(failure.getErrorMessageId());	
	}
	private boolean isValidTechnicianDistrict(String techId, String district) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("techId", techId);
		paramMap.put("district", district);
		String query = "select tech_id, district from click_technician_v where tech_Id = :techId and district = :district";
		List<Map<String, Object>> map =  dao.getNamedParameterJdbcTemplate().queryForList(query, paramMap);
		if (map.size() > 0)
			return true;
		else
			return false;
	}
}
