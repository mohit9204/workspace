package com.centurylink.cgs.clicksynchronization.testutils;

import javax.xml.bind.annotation.XmlType;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Fields specific to Click web service response. For display in return JSON, Checking for success/failure of operation, and for getting any Click Errors returned.")
@XmlType
@JsonInclude(Include.NON_NULL)
public class ClickResponse {
	
	private boolean clickSuccess;
	private String operation;
	private String soapFaultCode;
	private String soapFaultReason;
	private String schedulingErrorNumber;
	private String schedulingErrorDescription;
	
	@ApiModelProperty(value="Soap Fault Code", dataType="String")
	public String getSoapFaultCode() {
		return soapFaultCode;
	}

	public void setSoapFaultCode(String soapFaultCode) {
		this.soapFaultCode = soapFaultCode;
	}

	@ApiModelProperty(value="Soap Fault Reason", dataType="String")
	public String getSoapFaultReason() {
		return soapFaultReason;
	}

	public void setSoapFaultReason(String soapFaultReason) {
		this.soapFaultReason = soapFaultReason;
	}
	
	@ApiModelProperty(value="Scheduling Error Number", dataType="String")
	public String getSchedulingErrorNumber() {
		return schedulingErrorNumber;
	}

	public void setSchedulingErrorNumber(String string) {
		this.schedulingErrorNumber = string;
	}

	@ApiModelProperty(value="Scheduling Error Description", dataType="String")
	public String getSchedulingErrorDescription() {
		return schedulingErrorDescription;
	}

	public void setSchedulingErrorDescription(String schedulingErrorDescription) {
		this.schedulingErrorDescription = schedulingErrorDescription;
	}

	@ApiModelProperty(value="Click Schedule Service Operation", dataType="String")
	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	@ApiModelProperty(value="Click Schedule Service Operation Create/Update/Cancel Task or Assignment result", dataType="String")
	public boolean getClickSuccess() {
		return clickSuccess;
	}

	public void setClickSuccess(boolean clickSuccess) {
		this.clickSuccess = clickSuccess;
	}
}

	