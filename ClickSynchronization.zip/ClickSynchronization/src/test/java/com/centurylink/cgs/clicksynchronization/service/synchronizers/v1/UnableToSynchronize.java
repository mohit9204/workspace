package com.centurylink.cgs.clicksynchronization.service.synchronizers.v1;

import java.util.HashMap;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

public class UnableToSynchronize extends ClickSynchronizer {

	
	public static int secondsToPause = 0;
	
	
	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(UnableToSynchronize.class);
		LogContext context = new LogContext().add(LogContextHelper.get(failure, false));
		Configuration config= Configuration.getInstance();
		LOG.info(context.setMessage("Unable to SYNCHRONIZE"));
		jobsDao.failClickError(failure.getErrorMessageId());
		HashMap<String, String> options = config.getDispatchRefTable("CLICK_SYNC_EMAIL_DEV");
		try {
			emaliHelper.sendEmail(failure, options);
		} catch (ClickSynchronizationException e) {
			LOG.error(e);
		}

	}
	/*private void sendEmail(FailedMessage failure) throws ClickSynchronizationException {
		Configuration config= Configuration.getInstance();
		
		Mailer mailer = Mailer.getInstance();
		HashMap<String, String> options = config.getDispatchRefTable("CLICK_SYNC_EMAIL_DEV");
		String subject = options.get("subject");
		String mailTo = options.get("mailTo");
		String mailFrom = options.get("mailFrom");
		String messageBodyTemplate = "The correlationId %s failed with the message \n\n\"%s\".  \n\nPlease resolve the issue in Click and retry using the link \n\n%s/%s";
		String messageBody = String.format(messageBodyTemplate, 
												failure.getCorrelationId(), 
												failure.getErrorMessage(), 
												config.getRetryEndpoint(),
												failure.getCorrelationId());
		String attachmentName = "Message.xml";
		String attachmentContent = failure.getMessage();
		mailer.send(subject, mailTo, mailFrom, messageBody, attachmentName, attachmentContent);
	}*/
}
