package com.centurylink.cgs.clicksynchronization.service.synchronizers.v4;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.DistrictReference;
import com.clicksoftware.EngineerReference;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.Task.PreferredEngineers;
import com.clicksoftware.Task.RequiredEngineers;

public class PreferredRequiredEngineerSynchronizer extends ClickSynchronizer {

	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(PreferredRequiredEngineerSynchronizer.class);
		LogContext context = new LogContext().add(LogContextHelper.get(failure, false));

		ProcessTaskEx message = RequestMarshaller.unMarshallProcessTaskEx(failure.getMessage());
		
		boolean validEngineerFound = false;
		boolean preferredIsValid = true;
		boolean requiredIsValid = true;
		if (message != null && message.getTask() != null) {
			if( message.getTask().getPreferredEngineers() != null) {
				PreferredEngineers preferredEngineers = message.getTask().getPreferredEngineers();
				for (EngineerReference engineer : preferredEngineers.getPreferredEngineer()) {
					context.add("preferredEngineerId",engineer.getID());
					if (engineer.getDistrict() != null && isValidTechnicianDistrict(engineer.getID(), engineer.getDistrict().getName())) {
						context.add("preferredEngineerDistrict",engineer.getDistrict().getName());
						LOG.info(context.setMessage("Preferred Engineer reference is valid"));
						validEngineerFound = true;
					} else {
						String district = GetTechnicianDistrict(engineer.getID());
						if (district != null) {
							DistrictReference districtReference = new DistrictReference();
							districtReference.setName(district);
							engineer.setDistrict(districtReference);		
							LOG.info(context.setMessage("Using district from database for Preferred Engineer").add("preferredEngineerDistrict",district));
							validEngineerFound = true;
						} else
							preferredIsValid = false;
					}
				}
			}
			if( message.getTask().getRequiredEngineers() != null) {
				RequiredEngineers preferredEngineers = message.getTask().getRequiredEngineers();
				for (EngineerReference engineer : preferredEngineers.getRequiredEngineer()) {
					context.add("requiredEngineerId",engineer.getID());
					if (engineer.getDistrict() != null && isValidTechnicianDistrict(engineer.getID(), engineer.getDistrict().getName())) {
						context.add("requiredEngineerDistrict",engineer.getDistrict().getName());
						LOG.info(context.setMessage("Required Engineer reference is valid"));
						validEngineerFound = true;
					} else {
						String district = GetTechnicianDistrict(engineer.getID());
						if (district != null) {
							DistrictReference districtReference = new DistrictReference();
							districtReference.setName(district);
							engineer.setDistrict(districtReference);
							LOG.info(context.setMessage("Using district from database for Required Engineer").add("requiredEngineerDistrict",district));
							validEngineerFound = true;
						} else
							requiredIsValid = false;
					}
				}
			}
		}
		if (!validEngineerFound) {
			LOG.warn(context.setMessage("No valid engineers found. Setting preferred and required to null"));
			message.getTask().setPreferredEngineers(null);
			message.getTask().setRequiredEngineers(null);
		}
			
		if (requiredIsValid && !preferredIsValid) {
			LOG.info(context.setMessage("Preferred engineer is invalid, using required engineer as preferred"));
			message.getTask().getPreferredEngineers().getPreferredEngineer().clear();
			for (EngineerReference engineer : message.getTask().getRequiredEngineers().getRequiredEngineer()) {
				message.getTask().getPreferredEngineers().getPreferredEngineer().add(engineer);	
			}
		}
		if (!requiredIsValid && preferredIsValid) {
			LOG.info(context.setMessage("Required engineer is invalid, using preferred engineer as required"));
			message.getTask().getRequiredEngineers().getRequiredEngineer().clear();
			for (EngineerReference engineer : message.getTask().getPreferredEngineers().getPreferredEngineer()) {
				message.getTask().getRequiredEngineers().getRequiredEngineer().add(engineer);	
			}
		}
		LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
		jobsDao.completeClickError(failure.getErrorMessageId());	
		incrementRetryCounter(failure.getId());
		LOG.info(context.setMessage("Resending modified CLICK_SYNC_MESSAGE"));
		processTaskExClickClient.processTaskEx(message);
		LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record synchronized"));
		jobsDao.synchronizeClickSyncMessage(failure.getId());
	}
	private boolean isValidTechnicianDistrict(String techId, String district) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("techId", techId);
		paramMap.put("district", district);
		String query = "select tech_id, district from click_technician_v where tech_Id = :techId and district = :district";
		List<Map<String, Object>> map =  dao.getNamedParameterJdbcTemplate().queryForList(query, paramMap);
		if (map.size() > 0)
			return true;
		else
			return false;
	}
	private String GetTechnicianDistrict(String techId) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("techId", techId);
		String query = "select tech_id, district from click_technician_v  where tech_Id = :techId "; 
		List<Map<String, Object>> map =  dao.getNamedParameterJdbcTemplate().queryForList(query, paramMap);
		if (map.size() > 0)
			return map.get(0).get("DISTRICT").toString();
		else
			return null;
	}
	private void incrementRetryCounter(int messageId) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("messageId", messageId);
		String query = "update click_sync_message set retry_cnt = retry_cnt + 1, update_dt = systimestamp where message_id = :messageId "; 
		dao.getNamedParameterJdbcTemplate().update(query, paramMap);
		return;
	}
}
