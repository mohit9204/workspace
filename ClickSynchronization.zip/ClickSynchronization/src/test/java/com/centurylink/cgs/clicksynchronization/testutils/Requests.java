package com.centurylink.cgs.clicksynchronization.testutils;

public class Requests {
	public static final String TRACS_REQUEST = 
			"{ " +
					"  \"callingSystem\" : \"DGW\", " +
					"  \"originatingSystem\" : \"TRACS\", " +
					"  \"statusBackEndpoint\" : \"\", " +
					"  \"transactionId\" : \"145230842\", " +
					"  \"altCorrelationId\" : \"3108671\", " +
					"  \"numberEngineers\" : 1, " +
					"  \"statusBackServiceType\" : \"REST\", " +
					"  \"priority\" : 5, " +
					"  \"wireCenter\" : \"WDLYAL\", " +
					"  \"serviceType\" : \"Repair\", " +
					"  \"jobLocation\" : { " +
					"    \"street\" : \"53814 HWY 22\", " +
					"    \"city\" : \"WADLEY\", " +
					"    \"state\" : \"AL\", " +
					"    \"zipCode\" : \"\", " +
					"    \"country\" : \"US\", " +
					"    \"geoLocation\" : { " +
					"      \"longitude\" : -85.479008, " +
					"      \"latitude\" : 33.129354 " +
					"    } " +
					"  }, " +
					"  \"customerInfo\" : { " +
					"    \"customerName\" : \"ALEX SERASICO\", " +
					"    \"contactName\" : \"Alex Serasico\", " +
					"    \"phoneNumber\" : \"2562399997\", " +
					"    \"maintenancePlan\" : \"\" " +
					"  }, " +
					"  \"appointment\" : { " +
					"    \"earlyStart\" : \"2019-05-23T07:00:00\", " +
					"    \"apptStart\" : \"2019-05-23T08:00:00\", " +
					"    \"apptFinish\" : \"2019-05-23T12:00:00\", " +
					"    \"dueDate\" : \"2019-05-23T14:45:00\", " +
					"    \"futureAppt\" : false " +
					"  }, " +
					"  \"taskType\" : \"HSXXXXXNSLRRP\", " +
					"  \"technology\" : \"ADSL\", " +
					"  \"productType\" : \"HSI\", " +
					"  \"downstreamSpeed\" : \"0\", " +
					"  \"customerType\" : \"Residential\", " +
					"  \"onHold\" : false, " +
					"  \"isNicOne\" : \"false\", " +
					"  \"isInside\" : false, " +
					"  \"durationSec\" : 0, " +
					"  \"taskCodes\" : [ ], " +
					"  \"hostTrackingNum\" : \"TRAL000310867100\", " +
					"  \"altTrackingNum\" : \"3108671\", " +
					"  \"manualScheduleFlag\" : false, " +
					"  \"order\" : { " +
					"    \"orderType\" : \"M\", " +
					"    \"remarks\" : [ { " +
					"      \"remarkType\" : \"SUBSEQUENT-1\", " +
					"      \"remarkText\" : \"REM-RESV# AAAL000310867100 BOOKED\" " +
					"    }, { " +
					"      \"remarkType\" : \"ANSWER\", " +
					"      \"remarkText\" : \"Connectivity:No Sync:Dispatch:Customer:dispatch:\" " +
					"    }, { " +
					"      \"remarkType\" : \"DISPATCH\", " +
					"      \"remarkText\" : \"INT0000000068480\" " +
					"    } ] " +
					"  }, " +
					"  \"repair\" : { " +
					"    \"troubleType\" : \"OOS\", " +
					"    \"urls\" : [ ] " +
					"  }, " +
					"  \"openDate\" : \"2019-05-20T16:03:00\", " +
					"  \"csProductType\" : \"Biz&Res OOS(RP)\", " +
					"  \"nextDayCancel\" : \"N\", " +
					"  \"clickTaskTypeDescription\" : \"HSI - No Signal/No Sync Res Repair\", " +
					"  \"autoCancel\" : \"Y\", " +
					"  \"tncktId\" : \"2563951159\" " +
					"} ";
	public static final String NTM_REQUEST_LONG_WIRE_CENTER =
			"{ " +
					"  \"callingSystem\" : \"DGW\", " +
					"  \"originatingSystem\" : \"nativentm\", " +
					"  \"statusBackEndpoint\" : \"http://dgwjws-services.foss.corp.intranet/mdw/services/REST\", " +
					"  \"transactionId\" : \"92185\", " +
					"  \"altCorrelationId\" : \"NTMed33265b20190616\", " +
					"  \"numberEngineers\" : 1, " +
					"  \"statusBackServiceType\" : \"REST\", " +
					"  \"priority\" : 3, " +
					"  \"wireCenter\" : \"NNPLFLBHRLB101000499\", " +
					"  \"serviceType\" : \"Repair\", " +
					"  \"jobLocation\" : { " +
					"    \"street\" : \"8371 BAY COLONY DR.\", " +
					"    \"city\" : \"NORTH NAPLES\", " +
					"    \"state\" : \"FL\", " +
					"    \"zipCode\" : \"34108\", " +
					"    \"country\" : \"US\", " +
					"    \"address2\" : \"NMCB\", " +
					"    \"geoLocation\" : { " +
					"      \"longitude\" : -81.820541, " +
					"      \"latitude\" : 26.244819, " +
					"      \"latLonAccuracy\" : \"1\" " +
					"    } " +
					"  }, " +
					"  \"customerInfo\" : { " +
					"    \"customerName\" : \"PMAG-Resolve\", " +
					"    \"contactName\" : \"Network Ticket\", " +
					"    \"phoneNumber\" : \"8006589033\", " +
					"    \"maintenancePlan\" : \"\" " +
					"  }, " +
					"  \"appointment\" : { " +
					"    \"earlyStart\" : \"2019-06-17T07:00:00\", " +
					"    \"dueDate\" : \"2019-06-17T11:11:25\", " +
					"    \"futureAppt\" : false " +
					"  }, " +
					"  \"taskType\" : \"ALCOXXXXXC\", " +
					"  \"productType\" : \"OTHER\", " +
					"  \"downstreamSpeed\" : \"0\", " +
					"  \"customerType\" : \"Residential\", " +
					"  \"onHold\" : false, " +
					"  \"isNicOne\" : \"false\", " +
					"  \"isInside\" : false, " +
					"  \"durationSec\" : 0, " +
					"  \"taskCodes\" : [ ], " +
					"  \"hostTrackingNum\" : \"NTM000022448896\", " +
					"  \"manualScheduleFlag\" : false, " +
					"  \"order\" : { " +
					"    \"orderType\" : \"M\", " +
					"    \"remarks\" : [ { " +
					"      \"remarkType\" : \"TROUBLE_COMMENTS\", " +
					"      \"remarkText\" : \"NNPLFLBHRLB101000499 10.61.24.36 MARCONI IMA_LINK 10.61.24.36 [odu506:1/13/1/5][Problem:imaLinkOutOfDelaySync] DISC*S imaLinkOutOfDelaySync Don't call/cLink Or Close If Fixed\" " +
					"    } ] " +
					"  }, " +
					"  \"repair\" : { " +
					"    \"troubleType\" : \"Marconi DISC* Copper\", " +
					"    \"urls\" : [ ] " +
					"  }, " +
					"  \"openDate\" : \"2019-06-16T11:11:42\", " +
					"  \"nextDayCancel\" : \"N\", " +
					"  \"clickTaskTypeDescription\" : \"SWITCH_CENTRAL_OFFICE (OUTSIDE_TECH)\", " +
					"  \"autoCancel\" : \"N\", " +
					"  \"tncktId\" : \"N/A\" " +
					"} ";
}
