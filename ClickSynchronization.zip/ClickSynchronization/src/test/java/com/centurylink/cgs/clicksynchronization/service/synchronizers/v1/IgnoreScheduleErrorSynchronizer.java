package com.centurylink.cgs.clicksynchronization.service.synchronizers.v1;

import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

public class IgnoreScheduleErrorSynchronizer extends ClickSynchronizer {

	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(IgnoreScheduleErrorSynchronizer.class);
		LogContext context = new LogContext().add(LogContextHelper.get(failure, false));

		LOG.info(context.setMessage("Ignoring scheduling error.  CLICK_SYNC_ERROR set to Complete and CLICK_SYNC_MSSAGE set to Synchronized"));
		jobsDao.synchronizeClickSyncMessage(failure.getId());
		jobsDao.completeClickError(failure.getErrorMessageId());
	}
}
