package com.centurylink.cgs.clicksynchronization.service.synchronizers.v6;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Configuration;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.clicksynchronization.util.Util;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.ProcessTaskExResponse;
import com.clicksoftware.UpdateTaskAssignmentEx;
import com.clicksoftware.UpdateTaskAssignmentExResponse;

@Component
public class TaskHasNoAssignmentSynchronizer extends ClickSynchronizer {

	private static final String FETCH_ASSIGNED_DATA_FOR_ALLOCATION = 
			"SELECT TECH_ID, " +
	        "       TECH_NAME, " +
			"       DISTRICT, " +
			"       ASSIGNMENT_START, " +
			"       ASSIGNMENT_FINISH " +
			"  FROM (SELECT ADH.TECH_ID, " +
			"               ADH.TECH_NAME, " +
			"               CTV.DISTRICT, " +
			"               CTV.CREATE_DT, " +
			"               ADH.ASSIGNMENT_START, " +
			"               ADH.ASSIGNMENT_FINISH, " +
			"               MAX (CTV.CREATE_DT) OVER (PARTITION BY CTV.TECH_ID) MAX_DT " +
			"          FROM ASSIGNMENT_DETAILS_HIST ADH " +
			"               INNER JOIN CLICK_TECHNICIAN_V CTV ON ADH.TECH_ID = CTV.TECH_ID " +
			"               INNER JOIN JOBS_DETAIL_HIST J " +
			"                  ON ADH.CORRELATION_ID = J.CORRELATION_ID " +
			"         WHERE     J.UPDATE_DT = " +
			"                      (SELECT MAX (UPDATE_DT) " +
			"                         FROM JOBS_DETAIL_HIST " +
			"                        WHERE     CORRELATION_ID = J.CORRELATION_ID " +
			"                              AND TASK_STATUS = 'Assigned') " +
			"               AND ADH.UPDATE_DT = " +
			"                      (SELECT MAX (UPDATE_DT) " +
			"                         FROM ASSIGNMENT_DETAILS_HIST " +
			"                        WHERE     CORRELATION_ID = J.CORRELATION_ID " +
			"                              AND TECH_ID = J.TECH_ID) " +
			"               AND ADH.CORRELATION_ID = " +
			"                      (SELECT CORRELATION_ID " +
			"                         FROM (SELECT CORRELATION_ID KEY, CORRELATION_ID " +
			"                                 FROM JOBS_DETAIL " +
			"                               UNION ALL " +
			"                               SELECT CORRELATION_ID KEY, " +
			"                                      PARENT_CORRELATION_ID CORRELATION_ID " +
			"                                 FROM DISPATCH_GROUP_DETAILS) " +
			"                        WHERE KEY = :correlationId)) " +
			" WHERE CREATE_DT = MAX_DT ";
	
	private static final String FETCH_DATA_FOR_ALLOCATION =
			"SELECT ADH.TECH_ID, " +
			"       ADH.TECH_NAME, " +
			"       T.DISTRICT, " +
			"       ADH.ASSIGNMENT_START, " +
			"       ADH.ASSIGNMENT_FINISH " +
			"  FROM ASSIGNMENT_DETAILS_HIST ADH " +
			"       INNER JOIN CLICK_TECHNICIAN_V T ON ADH.TECH_ID = T.TECH_ID " +
			" WHERE     ADH.UPDATE_DT = " +
			"              (SELECT MAX (UPDATE_DT) " +
			"                 FROM ASSIGNMENT_DETAILS_HIST " +
			"                WHERE     CORRELATION_ID = ADH.CORRELATION_ID " +
			"                      AND TECH_ID IS NOT NULL) " +
			"       AND T.CREATE_DT = (SELECT MAX (CREATE_DT) " +
			"                            FROM CLICK_TECHNICIAN_V " +
			"                           WHERE TECH_ID = T.TECH_ID) " +
			"       AND ADH.CORRELATION_ID = " +
			"              (SELECT CORRELATION_ID " +
			"                 FROM (SELECT CORRELATION_ID KEY, CORRELATION_ID " +
			"                         FROM JOBS_DETAIL " +
			"                       UNION ALL " +
			"                       SELECT CORRELATION_ID KEY, " +
			"                              PARENT_CORRELATION_ID CORRELATION_ID " +
			"                         FROM DISPATCH_GROUP_DETAILS) " +
			"                WHERE KEY = :correlationId) ";
	private static final String UPDATE_ASSIGNMENT_DETAILS =
			"UPDATE ASSIGNMENT_DETAILS " +
					"   SET TECH_ID = :techId, " +
					"       TECH_NAME = :techName, " +
					"       ASSIGNMENT_START = :assignmentStart, " +
					"       ASSIGNMENT_FINISH = :assignmentFinish, " +
					"       UPDATE_DT = SYSTIMESTAMP " +
					" WHERE CORRELATION_ID IN (SELECT CORRELATION_ID " +
					"                            FROM (SELECT CORRELATION_ID KEY, CORRELATION_ID " +
					"                                    FROM JOBS_DETAIL " +
					"                                   WHERE TASK_STATUS NOT IN ('Completed', " +
					"                                                             'Cancelled') " +
					"                                  UNION ALL " +
					"                                  SELECT G.CORRELATION_ID KEY, " +
					"                                         M.CORRELATION_ID " +
					"                                    FROM DISPATCH_GROUP_MEMBERS M " +
					"                                         INNER JOIN JOBS_DETAIL J " +
					"                                            ON J.CORRELATION_ID = " +
					"                                                  M.CORRELATION_ID " +
					"                                         INNER JOIN DISPATCH_GROUP_DETAILS G " +
					"                                            ON G.GROUP_ID = M.GROUP_ID " +
					"                                   WHERE J.TASK_STATUS NOT IN ('Completed', " +
					"                                                               'Cancelled')) " +
					"                           WHERE KEY = :correlationId) and (tech_id is null or tech_id <> :techId) ";
	
	private static final String UPDATE_GROUP_STATUS = 
					"UPDATE DISPATCH_GROUP_STATUS " +
					"   SET TECH_ID = :techId, " +
					"       TECH_NAME = :techName, " +
					"       ASSIGNMENT_START = :assignmentStart, " +
					"       ASSIGNMENT_FINISH = :assignmentFinish, " +
					"       UPDATE_DT = SYSTIMESTAMP " +
					" WHERE  GROUP_ID = (SELECT GROUP_ID FROM DISPATCH_GROUP_DETAILS WHERE CORRELATION_ID = :correlationId) AND (TECH_ID IS NULL OR TECH_ID <> :techId)" ;
	
	ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(TaskHasNoAssignmentSynchronizer.class);
	
	@Override
	public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
		UpdateTaskAssignmentEx message = null;
		try {
			ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(TaskHasNoAssignmentSynchronizer.class);
			LogContext context = new LogContext().add(LogContextHelper.get(failure, false));
			message = RequestMarshaller.unMarshallUpdateTaskAssignmentEx(failure.getMessage());
			List<Map<String, Object>> techDetailList =  getAssignedTechDetailsByCorrelationId(failure.getCorrelationId());
			if (Util.isListNullOrEmpty(techDetailList)){
				techDetailList = getAllocatedTechDetailsByCorrelationId(failure.getCorrelationId());
			} 
			if (Util.isListNullOrEmpty(techDetailList)) { 
				Configuration config= Configuration.getInstance();
				LOG.info(context.setMessage("Unable to SYNCHRONIZE"));
				jobsDao.failClickError(failure.getErrorMessageId());
				HashMap<String, String> options = config.getDispatchRefTable("CLICK_SYNC_EMAIL_DEV");
				try {
					emaliHelper.sendEmail(failure, options);
				} catch (ClickSynchronizationException e) {
					LOG.error(e);
				}
				LOG.info(context.setMessage("No Technician found to Allocate" + message.getTask().getCallID()));
			}
			else {
				ProcessTaskExResponse processExResponse = clickHelper.allocateTask(message,techDetailList);
				LOG.info(context.setMessage("Assignment message sent to Click (Allocate)"));
				updateAssignmentDetails(failure.getCorrelationId(), techDetailList);
				LOG.info(context.setMessage("Assignment details records updated to last assigned tech"));
				message.getTask().getStatus().setName(Constants.STATUS_ASSIGNED);
				message.getTask().getStatus().setDisplayString(Constants.STATUS_ASSIGNED);
				UpdateTaskAssignmentExResponse result = updateTaskAssignmentExClickClient.updateTaskAssignmentEx(message);
				LOG.info(context.setMessage("Assigned message sent to Click"));
				jobsDao.retryClickSyncMessage(failure.getId());
				LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
				jobsDao.completeClickError(failure.getErrorMessageId());
			}
		} catch (ClickSynchronizationException e) {
			LOG.error(e);
		} catch (Exception ex) {
			ClickSynchronizationException exception = new ClickSynchronizationException(ex.getMessage(), ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_ALL_EXCEPTIONS, LogContextHelper.get(message));
			LOG.error(exception);
		}

	}

	private List<Map<String, Object>> getAssignedTechDetailsByCorrelationId(String correlationId) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);
		return dao.getNamedParameterJdbcTemplate().queryForList(FETCH_ASSIGNED_DATA_FOR_ALLOCATION, paramMap);
	}
	private List<Map<String, Object>> getAllocatedTechDetailsByCorrelationId(String correlationId) {
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);
		return dao.getNamedParameterJdbcTemplate().queryForList(FETCH_DATA_FOR_ALLOCATION, paramMap);
	}
	private void updateAssignmentDetails(String correlationId, List<Map<String, Object>> techDetailList) {
		Date assignmentStart = (Date)techDetailList.get(0).get("ASSIGNMENT_START");
		Date assignmentFinish = (Date)techDetailList.get(0).get("ASSIGNMENT_FINISH");
		String techId = (String) techDetailList.get(0).get("TECH_ID");
		String techName = (String) techDetailList.get(0).get("TECH_NAME");
		String district = (String) techDetailList.get(0).get("DISTRICT");
		NamedParameterJdbcDaoSupport dao = new NamedParameterJdbcDaoSupport();
		dao.setDataSource(configuration.getDataSource());
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("correlationId", correlationId);
		paramMap.put("techId", techId);
		paramMap.put("techName", techName);
		paramMap.put("assignmentStart", assignmentStart);
		paramMap.put("assignmentFinish", assignmentFinish);
		dao.getNamedParameterJdbcTemplate().update(UPDATE_ASSIGNMENT_DETAILS, paramMap);
		dao.getNamedParameterJdbcTemplate().update(UPDATE_GROUP_STATUS, paramMap);
	}
}
