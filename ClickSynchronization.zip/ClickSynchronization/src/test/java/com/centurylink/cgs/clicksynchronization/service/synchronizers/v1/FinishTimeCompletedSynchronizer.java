package com.centurylink.cgs.clicksynchronization.service.synchronizers.v1;

import com.centurylink.cgs.clicksynchronization.exception.AlarmId;
import com.centurylink.cgs.clicksynchronization.exception.ClickSynchronizationException;
import com.centurylink.cgs.clicksynchronization.helper.LogContextHelper;
import com.centurylink.cgs.clicksynchronization.logging.ClickSynchronizationLogger;
import com.centurylink.cgs.clicksynchronization.model.ClickSynchronizer;
import com.centurylink.cgs.clicksynchronization.model.FailedMessage;
import com.centurylink.cgs.clicksynchronization.util.Constants;
import com.centurylink.cgs.clicksynchronization.util.RequestMarshaller;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.clicksoftware.UpdateTaskAssignmentEx;


public class FinishTimeCompletedSynchronizer extends ClickSynchronizer {

    @Override
    public void synchronize(FailedMessage failure) throws ClickSynchronizationException {
        ClickSynchronizationLogger LOG = ClickSynchronizationLogger.getLogger(FinishTimeCompletedSynchronizer.class);
        LogContext context = new LogContext().add(LogContextHelper.get(failure, false));
        UpdateTaskAssignmentEx message = RequestMarshaller.unMarshallUpdateTaskAssignmentEx(failure.getMessage());
        if (Constants.STATUS_COMPLETED.equals(message.getTask().getStatus().getName())) {
            LOG.info(context.setMessage("Ignoring message on completed task"));
            LOG.info(context.setMessage("CLICK_SYNC_MESSAGE record set to Synchronized"));
            jobsDao.synchronizeClickSyncMessage(failure.getId());
            LOG.info(context.setMessage("CLICK_SYNC_ERROR record completed"));
            jobsDao.completeClickError(failure.getErrorMessageId());
            
        } else {
            throw new ClickSynchronizationException("Unexpected condition in FinishTimeCompletedSynchronizer",
                                                        AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_ALL_EXCEPTIONS, 
                                                        context);
        }
    }
}

