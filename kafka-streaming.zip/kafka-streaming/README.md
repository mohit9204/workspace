## kafka-streaming

### Sample kafka java client project for publisher and consumer utilities for C360 kafka streaming platform.


``` mvn clean spring-boot:run ```

#### To run againest specific spring profile, please pass additional jvm argument spring.profiles.active. For example to run with dev profile, use -Dspring.profiles.active=dev

For any additional clarifications/help, please reach out to Sambasiva.Tatikonda@CenturyLink.com