package com.centurylink.hyperlite.kafka.streaming.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;

/**
 * @author Sambasiva Tatikonda
 * @since 1.0.0
 */
@Configuration
@EnableKafka
public class KafkaConsumerConfig {
	// INFO: Will add any future consumer configuration related beans here
}