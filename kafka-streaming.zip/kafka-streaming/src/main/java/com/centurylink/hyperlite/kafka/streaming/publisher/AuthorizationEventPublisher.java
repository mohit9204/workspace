package com.centurylink.hyperlite.kafka.streaming.publisher;

import java.time.Instant;
import java.util.UUID;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.concurrent.ListenableFuture;

import com.centurylink.hyperlite.event.AuthorizationEvent;

/**
 * @author Sambasiva Tatikonda
 * @since 1.0.0
 */
@Component
public class AuthorizationEventPublisher implements ApplicationRunner {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthorizationEventPublisher.class);
	
	@Autowired
    private KafkaTemplate<String, AuthorizationEvent> kafkaTemplate;
	
	@Override
	@Transactional
	public void run(ApplicationArguments args) throws Exception {
		
		LOGGER.info("Inside run AuthorizationEventPublisher");
		
		AuthorizationEvent event = AuthorizationEvent.newBuilder()
				.setEventId(UUID.randomUUID().toString())
				.setEventType("created")
				.setEventCategory("billing")
				.setEventPublisherId("ivr")
				.setEventSource("dlomp93y.corp.intranet")
				.setEventTimestamp(Instant.now().toString())
				.setAccountNumber("A1110001")
				.setCustomerName("LEROY JENKINS")
				.setStartDateTime(Instant.now().toString())
				.setAuthorizationStatus("SUCCESS")
				.setUcid("101-ucid-value")
				.setAni("ANI-100001")
				.setAccountType("CONSUMER")
				.setIsPrepaid(false)
				.setAuthorizedPartyName("LEROY JENKINS")
				.setAgentCuid("AB12340")
				.setAuthorizationType("ssnLast4")
				.setAuthorizationCategory("nonOnline")
				.setAuthorizationRiskLevel("low")
				.build();
		
		// LOGGER.info(event.toString());
		
		ListenableFuture<SendResult<String, AuthorizationEvent>> resultFtrObj = this.kafkaTemplate.send("authorization-event", event.getAccountNumber(), event);
		if(resultFtrObj.isDone()) {
			SendResult<String, AuthorizationEvent> resultContainer = resultFtrObj.get();
			if (resultContainer!=null & resultContainer.getRecordMetadata()!=null) {
				RecordMetadata metadata = resultContainer.getRecordMetadata();
				LOGGER.info("Topic = " + metadata.topic());
				LOGGER.info("Partition = " + metadata.partition());
				LOGGER.info("Offset = " + metadata.offset());
			}
		}
		
		LOGGER.info("Successfully published the message with key =" + event.getAccountNumber() + " and value = " + event.toString());
	}
}
