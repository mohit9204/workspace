package com.centurylink.hyperlite.kafka.streaming.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.centurylink.hyperlite.event.ValueStreamEvent;

/**
 * @author Sambasiva Tatikonda
 * @since 1.0.0
 */
@Component
public class ValueStreamEventConsumer {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValueStreamEventConsumer.class);
	
	@KafkaListener(topics = "${hyperlite.event.value-stream-event.consumer.topic}", groupId = "${hyperlite.event.value-stream-event.consumer.group-id}")
	@Transactional
	public void receive(ConsumerRecord<String, ValueStreamEvent> consumerRecord) {
		LOGGER.info("Inside receive ValueStreamEventConsumer");
		
		try {
			LOGGER.info("Message Key-->" + consumerRecord.key());
			LOGGER.info("Message Value-->" + consumerRecord.value().toString());
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

	}
}