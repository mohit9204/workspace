package com.centurylink.hyperlite.kafka.streaming.publisher;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.concurrent.ListenableFuture;

import com.centurylink.hyperlite.event.AgileReleaseTrain;
import com.centurylink.hyperlite.event.Team;
import com.centurylink.hyperlite.event.TeamMember;
import com.centurylink.hyperlite.event.ValueStreamEvent;

@Component
public class ValueStreamEventPublisher implements ApplicationRunner {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValueStreamEventPublisher.class);
	
	@Autowired
    private KafkaTemplate<String, ValueStreamEvent> kafkaTemplate;
	
	@Override
	@Transactional
	public void run(ApplicationArguments args) throws Exception {
		
		LOGGER.info("Inside run ValueStreamEventPublisher");
		
		TeamMember tm1 = TeamMember.newBuilder()
				.setCuid("AC18385")
				.setFirstName("Brad")
				.setLastName("Haiar")
				.setEmail("Brad.Haiar@centurylink.com")
				.setTitle("Product Owner")
				.build();
		
		TeamMember tm2 = TeamMember.newBuilder()
				.setCuid("aa06046")
				.setFirstName("Deborah (Debbie) A")
				.setLastName("Snell")
				.setEmail("debbie.a.snell@centurylink.com")
				.setTitle("Scrum Master")
				.build();
		
		TeamMember tm3 = TeamMember.newBuilder()
				.setCuid("statiko")
				.setFirstName("Sambasiva")
				.setLastName("Tatikonda")
				.setEmail("sambasiva.tatikonda@centurylink.com")
				.setTitle("Developer")
				.build();
		
		List<TeamMember> t1Members = new ArrayList<TeamMember>();
		t1Members.add(tm1);
		t1Members.add(tm2);
		t1Members.add(tm3);
		
		
		Team t1 = Team.newBuilder()
				.setName("ID-Account")
				.setEmail("c360-ID-Account@centurylink.com")
				.setMembers(t1Members)
				.build();
		
		Team t2 = Team.newBuilder()
				.setName("Order-Fulfillment")
				.setEmail("c360-order-fulfillment@centurylink.com")
				.build();
		
		Team t3 = Team.newBuilder()
				.setName("Notification-Dispatch")
				.setEmail("c360-notification-dispatch@centurylink.com")
				.build();
		
		Team t4 = Team.newBuilder()
				.setName("Service Usage-Network")
				.setEmail("c360-ServiceUse-Network@centurylink.com")
				.build();
		
		Team t5 = Team.newBuilder()
				.setName("Conversation")
				.setEmail("c360-conversation@centurylink.com")
				.build();
		
		List<Team> art1Teams = new ArrayList<Team>();
		art1Teams.add(t1);
		art1Teams.add(t2);
		art1Teams.add(t3);
		art1Teams.add(t4);
		art1Teams.add(t5);
		
		AgileReleaseTrain art1 = AgileReleaseTrain.newBuilder()
				.setName("c360")
				.setRte("Carol Barlau")
				.setProductManager("Kristin Richmond")
				.setSystemArchitect("Raja Challapalli")
				.setTeams(art1Teams)
				.build();
		
		List<AgileReleaseTrain> vsEvent1Arts = new ArrayList<AgileReleaseTrain>();
		vsEvent1Arts.add(art1);
		
		ValueStreamEvent vsEvent1 = ValueStreamEvent.newBuilder()
				.setEventId(UUID.randomUUID().toString())
				.setEventType("updated")
				.setEventCategory("SAFe")
				.setEventPublisherId("statiko")
				.setEventSource("safe.host.com")
				.setEventTimestamp(Instant.now().toString())
				.setName("Responsive Services")
				.setAgileReleaseTrains(vsEvent1Arts)
				.build();
		
		//LOGGER.info(vsEvent1.toString());
		
		ListenableFuture<SendResult<String, ValueStreamEvent>> resultFtrObj = this.kafkaTemplate.send("value-stream-event", vsEvent1.getName(), vsEvent1);
		if(resultFtrObj.isDone()) {
			SendResult<String, ValueStreamEvent> resultContainer = resultFtrObj.get();
			if (resultContainer!=null & resultContainer.getRecordMetadata()!=null) {
				RecordMetadata metadata = resultContainer.getRecordMetadata();
				LOGGER.info("Topic = " + metadata.topic());
				LOGGER.info("Partition = " + metadata.partition());
				LOGGER.info("Offset = " + metadata.offset());
			}
		}
		
		LOGGER.info("Successfully published the message with key =" + vsEvent1.getName() + " and value = " + vsEvent1.toString());
	}
}
