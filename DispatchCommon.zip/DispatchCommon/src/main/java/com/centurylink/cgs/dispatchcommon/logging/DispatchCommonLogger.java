package com.centurylink.cgs.dispatchcommon.logging;

import com.centurylink.cgs.dispatchcommon.logging.DispatchLogger;

public class DispatchCommonLogger extends DispatchLogger {

	private static final String SERVICE_NAME = "DispatchCommon";
		
	private DispatchCommonLogger(Class clazz, String serviceName) {
		super(clazz, serviceName);
	}
	public static DispatchCommonLogger getLogger(Class clazz) {
		DispatchCommonLogger instance = new DispatchCommonLogger(clazz, SERVICE_NAME);
		return instance;
	}
}
