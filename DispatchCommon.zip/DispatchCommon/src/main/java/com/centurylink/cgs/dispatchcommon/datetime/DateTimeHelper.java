package com.centurylink.cgs.dispatchcommon.datetime;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class DateTimeHelper {
	public static String TIMEZONE_PACIFIC = "P";
	public static String TIMEZONE_MOUNTAIN = "M";
	public static String TIMEZONE_CENTRAL = "C";
	public static String TIMEZONE_EASTERN = "E";
	public static String TIMEZONE_UTC = "U";
	
	
	/**
	 * Converts the time value to GMT
	 * @param pTime
	 * @return
	 * @throws ParseException
	 */
	public static Timestamp convertToDatabaseTime(Timestamp pTime) throws ParseException {
		if (pTime == null)
			return null;
			
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSSSSSS");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		String time = sdf.format(pTime);
		sdf.setTimeZone(TimeZone.getDefault());
		return new Timestamp(sdf.parse(time).getTime());
	}
	/**
	 * Converts the GMT time value to one the default local time
	 * @param pTime
	 * @return
	 * @throws ParseException
	 */
	public static Timestamp convertToLocalTime(Timestamp utcTime) throws ParseException {
		if (utcTime == null)
			return null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSSSSSS");
		sdf.setTimeZone(TimeZone.getDefault());
		String time = sdf.format(utcTime);
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		return new Timestamp(sdf.parse(time).getTime());
	}
	/**
	 * Converts a given time to a value for the timezone provided.  Defaults to central time if
	 * pTimeZone is not P, M, C, or E
	 * @param pCalendar 
	 * @param pTimeZone 
	 * @return
	 * @throws ParseException
	 */
	public static Calendar convertToTimeZone(Calendar pCalendar, String pTimeZone) throws ParseException {
		String timeZoneName = "America/Chicago";
		
		if (pTimeZone.equals(TIMEZONE_PACIFIC))
			timeZoneName = "America/Los_Angeles";
		else if (pTimeZone.equals(TIMEZONE_MOUNTAIN))
			timeZoneName = "America/Denver";
		else if (pTimeZone.equals(TIMEZONE_CENTRAL))
			timeZoneName = "America/Chicago";
		else if (pTimeZone.equals(TIMEZONE_EASTERN))
			timeZoneName = "America/New_York";

		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSSSSSS");
		sdf.setTimeZone(TimeZone.getTimeZone(timeZoneName));
		String time = sdf.format(pCalendar.getTime());
		sdf.setTimeZone(TimeZone.getDefault());
		Calendar returnValue =  Calendar.getInstance();
		returnValue.setTime(sdf.parse(time));

		return returnValue;
	}
	public static Date convertToTimeZone(Date pDate, String pTimeZone) throws ParseException {
		String timeZoneName = "America/Chicago";
		
		if (pTimeZone.equals(TIMEZONE_PACIFIC))
			timeZoneName = "America/Los_Angeles";
		else if (pTimeZone.equals(TIMEZONE_MOUNTAIN))
			timeZoneName = "America/Denver";
		else if (pTimeZone.equals(TIMEZONE_CENTRAL))
			timeZoneName = "America/Chicago";
		else if (pTimeZone.equals(TIMEZONE_EASTERN))
			timeZoneName = "America/New_York";

		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSSSSSS");
		sdf.setTimeZone(TimeZone.getTimeZone(timeZoneName));
		String time = sdf.format(pDate);
		return sdf.parse(time);
	}
	public static Timestamp convertToTimeZone(Timestamp pTime,  String pTimeZone) throws ParseException {
		if (pTime == null)
			return null;
		String timeZoneName = "America/Chicago";
		
		if (pTimeZone.equals(TIMEZONE_PACIFIC))
			timeZoneName = "America/Los_Angeles";
		else if (pTimeZone.equals(TIMEZONE_MOUNTAIN))
			timeZoneName = "America/Denver";
		else if (pTimeZone.equals(TIMEZONE_CENTRAL))
			timeZoneName = "America/Chicago";
		else if (pTimeZone.equals(TIMEZONE_EASTERN))
			timeZoneName = "America/New_York";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSSSSSS");
		sdf.setTimeZone(TimeZone.getTimeZone(timeZoneName));
		String time = sdf.format(pTime);
		return new Timestamp(sdf.parse(time).getTime());
	}
	public static String convertToDateTimeString(Date pDate, String pTimeZone) {
		String timeZoneName = "America/Chicago";
		
		if (pTimeZone.equals(TIMEZONE_PACIFIC))
			timeZoneName = "America/Los_Angeles";
		else if (pTimeZone.equals(TIMEZONE_MOUNTAIN))
			timeZoneName = "America/Denver";
		else if (pTimeZone.equals(TIMEZONE_CENTRAL))
			timeZoneName = "America/Chicago";
		else if (pTimeZone.equals(TIMEZONE_EASTERN))
			timeZoneName = "America/New_York";
		else if  (pTimeZone.equals(TIMEZONE_UTC))
			timeZoneName = "GMT";
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss z"); //09-30-2014 16:35 UTC
		sdf.setTimeZone(TimeZone.getTimeZone(timeZoneName));
		return sdf.format(pDate);
	}
	public static String convertToDateTimeStringDefaultTimezone(Date pDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss"); //09-30-2014 16:35 UTC
		return sdf.format(pDate);
	}
	public static Timestamp convertToDateTimeDefaultTimeZone(String pDate) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss"); 
		return new Timestamp(sdf.parse(pDate).getTime());
	}
	public static Date convertToDate(String pDate, String pFormat) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(pFormat); 
		return sdf.parse(pDate);
	}
	public static Date parseDateTimeNoTimeZone(String dateTime)  throws ParseException {
		// CCYY-MM-DDThh:mm:ss
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.parse(dateTime);
	}
	public static Date parseDateTimeIgnoreTimeZone(String dateTime)  throws ParseException {
		
		try {
			Long longValue = Long.parseLong(dateTime);
			Date date = new Date(longValue);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //09-30-2014 16:35 UTC
			sdf.setTimeZone(TimeZone.getTimeZone(TIMEZONE_UTC));
			dateTime =  sdf.format(date);
		} catch(Exception e) {}
		// CCYY-MM-DDThh:mm:ss 
		String format = "yyyy-MM-dd HH:mm:ss";
		if (dateTime != null && dateTime.length() > format.length())
			dateTime = dateTime.substring(0,format.length());
		if (dateTime != null)
			dateTime = dateTime.replace('T', ' ');
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.parse(dateTime);
	}
	public static String formatDateTime(Date dateTime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //09-30-2014 16:35 UTC
		String string = sdf.format(dateTime);
		return string.replace(" ", "T");
	}
	public static Date parseDateTimeWithTimeZone(String dateTime)  throws ParseException {
		// CCYY-MM-DDThh:mm:ss
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSSXXX");
		return sdf.parse(dateTime);
	}
	public static XMLGregorianCalendar parseDateTime(String date, String time) throws ParseException, DatatypeConfigurationException {
	      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	      Date parsedDateTime = sdf.parse(date+ " " + time);
	      GregorianCalendar cal1 = new GregorianCalendar();
	      cal1.setTime(parsedDateTime);
	      return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal1);

	}
	public static XMLGregorianCalendar parseDate(String date) throws ParseException, DatatypeConfigurationException {
	      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	      Date parsedDate = sdf.parse(date);
	      GregorianCalendar cal1 = new GregorianCalendar();
	      cal1.setTime(parsedDate);
	      return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal1);

	}
	
}
