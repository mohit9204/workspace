package com.centurylink.cgs.dispatchcommon.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Information on a DB Connection")
public class DBConnection {
	private String databaseURL;
	private String databaseUser;
	private String connectionStatus = "NOT CHECKED";
	
	@ApiModelProperty(value="Database URL", dataType="string")
	public String getDatabaseURL() {
		return databaseURL;
	}
	public void setDatabaseURL(String databaseURL) {
		this.databaseURL = databaseURL;
	}
	
	@ApiModelProperty(value="Database User/Schema", dataType="string")
	public String getDatabaseUser() {
		return databaseUser;
	}
	public void setDatabaseUser(String databaseUser) {
		this.databaseUser = databaseUser;
	}
	
	@ApiModelProperty(value="Connection Status - string", dataType="string")
	public String getConnectionStatus() {
		return connectionStatus;
	}
	public void setConnectionStatus(String connectionStatus) {
		this.connectionStatus = connectionStatus;
	}
	
	

}
