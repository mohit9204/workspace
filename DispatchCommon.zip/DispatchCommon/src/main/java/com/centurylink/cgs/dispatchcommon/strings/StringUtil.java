package com.centurylink.cgs.dispatchcommon.strings;

public class StringUtil {
	public static final String EMPTY = "";
	
	/** Method is used to check, Object is null.
	 * @param input
	 * @return returns true if Object is null, otherwise false.
	 */
	public static boolean isObjectNull(Object object) {
		return (object == null);
	}
	
	/** Method is used to check, String is null or Empty.
	 * @param data
	 * @return returns true if String is null or empty, otherwise false.
	 */
	public static boolean isStringNullOrEmpty(String data) {
	    return (data == null || EMPTY.equals(data.trim()));
	  }
}
