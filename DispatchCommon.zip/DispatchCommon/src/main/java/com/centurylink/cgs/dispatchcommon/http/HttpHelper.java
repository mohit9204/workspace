package com.centurylink.cgs.dispatchcommon.http;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HttpHelper {

	private String mUrl;
	private HttpURLConnection mConnection;
	private int mResponseCode;
	private int mConnectionTimeoutMilliseconds = -1;
	private int mReadTimeoutMilliseconds = 20000; // Hard coded
	private Map<String, String> mHeaders;
	private boolean mIsSecure = false;
	public boolean isSecure() {
		return mIsSecure;
	}

	public void setSecure(boolean pIsSecure) {
		this.mIsSecure = pIsSecure;
	}

	public int getResponseCode() {
		return mResponseCode;
	}

	public int getConnectTimeout() {
		return mConnectionTimeoutMilliseconds;
	}

	public void setConnectTimeout(int timeout) {
		this.mConnectionTimeoutMilliseconds = timeout;
	}

	public int getReadTimeout() {
		return mReadTimeoutMilliseconds;
	}

	public void setReadTimeout(int timeout) {
		this.mReadTimeoutMilliseconds = timeout;
	}

	public Map<String, String> getHeaders() {
		return mHeaders;
	}

	public void setHeaders(Map<String, String> headers) {
		this.mHeaders = headers;
	}
	
	public void addHeader(String pName, String pValue ) {
		if (this.mHeaders == null) 
			this.mHeaders = new HashMap<String, String>();
		this.mHeaders.put(pName, pValue);
	}
	public HttpHelper(String url) {
		this.mUrl = url;
		if (url != null && url.toLowerCase().startsWith("https"))
			mIsSecure = true;
	}

	public HttpHelper(HttpURLConnection connection) {
		this.mConnection = connection;
	}

	/**
	 * Perform an HTTP POST request to the URL.
	 * 
	 * @param content
	 *            string containing the content to be posted
	 * @return string containing the response from the server
	 */
	public String post(String content, int connectTimeout, int readTimeout)
			throws IOException {
		this.mConnectionTimeoutMilliseconds = connectTimeout;
		this.mReadTimeoutMilliseconds = readTimeout;
		return post(content);
	}

	/**
	 * Perform an HTTP POST request to the URL.
	 * 
	 * @param content
	 *            string containing the content to be posted
	 * @return string containing the response from the server
	 * @throws IOException 
	 */
	public String post(String content) throws IOException {

		return (postOrPut(content,"POST"));
	}

	/**
	 * Perform an HTTP PUT request to the URL.
	 * 
	 * @param content
	 *            string containing the content to be posted
	 * @return string containing the response from the server
	 * @throws IOException 
	 */
	public String put(String content) throws IOException {

		return (postOrPut(content,"PUT"));
	}
	/**
	 * Perform an HTTP POST OR PUT request to the URL.
	 * 
	 * @param content
	 *            string containing the content to be posted
	 * @return string containing the response from the server
	 * @throws IOException 
	 */
	public String postOrPut(String content, String method) throws IOException {

		if (mConnection == null)
			mConnection = (HttpURLConnection) new URL(mUrl).openConnection();
		prepareConnection(mConnection);
		if (!mConnection.getDoOutput())
			mConnection.setDoOutput(true);
		if (!method.equals(mConnection.getRequestMethod()))
			mConnection.setRequestMethod(method);
		BufferedReader reader = null;
		StringBuffer responseBuffer = new StringBuffer();

		InputStream inStream = null;
		try {
		      //Send request
			DataOutputStream writer = new DataOutputStream (mConnection.getOutputStream ());
			writer.writeBytes (content);
			writer.flush ();
			writer.close ();
			
			if (mConnection.getResponseCode() >= 400) {
				inStream = mConnection.getErrorStream();
			} else {
				inStream = mConnection.getInputStream();
			}
			reader = new BufferedReader(new InputStreamReader(inStream));
			String line = null;
			while ((line = reader.readLine()) != null) {
				responseBuffer.append(line).append('\n');
			}
		} finally {
			if (inStream != null)
				try {inStream.close();} catch (IOException e) {}
			if (reader != null)
				try {reader.close();} catch (IOException e) {}
			mConnection.disconnect();
			mResponseCode = mConnection.getResponseCode();
		}
		return responseBuffer.toString();
	}
	/**
	 * Configures the connection timeout values and headers.
	 * @param sc 
	 */
	protected void prepareConnection(HttpURLConnection connection)
			throws IOException {
		// sun.net.client.defaultReadTimeout=5
		if (mReadTimeoutMilliseconds >= 0)
			connection.setReadTimeout(mReadTimeoutMilliseconds);
		if (mConnectionTimeoutMilliseconds >= 0)
			connection.setConnectTimeout(mConnectionTimeoutMilliseconds);
			
		if (mHeaders != null) {
			for (String key : mHeaders.keySet()) {
				connection.setRequestProperty(key, mHeaders.get(key));
			}
		}
	}
	/**
	 * Sends a get commend to the URL provided in the request string
	 * @param request URL 
	 * @param connectTimeout in milliseconds
	 * @param readTimeout in milliseconds
	 * @return String response from get
	 * @throws IOException
	 */
	public String get(String request, int connectTimeout, int readTimeout)
			 throws IOException{ 
		this.mConnectionTimeoutMilliseconds = connectTimeout;
		this.mReadTimeoutMilliseconds = readTimeout;
		return get(request);
	}
	/**
	 * Sends a get commend to the URL provided in the request string
	 * @param request URL
	 * @return String response from get
	 * @throws IOException
	 */
	public String get(String request) throws IOException {
		mUrl= mUrl+request;
		//System.out.println(mUrl);
		if (mConnection == null) {
			mConnection = (HttpURLConnection) new URL(mUrl).openConnection();
			mConnection.setDoOutput(true);
			mConnection.setRequestMethod("GET");
		}
		
		prepareConnection(mConnection);
		mConnection.getResponseCode();

		BufferedReader reader = null;
		StringBuffer responseBuffer = new StringBuffer();

		try {
			reader = new BufferedReader(new InputStreamReader(
					mConnection.getInputStream()));
			String line = null;
			while ((line = reader.readLine()) != null) {
				responseBuffer.append(line).append('\n');
			}
		} finally {
			if (reader != null)
				reader.close();
			mConnection.disconnect();
			mResponseCode = mConnection.getResponseCode();
		}
		
		return responseBuffer.toString();

	}
	public String get (ArrayList<Parameter>  parameters) throws IOException {
		StringBuilder string = new StringBuilder();
		boolean first = true;
		for (Parameter parameter : parameters) {
			if (first) {
				string.append("?");
				first = false;
			}
			else
				string.append("&");
			string.append(String.format("%s=%s",parameter.getName(),URLEncoder.encode(parameter.getValue())));
		}
		return get(string.toString());
	}
	/**
     * Perform an HTTP GET request against the URL.
     * @return the string response from the server
     */
    public String get() throws IOException {

        if (mConnection == null)
            mConnection = (HttpURLConnection) new URL(mUrl).openConnection();
        
        prepareConnection(mConnection);
        
        mConnection.setDoOutput(false);
        mConnection.setRequestMethod("GET");
        
        BufferedReader reader = null;
        StringBuffer responseBuffer = new StringBuffer();

        try {
            reader = new BufferedReader(new InputStreamReader(mConnection.getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null) {
                responseBuffer.append(line).append('\n');
            }
        }
        finally {
            if (reader != null)
                reader.close();
            mConnection.disconnect();
            mResponseCode = mConnection.getResponseCode();
        }
        
        return responseBuffer.toString();
    }


}
