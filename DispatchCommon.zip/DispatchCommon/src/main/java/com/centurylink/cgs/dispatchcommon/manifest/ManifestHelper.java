package com.centurylink.cgs.dispatchcommon.manifest;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import org.apache.log4j.Logger;




public class ManifestHelper {
	private static final Logger logger = Logger.getLogger(ManifestHelper.class);
	
	private static  String service = null;
	
	public static void setService(String service) {
		ManifestHelper.service = service;
	}
	public static String getService() {
		return service;
	}
	/** Returns the Build-Time entry from the WAR Manifest file.  Before calling this method, the
	 *  application context must be set with setContext()
	 * @return
	 * @throws IOException 
	 * @throws ParseException 
	 */
	public static String getBuildTimestamp() throws IOException, ParseException
	{
		Date date = null;
		
		String buildDate = getAttribute("Build-Time");
		if (buildDate != null && !buildDate.trim().isEmpty()) {
			DateFormat utcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
			utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			SimpleDateFormat newDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");

			/*
			 * There are two different parsing formats because the Maven build could produce
			 * different formats in the build, depending on how it's built.  For the second
			 * format, the timezone is associated with the machine where the build was done,
			 * so it is unknown.
			 */
			try {
				date = utcFormat.parse(buildDate);
				TimeZone tz = TimeZone.getTimeZone("America/Denver");
				newDateFormat.setTimeZone(tz);
				return newDateFormat.format(date) + " MST";
			} catch (ParseException e) {
				DateFormat mtzFormat = new SimpleDateFormat("yyyyMMdd-HHmm"); 
				mtzFormat.setTimeZone(TimeZone.getDefault());
				date = mtzFormat.parse(buildDate);
				return newDateFormat.format(date);
			}

		}
		return null;

	}
	public static String getApplicationVersion() throws IOException  {
		return getAttribute("Application-Version");
	}
	public static String getBuiltBy() throws IOException  {
		return getAttribute("Built-By");
	}
	public static String getBuildJdk() throws IOException  {
		return getAttribute("Build-Jdk");
	}
	private static String getAttribute(String name) throws IOException  {
		String directory = System.getProperty("user.dir");
		logger.debug("Working Directory = " + System.getProperty("user.dir"));
		InputStream manifestStream = null;
		String path = null;
		try {
			// Kubernetes - Spring boot
			manifestStream = ManifestHelper.class.getClassLoader().getResourceAsStream("META-INF/MANIFEST.MF");
			logger.debug("Got manifest from resource stream: " + manifestStream);
		} catch (Exception e) {}
		try {
			// Kubernetes
			path = String.format("%s/webapps/ROOT/META-INF/MANIFEST.MF", directory);
			logger.debug("Looking for file at path " + path);
			manifestStream = new FileInputStream(path);
		} catch (Exception e) {}
		try {
			path = String.format("%s/webapps/%s/META-INF/MANIFEST.MF", directory, service);
			logger.debug("Looking for file at path " + path);
			manifestStream = new FileInputStream(path);
		} catch (Exception e) {}
		try {
			// Cloud Foundry
			path = "META-INF/MANIFEST.MF";
			logger.debug("Looking for file at path " + path);
			manifestStream = new FileInputStream(path);
		} catch (Exception e) {}
		try {
			// FOSS
			path = String.format("%s/Qwest/apps/%s/META-INF/MANIFEST.MF",directory, service);
			logger.debug("Looking for file at path " + path);
			manifestStream = new FileInputStream(path);
		} catch (Exception e) {}
		if (manifestStream == null) { 
			// Local environment running in eclipse
			path = String.format("../%s/target/m2e-wtp/web-resources/META-INF/MANIFEST.MF",service);
			logger.debug("Looking for file at path " + path);
	    	manifestStream = new FileInputStream(path);
		}
		if (manifestStream != null)
		{
			Manifest manifest = new Manifest(manifestStream);
			Attributes attributes = manifest.getMainAttributes();

			manifestStream.close();
			return  attributes.getValue(name);
		}
		return null;
		
	}
}
