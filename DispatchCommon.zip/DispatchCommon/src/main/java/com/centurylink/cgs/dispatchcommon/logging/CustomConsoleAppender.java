package com.centurylink.cgs.dispatchcommon.logging;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.spi.LoggingEvent;

public class CustomConsoleAppender extends ConsoleAppender {


	@Override
	public void close() {
		
	}

	@Override
	public boolean requiresLayout() {
		return false;
	}

	@Override
	public void append(LoggingEvent event) {

		
		boolean logFlag= false;
		String key = null;
		
		
		String SERVICE_NAME = DispatchLogger.getServiceLevelName();
		
		if(DispatchLogger.getLoggingProperty()!=null){
			
			//System.out.println("SERVICE_NAME  "+SERVICE_NAME);
			key = SERVICE_NAME + "_" +event.getLogger().getName();
			key= key.replace('.', '_');
			
			//Logging level set specific to Class level
			
			if(DispatchLogger.getLoggingProperty().get(key.toString())!=null){
				logFlag=true;
			}
			
			//Logging level set specific to Package level
			String packageName = null;
			try {
				
				packageName = Class.forName(event.getLogger().getName()).getPackage().getName();
			} catch (ClassNotFoundException e) {
				
			}
			if(packageName!=null){
				if(!logFlag){
					
					key=SERVICE_NAME + "_" + packageName;
					key=key.replace('.', '_');
					if(DispatchLogger.getLoggingProperty().get(key)!=null){
					
						logFlag=true;
					}
				}
			}
				
			if(!logFlag){
				//Logging level set specific to Service level
				key=SERVICE_NAME + "_ALL";
				if(DispatchLogger.getLoggingProperty().get(key)!=null){
						logFlag=true;
				}
			}
		}
		
		// Specific log level is set and json object is not null
		if(logFlag){
				
				if(event.getLevel().toInt() >= Level.toLevel(DispatchLogger.getLoggingProperty().get(key).toString()).toInt()){
					PatternLayout layout = new PatternLayout();
					String conversionPattern = "[%p] %d %c - %m%n";
					layout.setConversionPattern(conversionPattern);
					super.setLayout(layout);
					super.append(event);
					logFlag=false;
					
				}
		}else{
			String defaultLogLevel=null;
			if(DispatchLogger.getLoggingProperty()!=null)
				defaultLogLevel = DispatchLogger.getLoggingProperty().get("DEFAULT_ALL");
			if(defaultLogLevel==null)
				defaultLogLevel="INFO";
			if(event.getLevel().toInt() >= Level.toLevel(defaultLogLevel).toInt()){
			
				PatternLayout layout = new PatternLayout();
				String conversionPattern = "[%p] %d %c - %m%n";
				layout.setConversionPattern(conversionPattern);
				super.setLayout(layout);
		        super.append(event);
			}
		}
	}
}
