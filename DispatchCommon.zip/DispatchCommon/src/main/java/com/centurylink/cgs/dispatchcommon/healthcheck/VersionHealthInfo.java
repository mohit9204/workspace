package com.centurylink.cgs.dispatchcommon.healthcheck;

import java.util.ArrayList;

import org.apache.commons.dbcp2.BasicDataSource;

import com.centurylink.cgs.dispatchcommon.manifest.ManifestHelper;
import com.centurylink.cgs.dispatchcommon.model.DBConnection;
import com.centurylink.cgs.dispatchcommon.model.ServiceEndpoint;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;
import com.centurylink.cgs.dispatchdatabase.Database;

public class VersionHealthInfo {
	private static final String ENVIRONMENT_KEY = "SPRING_PROFILES_ACTIVE";

	// Populate version info, return true/false based on success
	public static boolean setVersionInfo(VersionHealthResponse response, String serviceName) {
		ManifestHelper.setService(serviceName);
		try {
			response.setBuildJdk(ManifestHelper.getBuildJdk());
			response.setBuildTimeStamp(ManifestHelper.getBuildTimestamp());
			response.setBuiltBy(ManifestHelper.getBuiltBy());
			response.setVersion(ManifestHelper.getApplicationVersion());
			String environment = System.getenv().get(ENVIRONMENT_KEY);
			response.setSpringProfile(environment);

		}
		catch (Exception e) {
			response.setVersionStatus("Version Failure: " + e.getMessage());
			return false;
		}

		response.setVersionStatus("Version Success");
		return true;

	}

	// Populate DB info, return true/false based on success
	public static boolean addDBConnection(VersionHealthResponse response, BasicDataSource dataSource) {

		boolean success = true;
		ArrayList<DBConnection> dbConnections;

		if (response.getDbConnections() == null) {
			dbConnections = new ArrayList<DBConnection>();
		} else {
			dbConnections = response.getDbConnections();
		}

		DBConnection connection = new DBConnection();

		try {
			connection.setDatabaseURL(dataSource.getUrl());
			connection.setDatabaseUser(dataSource.getUsername());

			Database database = new Database(dataSource);
			database.runHealthCheck();
			//If no Exception, then we're good.
			connection.setConnectionStatus("SUCCESS");

		} catch (Exception e) {
			connection.setConnectionStatus("FAILURE: " + e.getMessage());
			success = false;
		}

		dbConnections.add(connection);
		response.setDbConnections(dbConnections);
		return success;
	}
	
	public static boolean addServiceEndpoint(VersionHealthResponse response, String url, String username, String connectionStatus) {
		ArrayList<ServiceEndpoint> endpoints;

		if (response.getEndpoints() == null) {
			endpoints = new ArrayList<ServiceEndpoint>();
		} else {
			endpoints = response.getEndpoints();
		}
		
		ServiceEndpoint endpoint = new ServiceEndpoint();
		
		endpoint.setEndpointURL(url);
		endpoint.setEndpointUser(username);
		endpoint.setConnectionStatus(connectionStatus);
		
		endpoints.add(endpoint);
		response.setEndpoints(endpoints);
		
		return true;
		
	}

}
