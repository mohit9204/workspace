package com.centurylink.cgs.dispatchcommon.logging;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import com.centurylink.cgs.dispatchcommon.exception.DispatchException;

/**
 * This is an abstract class which implements the methods to be used for logging in the Dispatch services.  This class wraps the log4j Logger
 * class to provide standard formatting of log messages.  It also ensures that all errors are logged with the required parameters, including
 * an alarm ID and context information.  This is the parent class for the service-specific logging classes, such as DispatchTaskLogger.
 * 
 * @author wmiddle
 *
 */
public abstract class DispatchLogger {

	private Logger logger;
	private String serviceName;
	
	private static String serviceLevelName;
	private static Map<String,String> loggingProperty;
	
	
	
	public static synchronized String getServiceLevelName() {
		return serviceLevelName;
	}

	public static synchronized void setServiceLevelName(String serviceLevelName) {
		DispatchLogger.serviceLevelName = serviceLevelName;
	}

	public static synchronized Map<String, String> getLoggingProperty() {
		return loggingProperty;
	}

	public static synchronized void setLoggingProperty(Map<String, String> loggingProperty) {
		DispatchLogger.loggingProperty = loggingProperty;
	}

	protected DispatchLogger(Class clazz, String serviceName) {
		this.logger = Logger.getLogger(clazz);
		this.serviceName = serviceName;
	}
	
	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}
	
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public void error(DispatchException exception) {
		logger.error(String.format("[%s] SERVICE_NAME=%s ALARM_ID=%d Message=[%s] Context=[%s]\n%s", serviceName,
														serviceName,
														exception.getAlarmId(),
														exception.getMessage(),
														exception.getContext(),
														stackTraceToString(exception)));
	}
	public void warn(String message) {
		logger.warn(String.format("[%s] %s",serviceName, message));
	}
	public void warn(String message, LogContext context) {
		logger.warn(String.format("[%s] %s %s",serviceName, message, context));
	}
	public void warn(String message, LogContext context, Throwable except) {
		if (except instanceof DispatchException) {
			DispatchException exception = (DispatchException)except;
			logger.warn(String.format("[%s] SERVICE_NAME=%s ALARM_ID=%d Context=[%s]\n%s", serviceName,
					serviceName,
					exception.getAlarmId(),
					exception.getContext(),
					stackTraceToString(exception)));			
		}
		else
			logger.warn(String.format("[%s] %s %s",serviceName, message, context), except);
	}
	public void warn(String message, Throwable except) {
		if (except instanceof DispatchException) {
			DispatchException exception = (DispatchException)except;
			logger.warn(String.format("[%s] SERVICE_NAME=%s ALARM_ID=%d\n%s", serviceName,
					serviceName,
					exception.getAlarmId(),
					stackTraceToString(exception)));			
		}
		else
			logger.warn(String.format("[%s] %s",serviceName, message), except);
	}
	
	public void warn(LogContext context) {
		logger.warn(String.format("[%s] %s",serviceName, context));
	}
	public void info(String message) {
		logger.info(String.format("[%s] %s",serviceName, message));
	}
	public void info(String message, LogContext context) {
		logger.info(String.format("[%s] %s %s",serviceName, message, context));
	}
	public void info(LogContext context) {
		logger.info(String.format("[%s] %s",serviceName, context));
	}
	public void debug(String message) {
		logger.debug(String.format("[%s] %s",serviceName, message));
	}
	public void debug(String message, LogContext context) {
		logger.debug(String.format("[%s] %s %s",serviceName, message, context));
	}
	public void debug(LogContext context) {
		logger.debug(String.format("[%s] %s",serviceName, context));
	}
	public void trace(String message) {
		logger.trace(String.format("[%s] %s",serviceName, message));
	}
	public void trace(String message, LogContext context) {
		logger.trace(String.format("[%s] %s %s",serviceName, message, context));
	}
	public void trace(LogContext context) {
		logger.trace(String.format("[%s] %s",serviceName, context));
	}
	private static String stackTraceToString(Throwable e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}

}
