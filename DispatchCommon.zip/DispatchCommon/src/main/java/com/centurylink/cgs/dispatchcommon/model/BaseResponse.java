package com.centurylink.cgs.dispatchcommon.model;

import javax.xml.bind.annotation.XmlType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Basic information returned for every request when there is a successful connection to the VehicleLocation service")
@XmlType
public class BaseResponse {
	private String message;
	private responseStatusValues responseStatus;
	private int reasonCode;
	@XmlType
	public enum responseStatusValues{Success, Failure, Informational, Warning};
	
	@ApiModelProperty(value="Description of the reason code.", dataType="string", required=true)
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@ApiModelProperty(value="Category assigned to the reason code.", dataType="string", required=true, notes="Enum values: Success, Failure, Informational, Warn")
	public responseStatusValues getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(responseStatusValues responseStatus) {
		this.responseStatus = responseStatus;
	}
	
	@ApiModelProperty(value="Numerical code assigned for possible expected results", dataType="int", required=true, notes="Includes codes for success, application errors, and no data returned scenarios." )
	public int getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(int reasonCode) {
		this.reasonCode = reasonCode;
	}
	
}
