package com.centurylink.cgs.dispatchcommon.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;

/**
 * This is a class which will be the parent of the service-specific exception class in each service in the Dispatch domain.  
 * This class will ensure that the each exception is defined with a message, alarm ID, a LogContext object, 
 * and an optional inner exception.  The constructors of this exception class will enforce this requirement.  
 * This exception class will also be used for any exceptions created within the common code.
 * @author wmiddle
 *
 */
public class DispatchException extends Exception {
	private static final long serialVersionUID = 1L;
	private int alarmId;
	private LogContext context;
		

	public DispatchException(String message, int alarmId, LogContext context) {
		super(message);
		this.alarmId = alarmId;
		setContext(context);
	}

	public DispatchException(String message, Throwable cause, int alarmId, LogContext context) {
		super(message, cause);
		this.alarmId = alarmId;
		setContext(context);
	}

	public int getAlarmId() {
		return alarmId;
	}

	public void setAlarmId(int alarmId) {
		this.alarmId = alarmId;
	}

	public LogContext getContext() {
		return context;
	}

	public void setContext(LogContext context) {
		this.context = context;
	}

	public String getStackTraceString() {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		this.printStackTrace(pw);
		return sw.toString();
	}
}
