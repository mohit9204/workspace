package com.centurylink.cgs.dispatchcommon.reference;

import java.util.ArrayList;
import java.util.HashMap;

import javax.sql.DataSource;

import com.centurylink.cgs.dispatchdatabase.DataRow;
import com.centurylink.cgs.dispatchdatabase.DataTable;
import com.centurylink.cgs.dispatchdatabase.Database;
import com.centurylink.cgs.dispatchdatabase.Parameter;

public class DispatchReference {
	
	public static final String REFERENCE_QUERY = "REFERENCE_QUERY";
	public static final String KEY_COLUMN = "REF_KEY";
	public static final String VALUE_COLUMN = "REF_VALUE";
	
	private static HashMap<String, HashMap<String, String>> referenceTables = new HashMap<String, HashMap<String,String>>();
	private static Object tableMutex = new Object();
	
	public String get(DataSource dataSource, String tableName, String key) throws Exception {
		HashMap<String, String> table = null;
		synchronized (tableMutex) {
			table = referenceTables.get(tableName);
			if (table == null) {
				table = loadTable(dataSource, tableName);
				referenceTables.put(tableName, table);
			}
		}
		return table.get(key);
	}
	public HashMap<String, String> getReferenceMap(DataSource dataSource, String tableName) throws Exception {
		HashMap<String, String> table = null;
		synchronized (tableMutex) {
			table = referenceTables.get(tableName);
			if (table == null) {
				table = loadTable(dataSource, tableName);
				referenceTables.put(tableName, table);
			}
		}
		return table;
	}

	private HashMap<String, String> loadTable(DataSource dataSource, String tableName) throws Exception {
		HashMap<String, String> table = new HashMap<String, String>();
		Database database = new Database("DispatchReferenceDatabaseConfiguration.xml",dataSource);
		ArrayList<Parameter> parameters = new ArrayList<Parameter>();
		parameters.add(new Parameter().setValue(tableName));
		DataTable dataTable = database.runQuery(REFERENCE_QUERY, parameters);
		for (DataRow row : dataTable.getRows()) {
			table.put(row.getString(KEY_COLUMN), row.getString(VALUE_COLUMN));
		}
		return table;
	}
	public void refreshTable(String tableName) {
		synchronized (tableMutex) {
			if (referenceTables.containsKey(tableName))
				referenceTables.remove(tableName);
		}
	}
}
