package com.centurylink.cgs.dispatchcommon.strings;

public class FormattedString {
	/**
	 * Returns the string value truncated to the length specified.
	 * @param pString
	 * @param pLength
	 * @return
	 */
	public static String truncate(String pString, int pLength) {
		if (pString != null && pString.length() > pLength)
			return pString.substring(0, pLength);
		else
			return pString;
	}
}
