package com.centurylink.cgs.dispatchcommon.performance;

import java.util.ArrayList;
import java.util.HashMap;

import javax.sql.DataSource;

import com.centurylink.cgs.dispatchcommon.datetime.Stopwatch;
import com.centurylink.cgs.dispatchcommon.exception.DispatchException;
import com.centurylink.cgs.dispatchcommon.logging.DispatchCommonLogger;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchdatabase.DataRow;
import com.centurylink.cgs.dispatchdatabase.DataTable;
import com.centurylink.cgs.dispatchdatabase.Database;
import com.centurylink.cgs.dispatchdatabase.Parameter;

public class PerformanceLog {
	private static DispatchCommonLogger LOG = DispatchCommonLogger.getLogger(PerformanceLog.class);
	private static boolean loggingEnabled = true;
	private String serviceName = null;
	private String performanceIndicator = null;
	private String trackingId;
	private long durationMilliseconds;
	private Stopwatch stopWatch = new Stopwatch();
	private static Database database = null;
	private DataSource dataSource = null;
	private static HashMap<String, Integer> performanceIndicatorMap = null;
	private static Object mapMutex = new Object();
	
	
	public PerformanceLog(String serviceName, DataSource dataSource) throws Exception {
		this.serviceName = serviceName;
		this.dataSource = dataSource;
	}
	public void start(String performanceIndicator, String trackingId) throws Exception {
		this.performanceIndicator = performanceIndicator;
		this.trackingId = trackingId;
		stopWatch.start();
	}
	public void stop() throws Exception {
		stopWatch.stop();
		durationMilliseconds = stopWatch.getElapsedMilliseconds();
		if (loggingEnabled)
			writeToDatabase();
	}
	private void writeToDatabase() throws Exception {
		synchronized (mapMutex) {
			if (performanceIndicatorMap == null) {
				database = new Database("PerformanceLogDatabaseConfiguration.xml", dataSource);
				performanceIndicatorMap = getPerformanceIndicatorMap();
			}
		}
		
		if (performanceIndicatorMap.get(serviceName+performanceIndicator) == null) {
			throw new Exception(String.format("No record in PERFORMANCE_IND_REF for Service %s and Indicator %s", serviceName, performanceIndicator));
		}
		ArrayList<Parameter> parameters = new ArrayList<Parameter>();

		try {
				parameters.add(new Parameter().setValue(trackingId));
				parameters.add(new Parameter().setValue(performanceIndicatorMap.get(serviceName+performanceIndicator)));
				parameters.add(new Parameter().setValue(durationMilliseconds));
				database.runNonQuery("INSERT_PERFORMANCE_LOG", parameters);
				LOG.info(new LogContext().add("serviceName",serviceName).add("performanceIndicator",performanceIndicator).add("durationMilliseconds",durationMilliseconds));
		} catch (Exception e) {
			LogContext context = new LogContext().add("serviceName",serviceName).add("trackingId",trackingId);
			LOG.error(new DispatchException(e.getMessage(),e, 9999, context));
		}
	}
	private HashMap<String, Integer> getPerformanceIndicatorMap() throws Exception {
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		DataTable table =database.runQuery("GET_PERFORMANCE_IND_VALUES");
		for (DataRow row : table.getRows()) {
			map.put(row.getString("SERVICE_NM_VAL")+row.getString("PERFORMANCE_IND_VAL"), Integer.parseInt(row.getString("PERFORMANCE_IND_ID")));
		}
		return map;
	}
	public static boolean isLoggingEnabled() {
		return loggingEnabled;
	}
	public static void setLoggingEnabled(boolean loggingEnabled) {
		PerformanceLog.loggingEnabled = loggingEnabled;
	}
	public String getTrackingId() {
		return trackingId;
	}
	public void setTrackingId(String trackingId) {
		this.trackingId = trackingId;
	}
	public long getDurationMilliseconds() {
		return durationMilliseconds;
	}
	public void setDurationMilliseconds(long durationMilliseconds) {
		this.durationMilliseconds = durationMilliseconds;
	}
	

}
