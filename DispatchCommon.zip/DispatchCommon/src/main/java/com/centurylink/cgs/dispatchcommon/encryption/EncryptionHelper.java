package com.centurylink.cgs.dispatchcommon.encryption;

import com.ctl.esec.crypto.BasicEncryptor;
import com.ctl.esec.crypto.*;

public class EncryptionHelper {
	
	private final static String ENVIRONMENT_KEY = "SPRING_PROFILES_ACTIVE";  

	public static String encrypt(String value) {
		return encrypt(value, getKey());
	}
	public static String encrypt(String value, String key) {

		try {
			BasicEncryptor encryptor = new BasicEncryptor("AES/CBC/PKCS5Padding");
			CipherText cTxt = encryptor.encrypt(value.toCharArray(), key.toCharArray(), key.length() * 8);

			return cTxt.toEncodedString();

		} catch (Exception ex) {
			System.out.println("Caught exception, message: " + ex.getMessage());
		}
		return null;

	}

	public static String decrypt(String value) {
		return decrypt(value, getKey());
	}
	public static String decrypt(String value, String key) {
		try {
			CipherText cTxt = new CipherText(value);

			BasicEncryptor decryptor = new BasicEncryptor(cTxt);
			return decryptor.decrypt(cTxt, key.toCharArray(), key.length() * 8);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	private static String getKey() {
		String key = System.getenv().get(ENVIRONMENT_KEY);
		if (key == null) 
			key = "";
		else
			key = key.toUpperCase();
		for (int i = 0; i < key.length()%16; ++i) {
			key = "X"+key;
		}
		return key;
	}	

}
