package com.centurylink.cgs.dispatchcommon.logging;

import java.util.ArrayList;
/**
 * This class provides a list of name/value pairs which will provide additional context messages for DispatchExceptions 
 * and log messages.  Methods are provided to add or insert new name/value pairs as well as a toString method to produce 
 * a formatted string for the log.  
 * 
 */
public class LogContext {
	
	/**
	 * These are the names of values which will be commonly used in the log context.  Use of the values in naming
	 * context values will ensure consistent naming across all dispatch services to help facilitate filtering in SPLUNK.
	 */
	public static final String EXCHANGE_ID = "EXCHANGE_ID";
	public static final String DISPATCH_CORRELATION_ID = "DISPATCH_CORRELATION_ID"; 
	
	private ArrayList<NameValue> nameValues = new ArrayList<NameValue>();
	private String message = "";

	public ArrayList<String> getValues() {
		ArrayList<String> array = new ArrayList<String>();
		for(NameValue nv : nameValues) {
			if (nv.getValue() != null && nv.getValue() instanceof LogContext)
				continue; // Prevent recursive loop
			array.add(String.format("%s=%s", nv.getName(), nv.getValue() == null ? "" : nv.getValue().toString()));
		}
		return array;
	}
	public ArrayList<NameValue> getNameValues() {
		return nameValues;
	}
	public LogContext() {
	}
	/**
	 * Adds the name value pair to the end of the list of values
	 * @param name
	 * @param value
	 * @return
	 */
	public LogContext add(String name, Object value) {
		return add(name, value, false);
	}
	/**
	 * Adds the name value pair to the end of the list of values
	 * @param name
	 * @param value
	 * @param allowDuplicates
	 * @return
	 */
	public LogContext add(String name, Object value, boolean allowDuplicates) {
		if (!contains(name) || allowDuplicates)
			nameValues.add(new NameValue(name, value));
		return this;
	}

	/**
	 * Inserts the name value pair to the beginning of the list of values
	 * @param name
	 * @param value
	 * @return
	 */
	public LogContext insert(String name, Object value) {
		return insert(name, value, false);
	}
	/**
	 * Inserts the name value pair to the beginning of the list of values
	 * @param name
	 * @param value
	 * @param allowDuplicates
	 * @return
	 */
	public LogContext insert(String name, Object value, boolean allowDuplicates) {
		if (!contains(name) || allowDuplicates)
			nameValues.add(0,new NameValue(name, value));
		return this;
	}
	/**
	 * Replaces the name value pair with the new value.  Adds it if it doesn't exist
	 * @param name
	 * @param value
	 * @return
	 */
	public LogContext replace(String name, Object value) {
		for (NameValue nv : nameValues) {
			if (name != null && name.equalsIgnoreCase(nv.getName())) {
				nv.setValue(value);
				return this;
			}
		}
		nameValues.add(new NameValue(name, value));
		return this;
	}
	/**
	 * Adds all name value pairs from the context parameter to the end of the list of values
	 * If there are duplicates of the same name, the new value will not be added
	 * @param context
	 * @param allowDuplicates
	 * @return
	 */
	public LogContext add(LogContext context, boolean allowDuplicates) {
		for(NameValue nv : context.getNameValues()) {
			if (!contains(nv.getName()) || allowDuplicates)
				this.nameValues.add(nv);
		}
		return this;
	}
	/**
	 * Adds all name value pairs from the context parameter to the end of the list of values
	 * If there are duplicates of the same name, the new value will not be added
	 * @param context
	 * @return
	 */
	public LogContext add(LogContext context) {
		return add(context, false);
	}
	
	/**
	 * Inserts all name value pairs from the context parameter to the beginning of the list of values
	 * If there are duplicates of the same name, only the inserted value will be retained
	 * @param context
	 * @param allowDuplicates
	 * @return
	 */
	public LogContext insert(LogContext context, boolean allowDuplicates) {
		ArrayList<NameValue> oldValues = this.nameValues;
		this.nameValues = context.getNameValues();
		for(NameValue nv : oldValues) {
			if (!contains(nv.getName()) || allowDuplicates)
				this.nameValues.add(nv);
		}
		return this;
	}
	/**
	 * Inserts all name value pairs from the context parameter to the beginning of the list of values
	 * If there are duplicates of the same name, only the inserted value will be retained
	 * @param context
	 * @return
	 */
	public LogContext insert(LogContext context) {
		return insert(context, false);
	}
	public LogContext setMessage(String message) {
		this.message = message;
		return this;
	}
	public LogContext appendMessage(String message) {
		if (this.message == null || this.message.trim().length() == 0)
			this.message = message;
		else {
			if (this.message.trim().endsWith(".")) 
				this.message = this.message.trim()+" "+message;
			else
				this.message = this.message.trim()+". "+message;
		}
		return this;
	}
	public String getValue(String name) {
		for (NameValue nv : nameValues) {
			if (name != null && name.equalsIgnoreCase(nv.getName()))
				return nv.getValue() == null ? null : nv.getValue().toString();
		}
		return null;
	}
	public boolean contains(String name) {
		for (NameValue nv : nameValues) {
			if (name != null && name.equalsIgnoreCase(nv.getName()))
				return true;
		}
		return false;
	}
	@Override
	public String toString() {
		StringBuilder string = new StringBuilder();
		if (message != null && message.trim().length() > 0) {
			if (this.getValues().size() > 0)
				string.append(message+": ");
			else
				string.append(message);
		}
		boolean first = true;
		for (String value : this.getValues()) {
			if (first) {
				
				string.append(value);
				first = false;
			}
			else
				string.append(String.format(", %s",value));
		}

		return string.toString();
	}

}
