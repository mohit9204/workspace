package com.centurylink.cgs.dispatchcommon.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Information on a Service Endpoint")
public class ServiceEndpoint {
	private String endpointURL;
	private String endpointUser;
	private String connectionStatus = "NOT CHECKED";
	
	@ApiModelProperty(value="Endpoint URL", dataType="string")
	public String getEndpointURL() {
		return endpointURL;
	}
	public void setEndpointURL(String endpointURL) {
		this.endpointURL = endpointURL;
	}
	
	@ApiModelProperty(value="Endpoint user - if using authentication", dataType="string")
	public String getEndpointUser() {
		return endpointUser;
	}
	public void setEndpointUser(String endpointUser) {
		this.endpointUser = endpointUser;
	}
	
	@ApiModelProperty(value="Connection Status - can connect?", dataType="string")
	public String getConnectionStatus() {
		return connectionStatus;
	}
	public void setConnectionStatus(String connectionStatus) {
		this.connectionStatus = connectionStatus;
	}
	


	
	

}
