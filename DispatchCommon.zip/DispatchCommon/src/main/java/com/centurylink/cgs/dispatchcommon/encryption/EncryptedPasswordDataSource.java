package com.centurylink.cgs.dispatchcommon.encryption;

import org.apache.commons.dbcp2.BasicDataSource;

public class EncryptedPasswordDataSource extends BasicDataSource {
	private String encryptedPassword;

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
		super.setPassword(EncryptionHelper.decrypt(encryptedPassword));
	}
}
