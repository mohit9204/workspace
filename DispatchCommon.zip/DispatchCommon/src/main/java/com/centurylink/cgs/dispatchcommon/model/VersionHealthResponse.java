package com.centurylink.cgs.dispatchcommon.model;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(description="Dispatch Status returned for a request for version")
@XmlRootElement
public class VersionHealthResponse {

	private BaseResponse baseResponse;
	private String version;
	private String buildTimeStamp;
	private String builtBy;
	private String buildJdk;
	private String springProfile;
	private String versionStatus;
	private ArrayList<DBConnection> dbConnections;
	private ArrayList<ServiceEndpoint> endpoints;
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	public String toString() {
		return this.toJSONString();
	}
	
	public String toJSONString() {
		try {
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		} catch (JsonProcessingException jpe) {
			return jpe.getMessage();
		}
	}

	@ApiModelProperty("BaseResponse indicating success/failure")
	public BaseResponse getBaseResponse() {
		return baseResponse;
	}
	public void setBaseResponse(BaseResponse baseResponse) {
		this.baseResponse = baseResponse;
	}
	

	@ApiModelProperty(value="Build Version Number", dataType="string")
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	@ApiModelProperty(value="Build Timestamp", dataType="string")
	public String getBuildTimeStamp() {
		return buildTimeStamp;
	}

	public void setBuildTimeStamp(String buildTimeStamp) {
		this.buildTimeStamp = buildTimeStamp;
	}
	@ApiModelProperty(value="Built By", dataType="string")
	public String getBuiltBy() {
		return builtBy;
	}

	public void setBuiltBy(String builtBy) {
		this.builtBy = builtBy;
	}
	@ApiModelProperty(value="Build JDK Version", dataType="string")
	public String getBuildJdk() {
		return buildJdk;
	}

	public void setBuildJdk(String buildJdk) {
		this.buildJdk = buildJdk;
	}
	
	@ApiModelProperty(value="SPRING_PROFILES_ACTIVE", dataType="string")
	public String getSpringProfile() {
		return springProfile;
	}

	public void setSpringProfile(String springProfile) {
		this.springProfile = springProfile;
	}

	@ApiModelProperty(value="List of DB connections and their status", dataType="string")
	public ArrayList<DBConnection> getDbConnections() {
		return dbConnections;
	}

	public void setDbConnections(ArrayList<DBConnection> dbConnections) {
		this.dbConnections = dbConnections;
	}

	@ApiModelProperty(value="List of Service Endpoints and their status", dataType="string")
	public ArrayList<ServiceEndpoint> getEndpoints() {
		return endpoints;
	}

	public void setEndpoints(ArrayList<ServiceEndpoint> endpoints) {
		this.endpoints = endpoints;
	}

	@ApiModelProperty(value="Success or failure of testing version", dataType="string")
	public String getVersionStatus() {
		return versionStatus;
	}

	public void setVersionStatus(String versionStatus) {
		this.versionStatus = versionStatus;
	}
	
}
