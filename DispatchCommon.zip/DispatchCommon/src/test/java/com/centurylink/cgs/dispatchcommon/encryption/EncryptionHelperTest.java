package com.centurylink.cgs.dispatchcommon.encryption;

import org.junit.Test;

import junit.framework.Assert;

public class EncryptionHelperTest {
	private String key = "FIFOLIFOFILOLILO";
	// <property name="defaultAssignmentStrategy" value="FIFOLIFOFILOMOFO" />
	public EncryptionHelperTest() {

	}
	@Test
	public void testEncrypt() {
		String key = "XXXXXXXXXXXXDEV1";
		String value = "R2tiday9";
		String encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted,key));
		value = "dgw";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "jobs";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "Pathway2Q16";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "CSEv2&U5zjs";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "gis";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		
		key = "XXXXXXXXXXXTEST1";
		value = "R2tiday9";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "e2edgw14";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "dgwjobs2016";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "Pathway2Q16";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "CSVr7&(PAr*";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "CSEv2&U5zjs";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "gis";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		
		key = "XXXXXXXXXXXXPROD";
		value = "XR52yyKw";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "Gisp#123";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));

	}
	@Test
	public void testDecrypt() {
		System.out.println(EncryptionHelper.decrypt("rO0ABXNyAB5jb20uY3RsLmVzZWMuY3J5cHRvLkNpcGhlclRleHQAAAAAATH0VwIACUkAB2tleXNpemVMAAxhbGdfcHJvdmlkZXJ0ABJMamF2YS9sYW5nL1N0cmluZztMAAVjX2FsZ3EAfgABWwANZW5jcnlwdGVkVGV4dHQAAltCWwAUaW5pdGlhbGl6YXRpb25WZWN0b3JxAH4AAkwAB2tleW5hbWVxAH4AAUwABm1kX2FsZ3EAfgABWwAUbWVzc2FnZUludGVncml0eUNvZGVxAH4AAlsABW5vbmNlcQB+AAJ4cAAAABB0AAZTdW5KQ0V0ABRBRVMvQ0JDL1BLQ1M1UGFkZGluZ3VyAAJbQqzzF/gGCFTgAgAAeHAAAAAQRpVML8aWoP/B1kkhA8ovGnVxAH4ABgAAABCLltQslYxaAvtIe5bBwG+tcHQABVNIQS0xdXEAfgAGAAAAFAMZp6xCJgvC9qJNgyAlm7RgFvVVdXEAfgAGAAAAEMlS1clNsHiXiM+5tAgCJgI=","XXXXXXXXXXXXDEV1"));
		System.out.println(EncryptionHelper.decrypt("rO0ABXNyAB5jb20uY3RsLmVzZWMuY3J5cHRvLkNpcGhlclRleHQAAAAAATH0VwIACUkAB2tleXNpemVMAAxhbGdfcHJvdmlkZXJ0ABJMamF2YS9sYW5nL1N0cmluZztMAAVjX2FsZ3EAfgABWwANZW5jcnlwdGVkVGV4dHQAAltCWwAUaW5pdGlhbGl6YXRpb25WZWN0b3JxAH4AAkwAB2tleW5hbWVxAH4AAUwABm1kX2FsZ3EAfgABWwAUbWVzc2FnZUludGVncml0eUNvZGVxAH4AAlsABW5vbmNlcQB+AAJ4cAAAABB0AAZTdW5KQ0V0ABRBRVMvQ0JDL1BLQ1M1UGFkZGluZ3VyAAJbQqzzF/gGCFTgAgAAeHAAAAAQqzxRnHoU7VDxoDf6nskpCXVxAH4ABgAAABBVJH4naqSMPHRqpX/hxPSXcHQABVNIQS0xdXEAfgAGAAAAFMiLvjoUwJjPMgME8xUsZXIGk4dZdXEAfgAGAAAAEFU9aclFCMraqaZ85oXhCR8=","XXXXXXXXXXXXDEV1"));
		System.out.println(EncryptionHelper.decrypt("rO0ABXNyAB5jb20uY3RsLmVzZWMuY3J5cHRvLkNpcGhlclRleHQAAAAAATH0VwIACUkAB2tleXNpemVMAAxhbGdfcHJvdmlkZXJ0ABJMamF2YS9sYW5nL1N0cmluZztMAAVjX2FsZ3EAfgABWwANZW5jcnlwdGVkVGV4dHQAAltCWwAUaW5pdGlhbGl6YXRpb25WZWN0b3JxAH4AAkwAB2tleW5hbWVxAH4AAUwABm1kX2FsZ3EAfgABWwAUbWVzc2FnZUludGVncml0eUNvZGVxAH4AAlsABW5vbmNlcQB+AAJ4cAAAABB0AAZTdW5KQ0V0ABRBRVMvQ0JDL1BLQ1M1UGFkZGluZ3VyAAJbQqzzF/gGCFTgAgAAeHAAAAAQrHU695AdpDe6qCi7F+t6CHVxAH4ABgAAABBFLVwkdOo81YUIDfnESz/McHQABVNIQS0xdXEAfgAGAAAAFHojyB+mD9EZKeELh/ELeZa+pikJdXEAfgAGAAAAEOe80FLLsEiQudv9TQmsYmc=","XXXXXXXXXXXTEST1"));
	}

}
