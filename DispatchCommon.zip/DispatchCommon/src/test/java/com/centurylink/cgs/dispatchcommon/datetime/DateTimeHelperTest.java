package com.centurylink.cgs.dispatchcommon.datetime;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.TimeZone;

import org.junit.Test;

public class DateTimeHelperTest {
	
	@Test
	public void testConvertToDatabaseTime() throws ParseException {
		
		System.out.println(DateTimeHelper.convertToDatabaseTime(new Timestamp(new Date().getTime())));
		
	}
	@Test
	public void testConvertToTimeZone() throws ParseException {
		Date date = new Date();
		System.out.println("utcDate: "+date);
		Date utcDate = DateTimeHelper.convertToLocalTime(new Timestamp(date.getTime()));
		System.out.println("localDate: "+utcDate);

	}

}
