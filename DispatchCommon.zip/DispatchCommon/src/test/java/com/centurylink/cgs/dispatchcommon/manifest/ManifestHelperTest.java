package com.centurylink.cgs.dispatchcommon.manifest;

import java.io.IOException;
import java.text.ParseException;

import org.junit.Test;

import junit.framework.Assert;

public class ManifestHelperTest {

	public ManifestHelperTest() {
		ManifestHelper.setService("DispatchTask");
	}
/*
Manifest-Version: 1.0
Build-Time: 2016-06-08T16:36:09Z
Build-Jdk: 1.7.0_79
Built-By: wmiddle
Created-By: Maven Integration for Eclipse
Application-Version: 1.0.1
 */
	@Test
	public void testGetBuildTimestamp() throws IOException, ParseException {
		String timeStamp = ManifestHelper.getBuildTimestamp();
		System.out.println("Build-Time: "+timeStamp);
		Assert.assertTrue(true);
	}
	@Test
	public void testGetBuildJdk() throws IOException, ParseException {
		String timeStamp = ManifestHelper.getBuildJdk();
		System.out.println("Build-Jdk: "+timeStamp);
		Assert.assertTrue(true);
	}
	@Test
	public void testGetApplicationVersion() throws IOException, ParseException {
		String timeStamp = ManifestHelper.getApplicationVersion();
		System.out.println("Application-Version: "+timeStamp);
		Assert.assertTrue(true);
	}
	@Test
	public void testGetBuiltBy() throws IOException, ParseException {
		String timeStamp = ManifestHelper.getBuiltBy();
		System.out.println("Built-By: "+timeStamp);
		Assert.assertTrue(true);
	}
}
