package com.centurylink.cgs.dispatchcommon.encryption;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.junit.Test;

import junit.framework.Assert;

public class EncryptionDispatchTask {
	// <property name="defaultAssignmentStrategy" value="FIFOLIFOFILOMOFO" />
	public EncryptionDispatchTask() {

	}
	@Test
	public void testEncrypt() {
		LogManager.getRootLogger().setLevel(Level.FATAL);
		
		TreeMap<String,TreeMap<String,String>> passwords = new TreeMap<String,TreeMap<String,String>>();
		
		
		/*
		 * ORDER:  SP, DGW, JOBS, Duration, Click, ESRI
		 */
		
		// Dev 1
		
		TreeMap<String,String> userPass = new TreeMap<String,String>();
		userPass.put("CGS_DISPATCH_SERVICES", "R2tiday9");
		//userPass.put("DGW", "dgw");
		userPass.put("JOBS", "jobs");
		userPass.put("dgwapp", "Pathway3Q16");
		userPass.put("cntrylnk.int", "CSEv2&U5zjs");
		userPass.put("gis", "gis");
		passwords.put("DEV1", userPass);
		
		// Dev2
		userPass = new TreeMap<String,String>();
		userPass.put("CGS_DISPATCH_SERVICES", "R2tiday9");
		//userPass.put("DGW", "dgw");
		userPass.put("JOBS", "jobs");
		userPass.put("dgwapp", "Pathway3Q16");
		userPass.put("cntrylnk.int", "CSEv2&U5zjs");
		userPass.put("gis", "gis");
		passwords.put("DEV2", userPass);
		
		// Test1
		userPass = new TreeMap<String,String>();
		userPass.put("CGS_DISPATCH_SERVICES", "R2tiday9");
		//userPass.put("DGW", "e2edgw14");
		userPass.put("JOBS", "dgwjobs2016");
		userPass.put("dgwapp", "Pathway3Q16");
		userPass.put("cntrylnk_sb1.int", "CSVr7&(PAr*");
		userPass.put("gis", "gis");
		passwords.put("TEST1", userPass);
		
		// Test 2
		userPass = new TreeMap<String,String>();
		userPass.put("CGS_DISPATCH_SERVICES", "R2tiday9");
		//userPass.put("DGW", "e2edgw14");
		userPass.put("JOBS", "dgwjobs2016");
		userPass.put("dgwapp", "Pathway3Q16");
		userPass.put("cntrylnk_sb2.int", "CSQo4)3JBC2");
		userPass.put("gis", "gis");
		passwords.put("TEST2", userPass);
		
		// Prod
		userPass = new TreeMap<String,String>();
		userPass.put("CGS_DISPATCH_SERVICES", "XR52yyKw");
		//userPass.put("DGW", "dgw01p2015");
		userPass.put("JOBS", "dgwjobs2016");
		userPass.put("dgwapp", "Pathway3Q16");
		userPass.put("cntrylnk.int", "CSYb4$D9lTu");
		userPass.put("gis", "Gisp#123");
		passwords.put("PROD", userPass);
		
		for (String s : passwords.keySet()) {
			String key = padLeft(s,16,'X');
			System.out.println(String.format("\n\nEnvironment: %s  KEY: %s", s, key));
			System.out.println("----------------------------------------");
			TreeMap<String,String> passSet = passwords.get(s);
			for (String user : passSet.keySet()) {
				String password = passSet.get(user);
				String encrypted = EncryptionHelper.encrypt(password, key);
				System.out.println("****** " + String.format("Encrypted value for %20s : \n\t%s", user, encrypted));
				String decrypted = EncryptionHelper.decrypt(encrypted, key);
				System.out.println("Decrypted: " + decrypted);
				assertEquals(password,decrypted);
			}
		}
		
/*		String key = "XXXXXXXXXXXXDEV1";
		String value = "R2tiday9";
		String encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted,key));
		value = "dgw";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "jobs";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "Pathway3Q16";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "CSEv2&U5zjs";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "gis";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		
		key = "XXXXXXXXXXXTEST1";
		value = "R2tiday9";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "e2edgw14";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "dgwjobs2016";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "Pathway3Q16";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "CSVr7&(PAr*";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "CSEv2&U5zjs";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "gis";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		
		key = "XXXXXXXXXXXXPROD";
		value = "XR52yyKw";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "Gisp#123";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
		value = "Pathway3Q16";
		encrypted = EncryptionHelper.encrypt(value, key);
		System.out.println("****** " + String.format("Encrypted value for %16s using key %18s = %s", value, key, encrypted));
		Assert.assertEquals("Decryption result", value, EncryptionHelper.decrypt(encrypted, key));
*/
	}
	@Test
	public void testDecrypt() {
		System.out.println(EncryptionHelper.decrypt("rO0ABXNyAB5jb20uY3RsLmVzZWMuY3J5cHRvLkNpcGhlclRleHQAAAAAATH0VwIACUkAB2tleXNpemVMAAxhbGdfcHJvdmlkZXJ0ABJMamF2YS9sYW5nL1N0cmluZztMAAVjX2FsZ3EAfgABWwANZW5jcnlwdGVkVGV4dHQAAltCWwAUaW5pdGlhbGl6YXRpb25WZWN0b3JxAH4AAkwAB2tleW5hbWVxAH4AAUwABm1kX2FsZ3EAfgABWwAUbWVzc2FnZUludGVncml0eUNvZGVxAH4AAlsABW5vbmNlcQB+AAJ4cAAAABB0AAZTdW5KQ0V0ABRBRVMvQ0JDL1BLQ1M1UGFkZGluZ3VyAAJbQqzzF/gGCFTgAgAAeHAAAAAQ6pWdnLSwZLO8xLWWoTzA2HVxAH4ABgAAABAZmUcP+G/O/CoH/JQ4RlcdcHQABVNIQS0xdXEAfgAGAAAAFFOYNwRI0aCziGIWV+dT7s0aMPDYdXEAfgAGAAAAECC0VmtKgvoKC7YyqNf9z8s=","XXXXXXXXXXXTEST1"));
		//System.out.println(EncryptionHelper.decrypt("rO0ABXNyAB5jb20uY3RsLmVzZWMuY3J5cHRvLkNpcGhlclRleHQAAAAAATH0VwIACUkAB2tleXNpemVMAAxhbGdfcHJvdmlkZXJ0ABJMamF2YS9sYW5nL1N0cmluZztMAAVjX2FsZ3EAfgABWwANZW5jcnlwdGVkVGV4dHQAAltCWwAUaW5pdGlhbGl6YXRpb25WZWN0b3JxAH4AAkwAB2tleW5hbWVxAH4AAUwABm1kX2FsZ3EAfgABWwAUbWVzc2FnZUludGVncml0eUNvZGVxAH4AAlsABW5vbmNlcQB+AAJ4cAAAABB0AAZTdW5KQ0V0ABRBRVMvQ0JDL1BLQ1M1UGFkZGluZ3VyAAJbQqzzF/gGCFTgAgAAeHAAAAAQqzxRnHoU7VDxoDf6nskpCXVxAH4ABgAAABBVJH4naqSMPHRqpX/hxPSXcHQABVNIQS0xdXEAfgAGAAAAFMiLvjoUwJjPMgME8xUsZXIGk4dZdXEAfgAGAAAAEFU9aclFCMraqaZ85oXhCR8=","XXXXXXXXXXXXDEV1"));
		//System.out.println(EncryptionHelper.decrypt("rO0ABXNyAB5jb20uY3RsLmVzZWMuY3J5cHRvLkNpcGhlclRleHQAAAAAATH0VwIACUkAB2tleXNpemVMAAxhbGdfcHJvdmlkZXJ0ABJMamF2YS9sYW5nL1N0cmluZztMAAVjX2FsZ3EAfgABWwANZW5jcnlwdGVkVGV4dHQAAltCWwAUaW5pdGlhbGl6YXRpb25WZWN0b3JxAH4AAkwAB2tleW5hbWVxAH4AAUwABm1kX2FsZ3EAfgABWwAUbWVzc2FnZUludGVncml0eUNvZGVxAH4AAlsABW5vbmNlcQB+AAJ4cAAAABB0AAZTdW5KQ0V0ABRBRVMvQ0JDL1BLQ1M1UGFkZGluZ3VyAAJbQqzzF/gGCFTgAgAAeHAAAAAQrHU695AdpDe6qCi7F+t6CHVxAH4ABgAAABBFLVwkdOo81YUIDfnESz/McHQABVNIQS0xdXEAfgAGAAAAFHojyB+mD9EZKeELh/ELeZa+pikJdXEAfgAGAAAAEOe80FLLsEiQudv9TQmsYmc=","XXXXXXXXXXXTEST1"));
	}
	
	public static String padRight(String s, int n, char c) {
	     return String.format("%1$-" + n + "s", s).replace(' ', c);  
	}

	public static String padLeft(String s, int n, char c) {
	    return String.format("%1$" + n + "s", s).replace(' ', c);  
	}

}
