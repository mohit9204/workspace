package com.centurylink.cgs.dispatchalarm.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmDatabaseReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmSqlReference;
import com.centurylink.cgs.dispatchalarm.util.Constants;

public class DispatchAlarmDatabaseReferenceMapper implements RowMapper<DispatchAlarmDatabaseReference> {
	@Override
	public DispatchAlarmDatabaseReference mapRow(ResultSet rs, int rowNum) throws SQLException {
		DispatchAlarmDatabaseReference result = new DispatchAlarmDatabaseReference();
		result.setDatabaseId(rs.getString("DATABASE_ID"));
		result.setEnvironment(rs.getString("ENVIRONMENT_VAL"));
		result.setUrl(rs.getString("URL_VAL"));
		result.setUserId(rs.getString("USER_ID"));
		result.setEncryptedPassword(rs.getString("PASSWORD_VAL"));
		result.setDriverClassName(rs.getString("DRIVER_CLASS_NM"));
		result.setConnectionProperties(rs.getString("CONNECTION_PROPERTIES_VAL"));
		return result;
	}
}