package com.centurylink.cgs.dispatchalarm.client;

import java.io.StringReader;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.centurylink.cgs.dispatchalarm.exception.AlarmId;
import com.centurylink.cgs.dispatchalarm.exception.DispatchAlarmException;
import com.centurylink.cgs.dispatchalarm.model.Alarm;
import com.centurylink.cgs.dispatchalarm.model.MessageSummary;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.splunkinterface.Data;
import com.centurylink.cgs.splunkinterface.ResultList;
import com.centurylink.cgs.splunkinterface.ResultList.Results;
import com.centurylink.cgs.splunkinterface.ResultList.Results.Result;
import com.centurylink.cgs.splunkinterface.ResultList.Results.Result.Field;

public class SplunkClient {
	private static JAXBContext jaxbContext;
	static {
		try {
			jaxbContext = JAXBContext.newInstance(	Data.class, ResultList.class);
		} catch (JAXBException e) {
		}
	}
	public List<Alarm> getAlarms() throws DispatchAlarmException{
		try {
			List list = new ArrayList<Alarm>();
			String url = "https://search.splunk-it.corp.intranet:8089/servicesNS/dispapp/search/search/jobs/export?search=search%20earliest=-10m%20index=k8_dispatch-services%20container_name=*-prod%20ALARM_ID%7C%20stats%20count%20by%20container_name%20ALARM_ID&output_mode=xml";
			HashMap<String, HashMap<String,Integer>> resultsMap = new HashMap<String, HashMap<String,Integer>>();
			ResultList resultList = getResults(url);
			for (Results results : resultList.getResults()) {
				for (Result result : results.getResult()) {
					HashMap<String, Integer> containerMap = null;
					String alarmId = null;
					for (Field field : result.getField()) {
						if ("container_name".equals(field.getK())) {
							containerMap = resultsMap.get(field.getValue().getText());
							if (containerMap == null) {
								containerMap = new HashMap<String, Integer>();
								resultsMap.put(field.getValue().getText(), containerMap);
							}
						}
						if ("ALARM_ID".equals(field.getK())) {
							alarmId = field.getValue().getText();
						}
						if ("count".equals(field.getK())) {
							containerMap.put(alarmId, Integer.parseInt(field.getValue().getText()));
						}
					}
				}
			}
			
			for (String containerName : resultsMap.keySet()) {
				for (String alarmId : resultsMap.get(containerName).keySet()) {
					Alarm alarm = new Alarm();
					String environment = containerName.substring(containerName.lastIndexOf("-")+1);
					String service = containerName.substring(0, containerName.lastIndexOf("-"));
					alarm.setServiceName(service);
					alarm.setEnvironment(environment);
					alarm.setCount(resultsMap.get(containerName).get(alarmId));
					alarm.setAlarmId(alarmId);
					list.add(alarm);
				}
			}
	
			return list;
		} catch (Exception e) {
			DispatchAlarmException exception = new DispatchAlarmException(e.getMessage(), e, AlarmId.SPLUNK_CLIENT_GET_ALARMS, new LogContext().setMessage("SplunkClient.getAlarms()"));
			throw exception;
		}
	}
	public List<MessageSummary> getMessages(Alarm alarm) throws Exception {
		List list = new ArrayList<MessageSummary>();
		String url = String.format("https://search.splunk-it.corp.intranet:8089/servicesNS/dispapp/search/search/jobs/export?search=search earliest=-10m index=k8_dispatch-services container_name=*%s-%s ALARM_ID=%s | stats count by Message&output_mode=xml",alarm.getServiceName(),alarm.getEnvironment(),alarm.getAlarmId());
		url = url.replace(" ", "%20").replace("|", "%7C");
		ResultList resultList = getResults(url);
		HashMap<String, Integer> resultMap = new HashMap<String, Integer>();
		for (Results results : resultList.getResults()) {
			for (Result result : results.getResult()) {
				MessageSummary message = new MessageSummary(alarm);
				String alarmId = null;
				for (Field field : result.getField()) {
					if ("Message".equals(field.getK())) {
						message.setMessage(field.getValue().getText());
					}
					if ("count".equals(field.getK())) {
						message.setCount(Integer.parseInt(field.getValue().getText()));
					}
				}
				if (!resultMap.containsKey(message.getMessage())) {
					resultMap.put(message.getMessage(), message.getCount());
					list.add(message);
				}
			}
		}
		return list;
	}
	private ResultList getResults(String url) throws Exception {
		CredentialsProvider provider = new BasicCredentialsProvider();
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials("DISPAPP", "86Gv8qvS");
		provider.setCredentials(AuthScope.ANY, credentials);			
        SSLContext sslcontext = SSLContexts.custom().useSSL().build();
        sslcontext.init(null, new X509TrustManager[]{new HttpsTrustManager()}, new SecureRandom());
        SSLConnectionSocketFactory factory = new SSLConnectionSocketFactory(sslcontext,
        		NoopHostnameVerifier.INSTANCE);
		CloseableHttpClient httpclient =  HttpClients.custom()
                .setDefaultCredentialsProvider(provider)
                .setMaxConnPerRoute(20)
                .setMaxConnTotal(20)
                .setSSLSocketFactory(factory)
                .build();
		HttpGet httpGet = new HttpGet(url);
		CloseableHttpResponse response1 = httpclient.execute(httpGet);
		String responseString = EntityUtils.toString(response1.getEntity(), "UTF-8");
		//System.out.println(responseString);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

		StringReader sr = new StringReader(String.format("<resultList>%s</resultList>", responseString.replace("<?xml version='1.0' encoding='UTF-8'?>", "")));
		ResultList resultList = (ResultList) unmarshaller.unmarshal(sr);
		return resultList;
	}
}
