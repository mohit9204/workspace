package com.centurylink.cgs.dispatchalarm.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import com.centurylink.cgs.dispatchalarm.dao.JobsDao;
import com.centurylink.cgs.dispatchalarm.dao.JobsDaoImpl;
import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.reference.DispatchReference;


public class Configuration {
	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(Configuration.class);
	
	
	private static Configuration instance = new Configuration();
	private Configuration() {
	}
	public static Configuration getInstance() {
		return instance;
	}
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected  DataSource dataSource; 
	
	@Autowired
	JobsDao jobsDao;

	private static DispatchReference ref = new DispatchReference();
	
	public static void refresh() 
	{
	    LOG.info("Refreshing configuration settings");
	    ref.refreshTable(Constants.DISPATCH_ALARM_OPTIONS);
	}
	public DataSource getDataSource() {
		return dataSource;
	}
}
