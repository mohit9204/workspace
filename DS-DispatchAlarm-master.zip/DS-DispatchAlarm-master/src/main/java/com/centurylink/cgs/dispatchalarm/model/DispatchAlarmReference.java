package com.centurylink.cgs.dispatchalarm.model;

public class DispatchAlarmReference {
	int sequenceId;
	String serviceName;
	String alarmId;
	int threshold;
	String destinationType;
	String destinationValue;
	boolean continueIndicator;
	String instructions;
	
	public int getSequenceId() {
		return sequenceId;
	}
	public void setSequenceId(int sequenceId) {
		this.sequenceId = sequenceId;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getAlarmId() {
		return alarmId;
	}
	public void setAlarmId(String alarmId) {
		this.alarmId = alarmId;
	}
	public int getThreshold() {
		return threshold;
	}
	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}
	public String getDestinationType() {
		return destinationType;
	}
	public void setDestinationType(String destinationType) {
		this.destinationType = destinationType;
	}
	public String getDestinationValue() {
		return destinationValue;
	}
	public void setDestinationValue(String destinationValue) {
		this.destinationValue = destinationValue;
	}
	public boolean isContinueIndicator() {
		return continueIndicator;
	}
	public void setContinueIndicator(boolean continueIndicator) {
		this.continueIndicator = continueIndicator;
	}
	public String getInstructions() {
		return instructions;
	}
	public void setInstructions(String instructions) {
		this.instructions = instructions;
	}
}
