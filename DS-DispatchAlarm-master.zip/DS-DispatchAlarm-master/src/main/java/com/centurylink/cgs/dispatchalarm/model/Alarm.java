package com.centurylink.cgs.dispatchalarm.model;

public class Alarm {
	String serviceName;
	String environment;
	String alarmId;
	int count;
	
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getAlarmId() {
		return alarmId;
	}
	public void setAlarmId(String alarmId) {
		this.alarmId = alarmId;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return String.format("Service=%s Environment=%s Alarm=%s Count=%d", serviceName, environment, alarmId, count);
	}
	
}
