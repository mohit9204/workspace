package com.centurylink.cgs.dispatchalarm.service;

import java.net.URI;
import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.util.Configuration;
import com.centurylink.cgs.dispatchalarm.util.Constants;
import com.centurylink.cgs.dispatchcommon.encryption.EncryptionHelper;
import com.centurylink.cgs.dispatchcommon.healthcheck.VersionHealthInfo;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;

public class DispatchAlarmVersionServiceImpl implements DispatchAlarmVersionService {

	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(VersionHealthResponse.class);

	private final static String ENVIRONMENT_KEY = "SPRING_PROFILES_ACTIVE";

	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 

	@Value("${client.timeout}")
	private int timeout;

	@Autowired
	private Configuration configuration;
		
	public VersionHealthResponse getVersionDetails() throws Exception{
		

		VersionHealthResponse healthResponse = new VersionHealthResponse();
		BaseResponse base = new BaseResponse();
		healthResponse.setBaseResponse(base);
		boolean success = true;
		BasicDataSource basicDataSrc  = (BasicDataSource) dataSource; 

		LogContext context = new LogContext().appendMessage("Version and Health Check").add("DB", "jobsDataSource");
		LOG.info(context);

		if (!VersionHealthInfo.setVersionInfo(healthResponse, Constants.APPLICATION_SERVICE_NAME))
			success = false;	

		if (!VersionHealthInfo.addDBConnection(healthResponse, basicDataSrc))
			success = false;

		if (!success) {
			base.setResponseStatus(BaseResponse.responseStatusValues.Failure);
			base.setMessage("Health Check Failed");
			base.setReasonCode(-1);
		} else {
			base.setResponseStatus(BaseResponse.responseStatusValues.Success);
			base.setMessage("Health Check Succeeded");
			base.setReasonCode(1);
		}

		LOG.info("VersionHealthCheck output: \n" + healthResponse.toJSONString());
		return healthResponse;	
	}
}
