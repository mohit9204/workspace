package com.centurylink.cgs.dispatchalarm.dao;

import java.util.List;
import java.util.Map;

import com.centurylink.cgs.dispatchalarm.exception.DispatchAlarmException;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmDatabaseReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmSqlReference;

public interface JobsDao {

	public List<DispatchAlarmReference> getDispatchAlarmReference() throws DispatchAlarmException;
	public List<DispatchAlarmSqlReference> getDispatchAlarmSqlReference() throws DispatchAlarmException;
	public DispatchAlarmDatabaseReference getDispatchAlarmDatabaseReference(String databaseId) throws DispatchAlarmException;
}
