package com.centurylink.cgs.dispatchalarm.model;

public class MessageSummary {
	Alarm alarm;
	String message;
	int count;
	
	public MessageSummary(Alarm alarm) {
		super();
		this.alarm = alarm;
	}
	
	public Alarm getAlarm() {
		return alarm;
	}
	public void setAlarm(Alarm alarm) {
		this.alarm = alarm;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
}
