package com.centurylink.cgs.dispatchalarm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.util.Configuration;

public class ScheduleServiceImpl implements ScheduleService {

	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(ScheduleServiceImpl.class);
	
	@Autowired
	Configuration configuration;
	
	@Autowired 
	AlarmService alarmService;
	
	@Autowired 
	SqlAlarmService sqlAlarmService;
	
	@Scheduled(fixedRate = 60000*5) // 5 minutes
	@Override
	public void refreshConfiguration() {
		LOG.info("Refreshing configuration");
		configuration.refresh();

	}
	@Scheduled(fixedRate = 60000*10) // 10 minutes
	//@Scheduled(fixedRate = 1000) // 1 second
	@Override
	public void monitorAlarms() {
		alarmService.monitorAlarms();
	}
	@Scheduled(fixedRate = 60000*10) // 10 minutes
	//@Scheduled(fixedRate = 1000) // 1 second
	@Override
	public void monitorSqlAlarms() {
		sqlAlarmService.monitorAlarms();
	}

}
