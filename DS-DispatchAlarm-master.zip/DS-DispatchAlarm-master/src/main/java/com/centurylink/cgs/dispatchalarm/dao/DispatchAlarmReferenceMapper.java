package com.centurylink.cgs.dispatchalarm.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmReference;
import com.centurylink.cgs.dispatchalarm.util.Constants;

public class DispatchAlarmReferenceMapper implements RowMapper<DispatchAlarmReference> {
	@Override
	public DispatchAlarmReference mapRow(ResultSet rs, int rowNum) throws SQLException {
		DispatchAlarmReference result = new DispatchAlarmReference();
		result.setSequenceId(rs.getInt("SEQUENCE_NO"));
		result.setServiceName(rs.getString("SERVICE_NM_VAL"));
		result.setAlarmId(rs.getString("ALARM_ID"));
		result.setThreshold(rs.getInt("THRESHOLD_VAL"));
		result.setDestinationType(rs.getString("DESTINATION_TYP"));
		result.setDestinationValue(rs.getString("DESTINATION_VAL"));
		String continueInd = rs.getString("CONTINUE_IND");
		if (Constants.YES.equals(continueInd))
			result.setContinueIndicator(true);
		else
			result.setContinueIndicator(false);
		result.setInstructions(rs.getString("INSTRUCTIONS_TXT"));
		return result;
	}
}