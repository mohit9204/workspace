package com.centurylink.cgs.dispatchalarm.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.centurylink.cgs.dispatchalarm.exception.AlarmId;
import com.centurylink.cgs.dispatchalarm.exception.DispatchAlarmException;
import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmDatabaseReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmSqlReference;
import com.centurylink.cgs.dispatchalarm.util.Configuration;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

@Repository
public class JobsDaoImpl extends NamedParameterJdbcDaoSupport implements JobsDao {
	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(JobsDaoImpl.class);

	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 
	
	@Autowired
	Configuration configuration;
	
	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}
	@Override
	public List<DispatchAlarmReference> getDispatchAlarmReference() throws DispatchAlarmException {
		LogContext logContext = new LogContext();
		try {
			List<DispatchAlarmReference> list =  this.getNamedParameterJdbcTemplate().query(SQLQueries.GET_DISPATCH_ALARM_REF, new DispatchAlarmReferenceMapper());
			return list;
		} catch (Exception ex) {
			DispatchAlarmException exception = new DispatchAlarmException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_DISPATCH_ALARM_REFERENCE,
					logContext);
			throw exception;
		}
	}
	@Override
	public List<DispatchAlarmSqlReference> getDispatchAlarmSqlReference() throws DispatchAlarmException {
		LogContext logContext = new LogContext();
		try {
			List<DispatchAlarmSqlReference> list =  this.getNamedParameterJdbcTemplate().query(SQLQueries.GET_DISPATCH_ALARM_SQL_REF, new DispatchAlarmSqlReferenceMapper());
			return list;
		} catch (Exception ex) {
			DispatchAlarmException exception = new DispatchAlarmException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_DISPATCH_ALARM_SQL_REFERENCE,
					logContext);
			throw exception;
		}
	}
	@Override
	public DispatchAlarmDatabaseReference getDispatchAlarmDatabaseReference(String databaseId) throws DispatchAlarmException {
		LogContext logContext = new LogContext();
		Map<String, Object> paramMap = new HashMap<>();
		
		logContext.add("databaseId", databaseId);
		paramMap.put("databaseId", databaseId);
		try {
			List<DispatchAlarmDatabaseReference> list =  this.getNamedParameterJdbcTemplate().query(SQLQueries.GET_DISPATCH_ALARM_DB_REF, paramMap, new DispatchAlarmDatabaseReferenceMapper());
			return list.get(0);
		} catch (Exception ex) {
			DispatchAlarmException exception = new DispatchAlarmException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_DISPATCH_ALARM_DB_REFERENCE,
					logContext);
			throw exception;
		}
	}

}
