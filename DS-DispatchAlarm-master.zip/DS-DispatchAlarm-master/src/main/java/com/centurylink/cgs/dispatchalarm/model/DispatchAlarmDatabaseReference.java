package com.centurylink.cgs.dispatchalarm.model;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

import com.centurylink.cgs.dispatchcommon.encryption.EncryptionHelper;

public class DispatchAlarmDatabaseReference {
	String databaseId;
	String environment;
	String url;
	String userId;
	String encryptedPassword;
	String driverClassName;
	String connectionProperties;
	
	public String getDatabaseId() {
		return databaseId;
	}
	public void setDatabaseId(String databaseId) {
		this.databaseId = databaseId;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEncryptedPassword() {
		return encryptedPassword;
	}
	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}
	public String getDriverClassName() {
		return driverClassName;
	}
	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}
	public String getConnectionProperties() {
		return connectionProperties;
	}
	public void setConnectionProperties(String connectionProperties) {
		this.connectionProperties = connectionProperties;
	}
	public synchronized DataSource getDataSource() {
		DataSource source = DataSourceCache.get(this.databaseId);
		if (source == null) {
			BasicDataSource dataSource = new BasicDataSource();;
			dataSource.setUrl(this.url);
			dataSource.setPassword(EncryptionHelper.decrypt(this.encryptedPassword));
			dataSource.setUsername(this.userId);
			dataSource.setDriverClassName(this.driverClassName);
			dataSource.setConnectionProperties(this.connectionProperties);
			DataSourceCache.add(this.databaseId, dataSource);
			return dataSource;
		} else
			return source;
	}
}
