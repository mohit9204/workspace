package com.centurylink.cgs.dispatchalarm.service;

import java.rmi.RemoteException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.dispatchalarm.client.SplunkClient;
import com.centurylink.cgs.dispatchalarm.dao.JobsDao;
import com.centurylink.cgs.dispatchalarm.exception.AlarmId;
import com.centurylink.cgs.dispatchalarm.exception.DispatchAlarmException;
import com.centurylink.cgs.dispatchalarm.helper.Pager;
import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.model.Alarm;
import com.centurylink.cgs.dispatchalarm.model.AlarmHandler;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmReference;
import com.centurylink.cgs.dispatchalarm.model.MessageSummary;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

@Service
public class AlarmServiceImpl implements AlarmService {
	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(AlarmServiceImpl.class);
	
	@Autowired
	JobsDao jobsDao;
	
	@Autowired
	SplunkClient splunk;
	
	@Autowired
	AlarmHandler alarmHandler;
	
	@Override
	public void monitorAlarms() {
		try {
			
			LOG.info("Starting monitor");
			
			List<DispatchAlarmReference> alarmConfigurations = jobsDao.getDispatchAlarmReference();
			List<Alarm> alarms = splunk.getAlarms();
			for (Alarm alarm : alarms) {
				for (DispatchAlarmReference alarmConfig : alarmConfigurations) {
					if ((alarmConfig.getServiceName().equalsIgnoreCase(alarm.getServiceName()) ||  alarmConfig.getServiceName().equals("*"))
							&& (alarmConfig.getAlarmId().equalsIgnoreCase(alarm.getAlarmId()) ||  alarmConfig.getAlarmId().equals("*"))
							&& alarmConfig.getThreshold() <= alarm.getCount()) {
						String messageString = null;
						if (alarmConfig.getDestinationType().equalsIgnoreCase("sendEmail")) {
							try {
								List<MessageSummary> messages = splunk.getMessages(alarm);
								messageString = getMessageString(messages);
							} catch (Exception e) {
								DispatchAlarmException exception = new DispatchAlarmException(e.getMessage(), e, AlarmId.ALARM_SERVICE_IMPL_MONITOR_ALARMS,
										new LogContext().add("",""));
							}
						}
						alarmHandler.takeAction(alarm, alarmConfig, messageString);
						if (!alarmConfig.isContinueIndicator())
							break;
					}
				}
			}
		} catch (DispatchAlarmException e) {
			LOG.error(e);
		}
	}
	private String getMessageString(List<MessageSummary> messages) {

		StringBuilder string = new StringBuilder();
		for(MessageSummary message : messages) {
			string.append(String.format("Message: %s     -     Count: %d \n", message.getMessage(), message.getCount()));
		}
		return string.toString();
	}
}
