package com.centurylink.cgs.dispatchalarm.service;

public interface AlarmService {
	public void monitorAlarms();
}
