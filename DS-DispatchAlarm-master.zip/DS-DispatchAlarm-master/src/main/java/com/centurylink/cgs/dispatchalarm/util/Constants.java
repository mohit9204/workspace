package com.centurylink.cgs.dispatchalarm.util;

public class Constants {

	public static final String APPLICATION_SERVICE_NAME = "DispatchAlarm";
	public static final String DISPATCH_ALARM_OPTIONS = "DISPATCH_ALARM_OPTIONS";	
	public static final String NO = "N";
	public static final String YES = "Y";
}
