package com.centurylink.cgs.dispatchalarm.service;


public interface ScheduleService {
	public void refreshConfiguration();
	public void monitorAlarms();
	public void monitorSqlAlarms();
}
