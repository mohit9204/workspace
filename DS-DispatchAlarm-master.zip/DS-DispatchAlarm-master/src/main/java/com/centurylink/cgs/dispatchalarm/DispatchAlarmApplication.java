package com.centurylink.cgs.dispatchalarm;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;


import com.centurylink.cgs.dispatchalarm.client.SplunkClient;
import com.centurylink.cgs.dispatchalarm.dao.JobsDao;
import com.centurylink.cgs.dispatchalarm.dao.JobsDaoImpl;
import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.model.AlarmHandler;
import com.centurylink.cgs.dispatchalarm.service.AlarmService;
import com.centurylink.cgs.dispatchalarm.service.AlarmServiceImpl;
import com.centurylink.cgs.dispatchalarm.service.DispatchAlarmHealthService;
import com.centurylink.cgs.dispatchalarm.service.DispatchAlarmHealthServiceImpl;
import com.centurylink.cgs.dispatchalarm.service.DispatchAlarmVersionService;
import com.centurylink.cgs.dispatchalarm.service.DispatchAlarmVersionServiceImpl;
import com.centurylink.cgs.dispatchalarm.service.ScheduleService;
import com.centurylink.cgs.dispatchalarm.service.ScheduleServiceImpl;
import com.centurylink.cgs.dispatchalarm.service.SqlAlarmService;
import com.centurylink.cgs.dispatchalarm.service.SqlAlarmServiceImpl;
import com.centurylink.cgs.dispatchalarm.util.Configuration;
import com.centurylink.cgs.dispatchcommon.encryption.EncryptedPasswordDataSource;
import com.centurylink.cgs.dispatchcommon.mail.Mailer;
import com.centurylink.cgs.dispatchcommon.reference.DispatchReference;
import com.centurylink.cgs.dispatchencryption.EncryptionHelper;



@EnableScheduling
@ComponentScan(basePackages = "com.centurylink.cgs.dispatchalarm")
@SpringBootApplication
public class DispatchAlarmApplication extends SpringBootServletInitializer  {
	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(DispatchAlarmApplication.class);
	
	@Value("${jobs.datasource.username}")
	private String jobsUsername;

	@Value("${jobs.datasource.encryptedPassword}")
	private String jobsPassword;
	
	@Value("${client.ssl.trust-store}")
	private Resource trustStore;

	@Value("${client.ssl.trust-store-password}")
	private String trustStorePassword;

	
	public static void main(String[] args) {
		LOG.trace("ClickSynchronization::main::start");
		SpringApplication.run(DispatchAlarmApplication.class, args);

		LOG.info("  >>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		LOG.info("  >>       Dispatch Alarm Service is STARTED       <<");
		LOG.info("  >>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
	}

	@Primary
	@Bean(name = "jobsDataSource")
	@ConfigurationProperties(prefix = "jobs.datasource")
	public DataSource dataSource() {
		EncryptedPasswordDataSource source = new EncryptedPasswordDataSource();
		source.setUsername(jobsUsername);
		source.setEncryptedPassword(jobsPassword);
		return source;
	}

	@Bean(name = "jobsJdbc") 
	public JdbcTemplate jdbcTemplate(DataSource jobsDataSource) { 
		return new JdbcTemplate(jobsDataSource); 
	} 

	@Bean
	@DependsOn("jobsDataSource")
	public JobsDao jobsDao() {
		return new JobsDaoImpl();
	}
	@Bean
    @DependsOn("jobsDataSource")
	public Configuration configuration() {
		return  Configuration.getInstance();
	}
	@Bean
	public DispatchAlarmHealthService dispatchAlarmHealthHealthService() {
		return new DispatchAlarmHealthServiceImpl();
	}
	@Bean
	public DispatchAlarmVersionService dispatchAlarmHealthVersionService() {
		return new DispatchAlarmVersionServiceImpl();
	}
	@Bean
	public AlarmService alarmService() {
		return new AlarmServiceImpl();
	}
	@Bean
	public SqlAlarmService sqlAlarmService() {
		return new SqlAlarmServiceImpl();
	}
	@Bean
	public AlarmHandler alarmHandler() {
		return new AlarmHandler();
	}
	@Bean
	public ScheduleService scheduleService() {
		return new ScheduleServiceImpl();
	}
	@Bean
	public SplunkClient splunkClient() {
		return new SplunkClient();
	}
	@Bean
	public Mailer mailer() throws Exception {
		DispatchReference ref = new DispatchReference();
		HashMap<String,String> map = ref.getReferenceMap(dataSource(), Mailer.MAILER_OPTIONS_TABLE);
		return new Mailer(map.get(Mailer.USER),EncryptionHelper.decrypt(map.get(Mailer.ENCRYPTED_PASSWORD)),map);
	}

}
