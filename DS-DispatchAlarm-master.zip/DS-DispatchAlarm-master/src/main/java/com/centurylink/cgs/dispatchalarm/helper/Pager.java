package com.centurylink.cgs.dispatchalarm.helper;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import com.qintra.net.WebServices.services.NETPaging.NETPaging;
import com.qintra.net.WebServices.services.NETPaging.NETPagingServiceLocator;
import webservice.net.qwest.com.PagingRequest;
import webservice.net.qwest.com.PagingResponse;

public class Pager {

    private static NETPagingServiceLocator locator = new NETPagingServiceLocator();
    private static NETPaging net;
    private static final String FROM_CUID = "DISPAPP";
    private static final String NULL_RESPONSE = "Null Page Response";
    
    static {
    	try {
			net = locator.getNETPaging();
		} catch (ServiceException e) {
			e.printStackTrace();
		}
    }
	public static String pageGroup(String groupId, String message, int severity) throws RemoteException {
	    PagingRequest req   = new PagingRequest();
		req.setMessageText(message);
		req.setFromCuid(FROM_CUID);
		req.setGroupPins(new String [] {groupId});
		req.setSeverity(severity);
		PagingResponse resp = net.sendNotification(req);
		return resp == null ? NULL_RESPONSE : resp.getStatusText();
	}
	public static String pageUser(String cuid, String message) throws RemoteException {
	    PagingRequest req   = new PagingRequest();
		req.setMessageText(message);
		req.setFromCuid(FROM_CUID);
		req.setToCuids(new String[]{cuid});
		PagingResponse resp = net.sendNotification(req);
		return resp == null ? NULL_RESPONSE : resp.getStatusText();
	}
}
