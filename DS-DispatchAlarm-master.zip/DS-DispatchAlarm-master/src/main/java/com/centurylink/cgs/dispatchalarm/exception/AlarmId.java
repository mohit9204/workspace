package com.centurylink.cgs.dispatchalarm.exception;

public class AlarmId {

	public static final int JOBS_DAO_IMPL_GET_DISPATCH_ALARM_REFERENCE = 778001;
	public static final int SPLUNK_CLIENT_GET_ALARMS = 778002;
	public static final int ALARM_SERVICE_IMPL_TAKE_ACTION = 778003;
	public static final int MAILER_SEND = 778004;
	public static final int JOBS_DAO_IMPL_GET_DISPATCH_ALARM_SQL_REFERENCE = 778005;
	public static final int JOBS_DAO_IMPL_GET_DISPATCH_ALARM_DB_REFERENCE = 778006;
	public static final int ALARM_SERVICE_IMPL_MONITOR_ALARMS = 778007;

}
