package com.centurylink.cgs.dispatchalarm.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmSqlReference;
import com.centurylink.cgs.dispatchalarm.util.Constants;

public class DispatchAlarmSqlReferenceMapper implements RowMapper<DispatchAlarmSqlReference> {
	@Override
	public DispatchAlarmSqlReference mapRow(ResultSet rs, int rowNum) throws SQLException {
		DispatchAlarmSqlReference result = new DispatchAlarmSqlReference();
		result.setServiceName(rs.getString("SERVICE_NM_VAL"));
		result.setAlarmId(rs.getString("ALARM_ID"));
		result.setDatabaseId(rs.getString("DATABASE_ID"));
		result.setSql(rs.getString("SQL_VAL"));
		result.setCriteria(rs.getString("CRITERIA_NM"));
		result.setOperator(rs.getString("CRITERIA_OPERATOR_VAL"));
		result.setValue(rs.getString("CRITERIA_VAL"));
		return result;
	}
}