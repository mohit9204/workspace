package com.centurylink.cgs.dispatchalarm.logging;

import com.centurylink.cgs.dispatchalarm.util.Constants;
import com.centurylink.cgs.dispatchcommon.logging.DispatchLogger;


public class DispatchAlarmLogger extends DispatchLogger {
	
	private static final String SERVICE_NAME = Constants.APPLICATION_SERVICE_NAME; 
	
	private DispatchAlarmLogger(Class clazz, String serviceName) {
		super(clazz, serviceName);
	}
	public static DispatchAlarmLogger getLogger(Class clazz) {
		DispatchAlarmLogger instance = new DispatchAlarmLogger(clazz, SERVICE_NAME);
		return instance;
	}
}
