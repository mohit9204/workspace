package com.centurylink.cgs.dispatchalarm.service;

import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;

public interface DispatchAlarmHealthService {
	public VersionHealthResponse getHealthDetails();
}
