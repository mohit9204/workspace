package com.centurylink.cgs.dispatchalarm.exception;

import com.centurylink.cgs.dispatchcommon.exception.DispatchException;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;

public class DispatchAlarmException extends DispatchException {
	/**
	 *  Common Exception class for DispatchAlarm service
	 */
	private static final long serialVersionUID = 1L;

	public DispatchAlarmException(String message, int alarmId, LogContext context) {
		super(message, alarmId, context);
	}
	public DispatchAlarmException(String message, Throwable cause, int alarmId, LogContext context) {
		super(message, cause, alarmId, context);
	}

}
