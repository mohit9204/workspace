package com.centurylink.cgs.dispatchalarm.service;

public interface SqlAlarmService {
	public void monitorAlarms();
}
