package com.centurylink.cgs.dispatchalarm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.service.DispatchAlarmHealthService;
import com.centurylink.cgs.dispatchalarm.service.DispatchAlarmVersionService;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;


@RestController
public class DispatchAlarmController {
	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(DispatchAlarmController.class);
	
	@Autowired
	private DispatchAlarmHealthService clickSynchronizationHealthService;
	
	@Autowired
	private DispatchAlarmVersionService clickSynchronizationVersionService;
	
	@GetMapping(value = "/healthz", produces = "application/json")
	public VersionHealthResponse healthz() throws Exception {
		
		return clickSynchronizationHealthService.getHealthDetails();
    }
	@GetMapping(value = "/version", produces = "application/json")
	public VersionHealthResponse version() throws Exception {
		
		return clickSynchronizationVersionService.getVersionDetails();
    }
}
