package com.centurylink.cgs.dispatchalarm.service;

import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.util.Constants;
import com.centurylink.cgs.dispatchcommon.healthcheck.VersionHealthInfo;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;

public class DispatchAlarmHealthServiceImpl implements DispatchAlarmHealthService {
	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(DispatchAlarmHealthServiceImpl.class);

	@Override
	public VersionHealthResponse getHealthDetails() {
		

		VersionHealthResponse healthResponse = new VersionHealthResponse();
		BaseResponse base = new BaseResponse();
		healthResponse.setBaseResponse(base);
		boolean success = true;

		LogContext context = new LogContext().appendMessage("Health Check");
		LOG.info(context);

		if (!VersionHealthInfo.setVersionInfo(healthResponse, Constants.APPLICATION_SERVICE_NAME))
			success = false;	


		if (!success) {
			base.setResponseStatus(BaseResponse.responseStatusValues.Failure);
			base.setMessage("Health Check Failed");
			base.setReasonCode(-1);
		} else {
			base.setResponseStatus(BaseResponse.responseStatusValues.Success);
			base.setMessage("Health Check Succeeded");
			base.setReasonCode(1);
		}
		context.add("status", base.getMessage());
		LOG.info(context);
		return healthResponse;	

	}

}
