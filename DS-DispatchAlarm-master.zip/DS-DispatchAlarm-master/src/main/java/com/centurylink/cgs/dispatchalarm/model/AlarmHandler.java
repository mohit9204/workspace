package com.centurylink.cgs.dispatchalarm.model;

import java.rmi.RemoteException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.centurylink.cgs.dispatchalarm.client.SplunkClient;
import com.centurylink.cgs.dispatchalarm.exception.AlarmId;
import com.centurylink.cgs.dispatchalarm.exception.DispatchAlarmException;
import com.centurylink.cgs.dispatchalarm.helper.Pager;
import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.mail.Mailer;

public class AlarmHandler {

	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(AlarmHandler.class);

	@Autowired
	SplunkClient splunk;
	
	@Autowired
	Mailer mailer;

	public void takeAction(Alarm alarm, DispatchAlarmReference alarmConfig, String additionalText) {
		String message = String.format("%s-%s %s Count=%d", alarm.getServiceName(), alarm.getEnvironment(), alarm.getAlarmId(), alarm.getCount());

		if (alarmConfig.getDestinationType().equalsIgnoreCase("pageGroup")) {
			try {
				Pager.pageGroup(alarmConfig.getDestinationValue(), String.format("%s\n\n%s\n", message, alarmConfig.getInstructions()), 4);
				LOG.info(new LogContext().setMessage("Page sent to group").add("alarm",alarm.toString()).add("destination",alarmConfig.getDestinationValue()));
			} catch (RemoteException ex) {
				DispatchAlarmException exception = new DispatchAlarmException(ex.getMessage(), ex, AlarmId.ALARM_SERVICE_IMPL_TAKE_ACTION,
						new LogContext().add("",""));
				LOG.error(exception);
			}
		} else if (alarmConfig.getDestinationType().equalsIgnoreCase("pageUser")) {
			try {
				Pager.pageUser(alarmConfig.getDestinationValue(), String.format("%s\n%s\n", message, alarmConfig.getInstructions()));
				LOG.info(new LogContext().setMessage("Page sent to user").add("alarm",alarm.toString()).add("destination",alarmConfig.getDestinationValue()));
			} catch (RemoteException ex) {
				DispatchAlarmException exception = new DispatchAlarmException(ex.getMessage(), ex, AlarmId.ALARM_SERVICE_IMPL_TAKE_ACTION,
						new LogContext().add("",""));
				LOG.error(exception);
			}
		} else if (alarmConfig.getDestinationType().equalsIgnoreCase("sendEmail")) {
			try {
				mailer.send(message, alarmConfig.getDestinationValue(), "DispatchServices@CenturyLink.com", String.format("%s\n%s\n%s", message, alarmConfig.getInstructions(),additionalText));
				LOG.info(new LogContext().setMessage("Email").add("alarm",alarm.toString()).add("destination",alarmConfig.getDestinationValue()));
			} catch (Exception ex) {
				DispatchAlarmException exception = new DispatchAlarmException(ex.getMessage(), ex, AlarmId.ALARM_SERVICE_IMPL_TAKE_ACTION,
						new LogContext().add("",""));
				LOG.error(exception);
			}
		}  
	}

	private String getMessageString(List<MessageSummary> messages) {

		StringBuilder string = new StringBuilder();
		for(MessageSummary message : messages) {
			string.append(String.format("Message: %s     -     Count: %d \n", message.getMessage(), message.getCount()));
		}
		return string.toString();
	}

}
