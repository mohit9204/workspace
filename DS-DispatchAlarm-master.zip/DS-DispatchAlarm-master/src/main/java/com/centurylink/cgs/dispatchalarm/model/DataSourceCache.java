package com.centurylink.cgs.dispatchalarm.model;

import java.util.HashMap;

import javax.sql.DataSource;

public class DataSourceCache {
	static HashMap<String, DataSource> cache = new HashMap<String, DataSource>();
	static Object cacheMutex = new Object();
	
	public static void add(String key, DataSource source) {
		synchronized(cacheMutex) {
			cache.put(key, source);
		}
	}
	public static DataSource get(String key) {
		synchronized(cacheMutex) {
			return cache.get(key);
		}
	}
}
