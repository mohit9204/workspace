package com.centurylink.cgs.dispatchalarm.service;

import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import com.centurylink.cgs.dispatchalarm.dao.JobsDao;
import com.centurylink.cgs.dispatchalarm.exception.DispatchAlarmException;
import com.centurylink.cgs.dispatchalarm.logging.DispatchAlarmLogger;
import com.centurylink.cgs.dispatchalarm.model.Alarm;
import com.centurylink.cgs.dispatchalarm.model.AlarmHandler;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmDatabaseReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmReference;
import com.centurylink.cgs.dispatchalarm.model.DispatchAlarmSqlReference;

public class SqlAlarmServiceImpl implements SqlAlarmService {
	private static final DispatchAlarmLogger LOG = DispatchAlarmLogger.getLogger(SqlAlarmServiceImpl.class);
	
	@Autowired
	JobsDao jobsDao;
	
	@Autowired
	AlarmHandler alarmHandler;
	
	@Override
	public void monitorAlarms() {
		JdbcTemplate dao = new JdbcTemplate();
		try {
			List<DispatchAlarmReference> alarmConfigurations = jobsDao.getDispatchAlarmReference();
			List<DispatchAlarmSqlReference> sqlReferences = jobsDao.getDispatchAlarmSqlReference();
			
			for (DispatchAlarmSqlReference sql : sqlReferences) {
				DataSource dataSource = null;
				try {
					DispatchAlarmDatabaseReference database = jobsDao.getDispatchAlarmDatabaseReference(sql.getDatabaseId());
					dao.setDataSource(database.getDataSource());
					List<Map<String, Object>> list = dao.queryForList(sql.getSql());
					for (Map<String, Object> map : list) {
						String criteria = map.get(sql.getCriteria()).toString();
						if (matchesCriteria(criteria, sql)) {
							Alarm alarm = new Alarm();
							alarm.setAlarmId(sql.getAlarmId());
							alarm.setServiceName(sql.getServiceName());
							alarm.setEnvironment(database.getEnvironment());
							alarm.setCount(1);
							try { alarm.setCount(Integer.parseInt(criteria)); } catch (Exception e) {}
							for (DispatchAlarmReference alarmConfig : alarmConfigurations) {
								if ((alarmConfig.getServiceName().equalsIgnoreCase(alarm.getServiceName()) ||  alarmConfig.getServiceName().equals("*"))
										&& (alarmConfig.getAlarmId().equalsIgnoreCase(alarm.getAlarmId()) ||  alarmConfig.getAlarmId().equals("*"))
										&& alarmConfig.getThreshold() <= alarm.getCount()) {
									String additionalText = String.format("%s %s %s %s", sql.getCriteria(), criteria, sql.getOperator(), sql.getValue());
									alarmHandler.takeAction(alarm , alarmConfig, additionalText);
									if (!alarmConfig.isContinueIndicator())
										break;
								}
							}
						}
					}
				} catch (DispatchAlarmException e) {
					LOG.error(e);
				}
			}
		} catch (DispatchAlarmException e) {
			LOG.error(e);
			
		}

	}
	private boolean matchesCriteria(String criteria, DispatchAlarmSqlReference sql) {
		int numericCriteria = -1;
		int numericValue = -1;
		try {numericCriteria = Integer.parseInt(criteria);} catch (Exception e) {}
		try {numericValue = Integer.parseInt(sql.getValue());} catch (Exception e) {}
		if ("=".equals(sql.getOperator())) {
			if (criteria.equals(sql.getValue()))
				return true;
			else
				return false;
		} else if (">=".equals(sql.getOperator()) && numericCriteria >= numericValue) {
				return true;
		} else if (">".equals(sql.getOperator()) && numericCriteria > numericValue) {
			return true;
		} else if ("<=".equals(sql.getOperator()) && numericCriteria <= numericValue) {
			return true;
		} else if ("<".equals(sql.getOperator()) && numericCriteria < numericValue) {
			return true;
		}
		return false;
	}
}
