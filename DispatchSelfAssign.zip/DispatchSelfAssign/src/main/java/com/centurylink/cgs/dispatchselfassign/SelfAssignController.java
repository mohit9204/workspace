package com.centurylink.cgs.dispatchselfassign;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;
import com.centurylink.cgs.dispatchcommon.reference.DispatchReference;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.model.RequestContext;
import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignRequest;
import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;
import com.centurylink.cgs.dispatchselfassign.service.AssignJobService;
import com.centurylink.cgs.dispatchselfassign.service.AvailableJobsService;
import com.centurylink.cgs.dispatchselfassign.service.SelfAssignHealthService;
import com.centurylink.cgs.dispatchselfassign.service.SelfAssignVersionService;
import com.centurylink.cgs.dispatchselfassign.service.RescheduledJobsService;
import com.centurylink.cgs.dispatchselfassign.util.Configuration;
import com.centurylink.cgs.dispatchselfassign.util.Constants;




@RestController
//@RequestMapping("/DispatchSelfAssign")
public class SelfAssignController {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(SelfAssignController.class);
	
	@Autowired
	private RequestContext requestContext;
	@Autowired
	private SelfAssignVersionService techAvailableJobsVersionService;
	@Autowired
	private SelfAssignHealthService techAvailableJobsHealthService;
	@Autowired
	private AvailableJobsService techAvailableJobsService;
	@Autowired
	private AssignJobService assignJobService;
	@Autowired
	private RescheduledJobsService techRescheduledJobsService;
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	private DataSource dataSource; 
	
	
	@GetMapping(value = "/version", produces = "application/json")
    public VersionHealthResponse getVersion() {
        return techAvailableJobsVersionService.getVersionDetails();
    }
	
	@GetMapping(value = "/healthz", produces = "application/json")
    public VersionHealthResponse getHealth() {
        return techAvailableJobsHealthService.getHealthDetails();
    }
	
	@GetMapping(value = "/available/{techId}/{district}", produces = "application/json")
    public DispatchSelfAssignResponse availablejobs(@PathVariable String techId, 
    											@PathVariable String district) throws Exception {
		DispatchSelfAssignResponse techAvailableJobsResponse = techAvailableJobsService.engineerGetCandidatesTasks(techId, district);
		LOG.info("SelfAssignController::availablejobs::SelfAssignResponse for requestId: "+techId+"::"+techAvailableJobsResponse);
		return techAvailableJobsResponse;
    }
	@PutMapping(value = "/assign/{correlationId}", produces = "application/json")
	public DispatchSelfAssignResponse assignJob(@RequestBody DispatchSelfAssignRequest assignJobRequest,
										@PathVariable String correlationId) throws Exception {
		LOG.info("SelfAssignController::assignJob::AssignJobRequest for requestId: "+correlationId+"::"+assignJobRequest);
		this.requestContext.setCorrelationId(correlationId);
		DispatchSelfAssignResponse response = assignJobService.assignJob(assignJobRequest.getTechnicianId(), assignJobRequest.getDistrict(), correlationId, assignJobRequest.getCallingSystem(),assignJobRequest.getStatusUpdateTimestamp(), assignJobRequest.getDuration());
		return response;
    }
	@GetMapping(value = "/rescheduledlist/{techId}", produces = "application/json")
    public DispatchSelfAssignResponse rescheduledJobsList(@PathVariable String techId) 
    		throws Exception {
		DispatchSelfAssignResponse techRescheduledListResponse = techRescheduledJobsService.engineerGetRescheduledTasks(techId);
		LOG.info("SelfAssignController::rescheduledJobsList::SelfAssignResponse for requestId: "+techId+"::"+techRescheduledListResponse);
		return techRescheduledListResponse;
    }

	
}
