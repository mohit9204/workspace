package com.centurylink.cgs.dispatchselfassign.util;

import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.centurylink.cgs.dispatchcommon.reference.DispatchReference;
import com.centurylink.cgs.dispatchselfassign.SelfAssignController;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;


public class Configuration {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(Configuration.class);
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected  DataSource dataSource; 
	
	private static DispatchReference ref = new DispatchReference();
	
	public Configuration() {
		
	}
	
	public  int getNumberOfAvailableTasksReturned() throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "numberOfAvailableTasksReturned"));
	}
	public  int getNumberOfAvailableTasksRequested() throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "numberOfAvailableTasksRequested"));
	}
	public  int getStartDateOffset()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "startDateOffset"));
	}
	public  int getEndDateOffset()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "endDateOffset"));
	}
	public  int getTaskConnectTimeout()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "taskConnectTimeout"));
	}
	public  int getTaskReadTimeout()  throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "taskReadTimeout"));
	}
	public  String getTaskEndpointURI()  throws Exception {
		return ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "taskEndpointURI");
	}
	public  String getRemarkText()  throws Exception {
		return ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "remarkTextWithTech");
	}
	public  String getRemarkToDelete()  throws Exception {
		return ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "remarkToDelete");
	}
	public  String getRemarkType()  throws Exception {
		return ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "remarkType");
	}
	public  String getJobStatus()  throws Exception {
		return ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "jobStatus");
	}
	public  boolean isEnforceUserList() throws Exception  {
		String enforceUserList = ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "enforceUserList");
		if ( enforceUserList != null && "true".equalsIgnoreCase(enforceUserList))
			return true;
		else 
			return false;
	}
	public HashMap<String, String> getAuthorizedUsers() throws Exception {
		return ref.getReferenceMap(dataSource, Constants.DISPATCH_SELF_ASSIGN_USERS);
	}
	public HashMap<String, String> getAuthorizedDistricts() throws Exception {
		return ref.getReferenceMap(dataSource, Constants.DISPATCH_SELF_ASSIGN_DISTRICTS);
	}
	public HashMap<String, String>getSortValues() throws Exception {
		return ref.getReferenceMap(dataSource, Constants.DISPATCH_SELF_ASSIGN_SORT);
	}
	public HashMap<String, String>getCriteria() throws Exception {
		return ref.getReferenceMap(dataSource, Constants.DISPATCH_SELF_ASSIGN_CRITERIA);
	}
	public int getClickConnectionTimeout() throws Exception {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "clickConnectionTimeout"));
	}

	public int getClickReadTimeout() throws Exception  {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "clickReadTimeout"));
	}

	public int getMaxConnections() throws Exception  {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "maxConnections"));
	}

	public int getMaxConnectionsPerHost() throws Exception  {
		return Integer.parseInt(ref.get(dataSource, Constants.DISPATCH_SELF_ASSIGN_OPTIONS, "maxConnectionsPerHost"));
	}

	public static void refresh() 
	{
	    LOG.info("Refreshing configuration settings");
	    ref.refreshTable(Constants.DISPATCH_SELF_ASSIGN_USERS);
	    ref.refreshTable(Constants.DISPATCH_SELF_ASSIGN_DISTRICTS);
	    ref.refreshTable(Constants.DISPATCH_SELF_ASSIGN_OPTIONS);
	    ref.refreshTable(Constants.DISPATCH_SELF_ASSIGN_SORT);
	    ref.refreshTable(Constants.DISPATCH_SELF_ASSIGN_CRITERIA);
	}
}
