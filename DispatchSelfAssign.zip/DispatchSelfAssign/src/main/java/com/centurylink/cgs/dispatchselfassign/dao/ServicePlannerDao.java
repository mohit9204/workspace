package com.centurylink.cgs.dispatchselfassign.dao;

import com.centurylink.cgs.dispatchselfassign.exception.DispatchSelfAssignException;
import com.centurylink.cgs.dispatchselfassign.model.StateTimeZone;

public interface ServicePlannerDao {
	public StateTimeZone getTimeZone(String district) throws DispatchSelfAssignException;
}
