package com.centurylink.cgs.dispatchselfassign.dao;

import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchselfassign.dao.sql.SQLQueries;
import com.centurylink.cgs.dispatchselfassign.exception.AlarmId;
import com.centurylink.cgs.dispatchselfassign.exception.DispatchSelfAssignException;
import com.centurylink.cgs.dispatchselfassign.model.AvailableJob;
import com.centurylink.cgs.dispatchselfassign.util.Configuration;
import com.centurylink.cgs.dispatchselfassign.util.QueryBuilder;

@Repository
public class JobsDaoImpl extends NamedParameterJdbcDaoSupport implements JobsDao {
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 
	
	@Autowired
	private Configuration configuration;
	
	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}
	@Override
	public List<AvailableJob> getJobsSummaryByCorrelationIdList(List<String> correlationIdList, String techId, int rowLimit) throws DispatchSelfAssignException {
		LogContext logContext = new LogContext();
		List<AvailableJob> listJobs = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("correlationidList", correlationIdList);
			paramMap.put("techId",  techId);
			paramMap.put("rowLimit", rowLimit);
			logContext.add("correlationidList", correlationIdList);

			QueryBuilder query = new QueryBuilder();
			String queryString = query.buildQuery(SQLQueries.SQL_FIND_JOBS_SUMMARY_BY_CORRELATION_ID,configuration.getCriteria(), configuration.getSortValues()); 
			listJobs = this.getNamedParameterJdbcTemplate().query(
					queryString, paramMap, new AvailableJobRowMapper());

		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_IMPL_GET_JOBS_SUMMARY_BY_CORRELATION_ID_LIST,
					logContext);
			throw e;
		}
		return listJobs;

	}
	@Override
	public List<AvailableJob> getRescheduledJobsSummaryByTechId(String techId) throws DispatchSelfAssignException{
		LogContext logContext = new LogContext();
		List<AvailableJob> listJobs = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("techId",  techId);
			logContext.add("techId", techId);

			listJobs = this.getNamedParameterJdbcTemplate().query(
					SQLQueries.SQL_FIND_RESCHEDULED_JOBS_BY_TECH_ID, paramMap, new AvailableJobRowMapper());

		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_RESCHEDULED_JOBS_SUMMARY_BY_TECH_ID,
					logContext);
			throw e;
		}
		return listJobs;

	}

	@Override
	public void insertRemark(String correlationId, String type, String remark) throws DispatchSelfAssignException {
		LogContext logContext = new LogContext();
		try {
			logContext.add("updating data to upstream_status_publish table", 1);
			int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR};
			this.getJdbcTemplate().update(SQLQueries.INSERT_REMARK, new Object [] {type, remark, correlationId, correlationId});
		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_INSERT_REMARK,
					logContext);
			throw e;
		}
	}
	@Override
	public void deleteRemark(String correlationId, String type, String remark) throws DispatchSelfAssignException {
		LogContext logContext = new LogContext();
		try {
			logContext.add("updating data to upstream_status_publish table", 1);
			int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR};
			this.getJdbcTemplate().update(SQLQueries.DELETE_REMARK, new Object [] {type, remark, correlationId, correlationId});
		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_DELETE_REMARK,
					logContext);
			throw e;
		}
	}
	@Override
	public void updateJobStatus(String correlationId, String status) throws DispatchSelfAssignException {
		LogContext logContext = new LogContext();
		try {
			logContext.add("updating data to upstream_status_publish table", 1);
			int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
			this.getJdbcTemplate().update(SQLQueries.UPDATE_JOB_STATUS, new Object [] {status, correlationId, correlationId});
		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_UPDATE_JOB_STATUS,
					logContext);
			throw e;
		}
	}
	@Override
	public String getJobsCorrelationId(String correlationId) throws DispatchSelfAssignException {
		LogContext logContext = new LogContext();
		List<AvailableJob> listJobs = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("correlationId", correlationId);
			logContext.add("correlationId", correlationId);

			List<Map<String, Object>> returnMap = this.getJdbcTemplate().queryForList(SQLQueries.SQL_FIND_PARENT_CORRELATION_ID, correlationId); 
			if (returnMap != null && returnMap.size() > 0 && returnMap.get(0).get("PARENT_CORRELATION_ID") != null)
				return returnMap.get(0).get("PARENT_CORRELATION_ID").toString();
			else
				return correlationId;
				
		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_JOBS_CORRELATIONID,
					logContext);
			throw e;
		}
	}
	@Override
	public List<String> getWorkingDistricts(String techId) throws DispatchSelfAssignException {
		LogContext logContext = new LogContext();
		List<String> workingDistricts = null;
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("techId",  techId);
			logContext.add("techId", techId);

			workingDistricts = this.getNamedParameterJdbcTemplate().query(
					SQLQueries.SQL_GET_WORKING_DISTRICTS, paramMap, new WorkingDistrictMapper());

		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.JOBS_DAO_IMPL_GET_WORKING_DISTRICTS,
					logContext);
			throw e;
		}
		return workingDistricts;
	}
}
