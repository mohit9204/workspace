package com.centurylink.cgs.dispatchselfassign.service;

import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;


public interface SelfAssignHealthService{

	public VersionHealthResponse getHealthDetails();
}


