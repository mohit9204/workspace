package com.centurylink.cgs.dispatchselfassign.json;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import com.centurylink.cgs.dispatchcommon.datetime.DateTimeHelper;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;;

public class CustomDateDeserializer extends StdDeserializer<Date> {

    public CustomDateDeserializer() { 
        this(null); 
    } 
 
    public CustomDateDeserializer(Class<?> vc) { 
        super(vc); 
    }



	@Override
	public Date deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
	       JsonNode node = jp.getCodec().readTree(jp);
	       String dateTime = node.asText();
	       try {
			return DateTimeHelper.parseDateTimeIgnoreTimeZone(dateTime);
		} catch (ParseException e) {
			return null;
		}

	}
}