package com.centurylink.cgs.dispatchselfassign.model;

import javax.annotation.ManagedBean;

import org.springframework.web.context.annotation.RequestScope;

@ManagedBean
@RequestScope
public class RequestContext {
	
	private String techId;
	private String district;
	private String correlationId;
	
	public String getTechId() {
		return techId;
	}
	public void setTechId(String techId) {
		this.techId = techId;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
}
