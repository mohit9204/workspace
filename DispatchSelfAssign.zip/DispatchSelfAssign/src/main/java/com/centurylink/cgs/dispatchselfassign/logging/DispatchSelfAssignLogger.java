package com.centurylink.cgs.dispatchselfassign.logging;

import com.centurylink.cgs.dispatchcommon.logging.DispatchLogger;
import com.centurylink.cgs.dispatchselfassign.util.Constants;

public class DispatchSelfAssignLogger extends DispatchLogger {
	
	private static final String SERVICE_NAME = Constants.APPLICATION_SERVICE_NAME; 
	
	private DispatchSelfAssignLogger(Class clazz, String serviceName) {
		super(clazz, serviceName);
	}
	public static DispatchSelfAssignLogger getLogger(Class clazz) {
		DispatchSelfAssignLogger instance = new DispatchSelfAssignLogger(clazz, SERVICE_NAME);
		return instance;
	}
}
