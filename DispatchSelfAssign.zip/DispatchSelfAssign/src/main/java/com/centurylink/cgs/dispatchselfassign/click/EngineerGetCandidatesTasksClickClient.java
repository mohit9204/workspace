package com.centurylink.cgs.dispatchselfassign.click;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.util.Configuration;
import com.centurylink.cgs.dispatchselfassign.util.Constants;
import com.clicksoftware.serviceoptimizeservice.AdditionalLoadingCriteria;
import com.clicksoftware.serviceoptimizeservice.ArrayOfAdditionalLoadingCriteria;
import com.clicksoftware.serviceoptimizeservice.DistrictReference;
import com.clicksoftware.serviceoptimizeservice.EngineerGetCandidatesTasks;
import com.clicksoftware.serviceoptimizeservice.EngineerGetCandidatesTasksResponse;
import com.clicksoftware.serviceoptimizeservice.EngineerReference;
import com.clicksoftware.serviceoptimizeservice.OptionalParameters;

public class EngineerGetCandidatesTasksClickClient extends WebServiceGatewaySupport {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(EngineerGetCandidatesTasksClickClient.class);
	
	@Value("${click.date.format}")
	private String clickDateFormat;

	@Value("${click.optimizationservice.soap.action}")
	private String clickSoapAction;
	
	@Autowired
	private Configuration configuration;
	
	
	public EngineerGetCandidatesTasksResponse callEngineerGetCandidatesTasks(String techId, String district, List<String> workingDistricts) throws Exception {
		LOG.trace("EngineerGetCandidatesTasksClickClient::callEngineerGetCandidatesTasks::start");	
		EngineerGetCandidatesTasks request = constructRequest(techId, district, workingDistricts);
		WebServiceTemplate wsTemplate = getWebServiceTemplate();		
		
		EngineerGetCandidatesTasksResponse response = (EngineerGetCandidatesTasksResponse) wsTemplate.marshalSendAndReceive(request, 
				new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(WebServiceMessage requestMessage) throws IOException, TransformerException {
				try {
					SoapMessage soapMsg = ((SoapMessage) requestMessage);
					// get the header from the SOAP message		
					SoapHeader soapHeader = soapMsg.getSoapHeader();
					soapMsg.setSoapAction(clickSoapAction);					
					// create the header element
					OptionalParameters optionalParameters = new OptionalParameters();
					optionalParameters.setCallerIdentity(Constants.CALLER_IDENTY); 
					optionalParameters.setErrorOnNonExistingDictionaries(true);
					// create a marshaller
					JAXBContext context = JAXBContext.newInstance(OptionalParameters.class);
					Marshaller marshaller = context.createMarshaller();
					// marshal the headers into the specified result
					marshaller.marshal(optionalParameters, soapHeader.getResult());
				} catch (JAXBException  e) {
					throw new TransformerException("Error while marshalling");
				}
			}
		});
		LOG.trace("EngineerGetCandidatesTasksClickClient::callEngineerGetCandidatesTasks::end");	
		return response;
	}



	private EngineerGetCandidatesTasks constructRequest(String techId, String district, List<String> workingDistricts) throws Exception {
		EngineerGetCandidatesTasks request = new EngineerGetCandidatesTasks();
		EngineerReference engineer = new EngineerReference();
		engineer.setID(techId);
		DistrictReference districtRef = new DistrictReference();
		districtRef.setName(district);
		engineer.setDistrict(districtRef);
		request.setEngineer(engineer);
		
		ArrayOfAdditionalLoadingCriteria additionalCriteria = new ArrayOfAdditionalLoadingCriteria();
		AdditionalLoadingCriteria workingDistrictsCriteria = new AdditionalLoadingCriteria();
		workingDistrictsCriteria.setType("Property");
		workingDistrictsCriteria.setName("District");
		for(String workingDistrict : workingDistricts)
			workingDistrictsCriteria.getValue().add(workingDistrict);
		additionalCriteria.getAdditionalLoadingCriteria().add(workingDistrictsCriteria);
		AdditionalLoadingCriteria manualScheduleCriteria = new AdditionalLoadingCriteria();
		manualScheduleCriteria.setType("Property");
		manualScheduleCriteria.setName("CTLManualSchedule");
		manualScheduleCriteria.getValue().add("false");
		additionalCriteria.getAdditionalLoadingCriteria().add(manualScheduleCriteria );
		AdditionalLoadingCriteria dispatchReadyCriteria = new AdditionalLoadingCriteria();
		dispatchReadyCriteria.setType("Property");
		dispatchReadyCriteria.setName("CTLDispatchReady");
		dispatchReadyCriteria.getValue().add("true");
		additionalCriteria.getAdditionalLoadingCriteria().add(dispatchReadyCriteria );
		AdditionalLoadingCriteria onHoldCriteria = new AdditionalLoadingCriteria();
		onHoldCriteria.setType("Property");
		onHoldCriteria.setName("CTLOnHold");
		onHoldCriteria.getValue().add("false");
		additionalCriteria.getAdditionalLoadingCriteria().add(onHoldCriteria );
		AdditionalLoadingCriteria statusCriteria = new AdditionalLoadingCriteria();
		statusCriteria.setType("Property");
		statusCriteria.setName("Status");
		statusCriteria.getValue().add("Unscheduled");
		statusCriteria.getValue().add("Allocated");
		additionalCriteria.getAdditionalLoadingCriteria().add(statusCriteria );
		AdditionalLoadingCriteria dateCriteria = new AdditionalLoadingCriteria();
		dateCriteria.setType("Property");
		dateCriteria.setName("DueDate");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		LocalDate today = LocalDate.now();
		LocalDate startDate = today.plusDays(configuration.getStartDateOffset());
		LocalDate endDate = today.plusDays(configuration.getEndDateOffset());
		dateCriteria.getValue().add(formatter.format(Date.valueOf(startDate))+ "T00:00:00");
		dateCriteria.getValue().add(formatter.format(Date.valueOf(endDate))+ "T00:00:00");
		additionalCriteria.getAdditionalLoadingCriteria().add(dateCriteria );
		request.setAdditionalLoadingCriterias(additionalCriteria );
		request.setMaxNumReturnedTasks(configuration.getNumberOfAvailableTasksRequested());
		return request;
	}
}
