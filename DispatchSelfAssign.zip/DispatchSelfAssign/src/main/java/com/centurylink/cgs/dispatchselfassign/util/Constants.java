package com.centurylink.cgs.dispatchselfassign.util;

public class Constants {
	
	public static final String APPLICATION_SERVICE_NAME = "DispatchSelfAssign";
	public static final String CALLER_IDENTY = "DGWAPP";
	public static final String DISPATCH_SELF_ASSIGN_OPTIONS = "DISPATCH_SELF_ASSIGN_OPTIONS";
	public static final String DISPATCH_SELF_ASSIGN_USERS = "DISPATCH_SELF_ASSIGN_USERS";
	public static final String DISPATCH_SELF_ASSIGN_DISTRICTS = "DISPATCH_SELF_ASSIGN_DISTRICTS";
	public static final String DISPATCH_SELF_ASSIGN_SORT = "DISPATCH_SELF_ASSIGN_SORT";
	public static final String DISPATCH_SELF_ASSIGN_CRITERIA = "DISPATCH_SELF_ASSIGN_CRITERIA";
	public static final String CORRELATION_ID = "correlationId";
	
}
