package com.centurylink.cgs.dispatchselfassign.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse.responseStatusValues;
import com.centurylink.cgs.dispatchselfassign.dao.JobsDao;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.model.AvailableJob;
import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;
import com.centurylink.cgs.dispatchselfassign.model.ReasonCodes;

@Service
public class RescheduledJobsServiceImpl implements RescheduledJobsService {

	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(RescheduledJobsServiceImpl.class);

	@Autowired 
	private JobsDao jobsDao;
		
	
	public DispatchSelfAssignResponse engineerGetRescheduledTasks(String techId) throws Exception   {
		LOG.trace("RescheduledJobsServiceImpl::engineerGetRescheduledTasks::start");
		LogContext requestContext = new LogContext().add("techId",techId);
		LOG.info(new LogContext().setMessage("Request").add(requestContext));
		DispatchSelfAssignResponse dispatchSelfAssignResponse = new DispatchSelfAssignResponse();
		BaseResponse baseResponse = new BaseResponse();
		dispatchSelfAssignResponse.setBaseResponse(baseResponse);
		List<AvailableJob> jobsList = null;
		
		dispatchSelfAssignResponse.setTechnicianId(techId);
		
		if (techId != null)
			jobsList = jobsDao.getRescheduledJobsSummaryByTechId(techId);  
		dispatchSelfAssignResponse.setListJobSummary(jobsList);
		
		if (jobsList != null && jobsList.size() > 0) {
			baseResponse.setMessage("Found: "+ jobsList.size()+ " rescheduled jobs for technician ID: "+techId);
			baseResponse.setResponseStatus(responseStatusValues.Success);
			baseResponse.setReasonCode(ReasonCodes.SUCCESS);
		} else {
			baseResponse.setMessage("No rescheduled jobs found for technician ID: "+techId);
			baseResponse.setResponseStatus(responseStatusValues.Informational);
			baseResponse.setReasonCode(1001);		
		}
		LOG.trace("RescheduledJobsServiceImpl::engineerGetRescheduledTasks::end");
		LOG.info(new LogContext().setMessage("Response")
									.add(requestContext)
									.add("responseStatus",baseResponse.getResponseStatus())
									.add("reasonCode",baseResponse.getReasonCode())
									.add("message",baseResponse.getMessage())
									.add("Number of jobs returned", dispatchSelfAssignResponse.getListJobSummary() != null ? dispatchSelfAssignResponse.getListJobSummary().size() : 0));	
		return dispatchSelfAssignResponse;
	}
}
