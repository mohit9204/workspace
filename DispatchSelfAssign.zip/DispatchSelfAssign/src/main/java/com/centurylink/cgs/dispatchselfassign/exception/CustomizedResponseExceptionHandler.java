package com.centurylink.cgs.dispatchselfassign.exception;

import java.io.IOException;
import java.net.ConnectException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.text.ParseException;

import javax.sql.DataSource;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.http.client.ClientProtocolException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.WebServiceTransportException;
import org.springframework.ws.soap.client.SoapFaultClientException;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchlog.DispatchLog;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.model.ReasonCodes;
import com.centurylink.cgs.dispatchselfassign.model.RequestContext;
import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;
import com.centurylink.cgs.dispatchselfassign.util.Constants;
import com.centurylink.cgs.dispatchselfassign.util.Util;

@ControllerAdvice(basePackages = {"com.centurylink.cgs.dispatchselfassign"} )
@RestController
public class CustomizedResponseExceptionHandler extends ResponseEntityExceptionHandler{

	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(CustomizedResponseExceptionHandler.class);
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected DataSource dataSource; 
	
	@Autowired
	private RequestContext requestContext;

	
	private ResponseEntity<DispatchSelfAssignResponse> createResponseEntityAndStoreException(String message, 
			BaseResponse.responseStatusValues responseStatus, HttpStatus httpStatus, Exception ex, int alarmId) {
		DispatchSelfAssignResponse response = new DispatchSelfAssignResponse();
		BaseResponse baseResponse = new BaseResponse();
		response.setBaseResponse(baseResponse);
		baseResponse.setReasonCode(alarmId);
		baseResponse.setMessage(message);
		baseResponse.setResponseStatus(responseStatus);;

		DispatchSelfAssignException exception = new DispatchSelfAssignException(message, ex, alarmId,	new LogContext().setMessage(message));
		LOG.error(exception);
		saveToDispatchLog(exception, message, alarmId);
		return new ResponseEntity<>(response, httpStatus);
	}
	private ResponseEntity<DispatchSelfAssignResponse> createResponseEntityAndStoreException(int reasonCode, String message, 
			BaseResponse.responseStatusValues responseStatus, HttpStatus httpStatus, DispatchSelfAssignException exception) {
		DispatchSelfAssignResponse response = new DispatchSelfAssignResponse();
		BaseResponse baseResponse = new BaseResponse();
		response.setBaseResponse(baseResponse);
		baseResponse.setReasonCode(reasonCode);
		baseResponse.setMessage(message);
		baseResponse.setResponseStatus(responseStatus);;
		LOG.error(exception);
		saveToDispatchLog(exception, message, exception.getAlarmId());
		return new ResponseEntity<>(response, httpStatus);
	}
	@ExceptionHandler(DispatchSelfAssignException.class)
	public final ResponseEntity<DispatchSelfAssignResponse>  handleSelfAssignException(DispatchSelfAssignException ex) {
		
 		return createResponseEntityAndStoreException(ex.getAlarmId(), ex.getMessage(), BaseResponse.responseStatusValues.Failure,
 				HttpStatus.INTERNAL_SERVER_ERROR, ex);
 
	}
	
	@ExceptionHandler(SoapFaultClientException.class)
	public final ResponseEntity<DispatchSelfAssignResponse>  handleSoapFaultException(SoapFaultClientException ex) {
		
		String message = ex.getSoapFault().getFaultCode().getLocalPart() + " - " + ex.getSoapFault().getFaultStringOrReason();
 		return createResponseEntityAndStoreException(message, BaseResponse.responseStatusValues.Failure,
 				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_SOAP_FAULT_EXCEPTION);
 
	}

	@ExceptionHandler(WebServiceClientException.class)
	public final ResponseEntity<DispatchSelfAssignResponse>  handleClickException(WebServiceClientException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_CLICK_EXCEPTION);
	}

	@ExceptionHandler(WebServiceTransportException.class)
	public final ResponseEntity<DispatchSelfAssignResponse>  handleClickTransportException(WebServiceTransportException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_CLICK_TRANSPORT_EXCEPTION);
	}

	@ExceptionHandler(ConnectException.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleClickConnectException(ConnectException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_CLICK_CONNECT_EXCEPTION);
	}

	@ExceptionHandler(DatatypeConfigurationException.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleDatatypeConfigurationException(DatatypeConfigurationException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure,
				 HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_DATATYPE_CONFIGURATION_EXCEPTION);
	}

	@ExceptionHandler(IOException.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleIOException(IOException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_IOEXCEPTION);
	}

	@ExceptionHandler(TransformerException.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleTransformerException(TransformerException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_TRANSFORMER_EXCEPTION);
	}
	
	@ExceptionHandler(SQLException.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleSQLException(SQLException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_SQLEXCEPTION);
	}
	
	@ExceptionHandler(DataAccessException.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleDataAccessException(DataAccessException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_DATA_ACCESS_EXCEPTION);
	}
	
	@ExceptionHandler(CannotGetJdbcConnectionException.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleCannotGetJdbcConnectionException(CannotGetJdbcConnectionException ex) {
		
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_CANNOT_GET_JDBC_CONNECTION_EXCEPTION);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<DispatchSelfAssignResponse> handleAllExceptions(Exception ex)  {

		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_ALL_EXCEPTIONS);
	}
	
	@ExceptionHandler(URISyntaxException.class)
	public final ResponseEntity<DispatchSelfAssignResponse>  handleURISyntaxException(URISyntaxException ex) {
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_URISYNTAX_EXCEPTION);
 
	}
	@ExceptionHandler(ClientProtocolException.class)
	public final ResponseEntity<DispatchSelfAssignResponse>  handleClientProtocolException(ClientProtocolException ex) {
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_CLIENT_PROTOCOL_EXCEPTION);
 
	}
	@ExceptionHandler(ParseException.class)
	public final ResponseEntity<DispatchSelfAssignResponse>  handleParseException(ParseException ex) {
		return createResponseEntityAndStoreException(ex.getMessage(), BaseResponse.responseStatusValues.Failure, 
				HttpStatus.INTERNAL_SERVER_ERROR, ex, AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_HANDLE_PARSE_EXCEPTION);
 
	}
	
	//saving exceptions details to DispatchLog table
	private void saveToDispatchLog(DispatchSelfAssignException exception, String alarmMessage, int errorNumber){
		
		DispatchLog log = new DispatchLog();
		log.setServiceName(Constants.APPLICATION_SERVICE_NAME);
		String requestId = this.requestContext.getTechId();
		if (requestId != null) {
			log.setCallId(requestId.substring(0, Math.min(requestId.length(), 64)));
		}
		if (exception != null) {
			log.setAlarmId(exception.getAlarmId());
			log.setAlarmMessage(alarmMessage);
			if (exception.getContext() != null){
				log.setAlarmContext(exception.getContext().toString());
			}
			log.setErrorMessage(exception.getMessage());
			log.setStackTrace(Util.getStackTraceString(exception));
		}
		log.setErrorNumber(errorNumber);
		if (exception.getContext() != null && exception.getContext().getValue("correlationId") != null)
			log.setCorrelationId(exception.getContext().getValue(Constants.CORRELATION_ID));
		try {
			log.save(dataSource);
			LOG.info("Saved exception details to dispatch log");
		} catch (Exception e) {
			LogContext context = new LogContext().add("DispatchLog",log);
			DispatchSelfAssignException dtex = new DispatchSelfAssignException("Unable to save to dispatch log", e,
					AlarmId.CUSTOMIZED_RESPONSE_EXCEPTION_HANDLER_SAVE_TO_DISPATCH_LOG, context);
			LOG.error(dtex);
		}
	}
}
