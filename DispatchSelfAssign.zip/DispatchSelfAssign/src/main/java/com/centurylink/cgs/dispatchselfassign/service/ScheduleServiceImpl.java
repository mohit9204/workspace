package com.centurylink.cgs.dispatchselfassign.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.dispatchselfassign.util.Configuration;

@Service
public class ScheduleServiceImpl implements ScheduleService {

	@Scheduled(fixedRate = 3600000) // 1 hour 
	@Override
	public void refreshConfiguration() {
		 Configuration.refresh();
	}

}
