package com.centurylink.cgs.dispatchselfassign.service;

import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;

public interface RescheduledJobsService {

	public DispatchSelfAssignResponse engineerGetRescheduledTasks(String techId) throws Exception;

}
