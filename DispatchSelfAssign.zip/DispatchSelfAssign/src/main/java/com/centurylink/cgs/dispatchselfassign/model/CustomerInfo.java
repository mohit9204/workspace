package com.centurylink.cgs.dispatchselfassign.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Customer info ")
@JsonInclude(Include.NON_EMPTY)
public class CustomerInfo {
	private String customerName;
	private String PrimaryContactNumber;
	private String CircuitId;
		
	/**
	 * @return the customerName
	 */
	@ApiModelProperty(value="Customer full name", dataType="string")
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the primaryContactNumber
	 */
	@ApiModelProperty(value="Primary contact phone number", dataType="string")
	public String getPrimaryContactNumber() {
		return PrimaryContactNumber;
	}
	/**
	 * @param primaryContactNumber the primaryContactNumber to set
	 */
	public void setPrimaryContactNumber(String primaryContactNumber) {
		PrimaryContactNumber = primaryContactNumber;
	}
	/**
	 * @return the circuitId
	 */
	@ApiModelProperty(value="TN/Circuit ID", dataType="string")
	public String getCircuitId() {
		return CircuitId;
	}
	/**
	 * @param circuitId the circuitId to set
	 */
	public void setCircuitId(String circuitId) {
		CircuitId = circuitId;
	}
	
}
