package com.centurylink.cgs.dispatchselfassign.model;

public class StateTimeZone {
	String state;
	String timeZone;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

}
