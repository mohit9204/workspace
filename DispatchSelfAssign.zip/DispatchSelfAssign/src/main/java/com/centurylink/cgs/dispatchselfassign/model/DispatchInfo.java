package com.centurylink.cgs.dispatchselfassign.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Dispatch info ")
@JsonInclude(Include.NON_EMPTY)

public class DispatchInfo {
	private String dispatchType;
	private Long duration;
	private Long dispatchCorrelationId;
	
	@ApiModelProperty(value="Dispatch type", dataType="String")
	public String getDispatchType() {
		return dispatchType;
	}

	public void setDispatchType(String dispatchType) {
		this.dispatchType = dispatchType;
	}
	@ApiModelProperty(value="Duration", dataType="Long")
	public Long getDuration() {
		return duration;
	}
	
	public void setDuration(Long long1) {
		this.duration = long1;
	}
	@ApiModelProperty(value="Correlation id", dataType="Long")
	public Long getDispatchCorrelationId() {
		return dispatchCorrelationId;
	}

	public void setDispatchCorrelationId(Long dispatchCorrelationId) {
		this.dispatchCorrelationId = dispatchCorrelationId;
	}
}
