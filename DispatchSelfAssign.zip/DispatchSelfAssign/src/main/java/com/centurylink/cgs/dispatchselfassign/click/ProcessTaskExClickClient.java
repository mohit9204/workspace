package com.centurylink.cgs.dispatchselfassign.click;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.TransformerException;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.util.Constants;
import com.clicksoftware.Assignment;
import com.clicksoftware.Assignment.Engineers;
import com.clicksoftware.DistrictReference;
import com.clicksoftware.EngineerReference;
import com.clicksoftware.ProcessTaskEx;
import com.clicksoftware.ProcessTaskExResponse;
import com.clicksoftware.Task;
import com.clicksoftware.serviceoptimizeservice.OptionalParameters;

public class ProcessTaskExClickClient extends WebServiceGatewaySupport {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(ProcessTaskExClickClient.class);
	
	@Value("${click.date.format}")
	private String clickDateFormat;

	@Value("${click.scheduleservice.soap.action}")
	private String clickSoapAction;
	
	public ProcessTaskExResponse allocateTask(String techId, String district, String callId, XMLGregorianCalendar start, XMLGregorianCalendar finish, XMLGregorianCalendar assignTime) throws DatatypeConfigurationException {
		
		ProcessTaskEx request = constructRequest(techId, district, callId, start, finish, assignTime);
		WebServiceTemplate wsTemplate = getWebServiceTemplate();		

        LOG.info("Allocate Request to click: "+"techId: "+techId+", district: "+district+", correlationId: "+callId+"' start: "+start+", finish: "+ finish+", selfAssignTime: "+ assignTime);

		ProcessTaskExResponse response = (ProcessTaskExResponse) wsTemplate.marshalSendAndReceive(request, 
				new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(WebServiceMessage requestMessage) throws IOException, TransformerException {
				try {
					SoapMessage soapMsg = ((SoapMessage) requestMessage);
					// get the header from the SOAP message		
					SoapHeader soapHeader = soapMsg.getSoapHeader();
					soapMsg.setSoapAction(clickSoapAction);					
					// create the header element
					OptionalParameters optionalParameters = new OptionalParameters();
					optionalParameters.setCallerIdentity(Constants.CALLER_IDENTY); 
					optionalParameters.setErrorOnNonExistingDictionaries(true);
					// create a marshaller
					JAXBContext context = JAXBContext.newInstance(OptionalParameters.class);
					Marshaller marshaller = context.createMarshaller();
					// marshal the headers into the specified result
					marshaller.marshal(optionalParameters, soapHeader.getResult());
				} catch (JAXBException  e) {
					throw new TransformerException("Error while marshalling");
				}
			}
		});
		LOG.trace("ProcessTaskExClickClient::allocateTask::end");	
		return response;
	}

	private ProcessTaskEx constructRequest(String techId, String district, String callId, XMLGregorianCalendar start, XMLGregorianCalendar finish, XMLGregorianCalendar selfAssignTime) {
		ProcessTaskEx request = new ProcessTaskEx();
		Task task = new Task();
		request.setTask(task);
		task.setExternalRefID(callId);
		task.setNumber(1);
		task.setCTLSelfAssignedTime(selfAssignTime);
		task.setCTLSelfAssignedFlag(true);
		Assignment assignment = new Assignment();
		request.setAssignment(assignment);
		assignment.setStart(start);
		assignment.setFinish(finish);
		Engineers engineers = new Engineers();
		assignment.setEngineers(engineers);
		EngineerReference engineer = new EngineerReference();
		engineers.getEngineer().add(engineer);
		engineer.setID(techId);
		DistrictReference districtReference = new DistrictReference();
		engineer.setDistrict(districtReference);
		districtReference.setName(district);
		request.setReturnAssignment(true);
		request.setReturnSchedulingError(true);
		return request;
	}
}
