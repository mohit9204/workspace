package com.centurylink.cgs.dispatchselfassign.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "location")
@JsonInclude(Include.NON_EMPTY)
public class Location {
	private String city;
	private String state;
	private String addressLine1;
	private String addressLine2;
	

	@ApiModelProperty(value="City name for job", dataType="string")
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@ApiModelProperty(value="State info", dataType="string")
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}


	@ApiModelProperty(value="Address line1 info", dataType="string")
	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	@ApiModelProperty(value="Address line2 info", dataType="string")
	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}


}

