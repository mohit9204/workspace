package com.centurylink.cgs.dispatchselfassign.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse.responseStatusValues;
import com.centurylink.cgs.dispatchselfassign.click.EngineerGetCandidatesTasksClickClient;
import com.centurylink.cgs.dispatchselfassign.click.GetEngineersCrewAllocationsClickClient;
import com.centurylink.cgs.dispatchselfassign.dao.JobsDao;
import com.centurylink.cgs.dispatchselfassign.dao.ServicePlannerDao;
import com.centurylink.cgs.dispatchselfassign.exception.AlarmId;
import com.centurylink.cgs.dispatchselfassign.exception.DispatchSelfAssignException;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.model.Appointment;
import com.centurylink.cgs.dispatchselfassign.model.AvailableJob;
import com.centurylink.cgs.dispatchselfassign.model.DispatchInfo;
import com.centurylink.cgs.dispatchselfassign.model.Location;
import com.centurylink.cgs.dispatchselfassign.model.ReasonCodes;
import com.centurylink.cgs.dispatchselfassign.model.StateTimeZone;
import com.centurylink.cgs.dispatchselfassign.util.Configuration;
import com.centurylink.cgs.dispatchselfassign.util.TimeZoneMapper;
import com.centurylink.cgs.dispatchselfassign.util.Util;
import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;
import com.clicksoftware.CrewAllocation;
import com.clicksoftware.GetEngineersCrewAllocationsResponse;
import com.clicksoftware.serviceoptimizeservice.EngineerGetCandidatesTasksResponse;
import com.clicksoftware.serviceoptimizeservice.Task;
import com.clicksoftware.serviceoptimizeservice.TaskExt;

@Service
public class AvailableJobsServiceImpl implements AvailableJobsService {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(AvailableJobsServiceImpl.class);

	@Autowired
	private EngineerGetCandidatesTasksClickClient engineerGetCandidatesTasksClickClient;
	
	@Autowired
	private GetEngineersCrewAllocationsClickClient getEngineersCrewAllocationsClickClient;
	
	@Autowired 
	private JobsDao jobsDao;
	
	@Autowired 
	private ServicePlannerDao servicePlannerDao;
	
	@Autowired
	private Configuration configuration;
	
	@Autowired
	private Util util;
	
	public DispatchSelfAssignResponse engineerGetCandidatesTasks(String techId, String district) throws Exception   {
		LOG.trace("AvailableJobsServiceImpl::engineerGetCandidatesTasks::start");
		LogContext requestContext = new LogContext().add("techId",techId).add("district",district);
		LOG.info(new LogContext().setMessage("Request").add(requestContext));
		DispatchSelfAssignResponse dispatchSelfAssignResponse = new DispatchSelfAssignResponse();
		BaseResponse baseResponse = new BaseResponse();
		dispatchSelfAssignResponse.setBaseResponse(baseResponse);
		List<AvailableJob> jobsList = null;
		boolean authorized = !configuration.isEnforceUserList() || configuration.getAuthorizedUsers().containsKey(techId.toUpperCase()) || configuration.getAuthorizedDistricts().containsKey(district.toUpperCase()); 
		if (authorized) {
			String reassignedDistrict = null;
			try {
				reassignedDistrict = getReassignedDistrict(techId, district);
			} catch (Exception e) {
				LogContext context = new LogContext().add("techId",techId).add("district",district);
				DispatchSelfAssignException exception = new DispatchSelfAssignException(e.getMessage(), e, AlarmId.AVAILABLE_JOBS_SERVICE_IMPL_ENGINEER_GET_CANDIDATES_TASKS, context);
				LOG.error(exception);
				util.saveDispatchLog(exception);
			}
			if (reassignedDistrict != null) {
				LOG.info(new LogContext().setMessage("Technician is reassigned").add(requestContext).add("reassignedDistrict",reassignedDistrict));
				requestContext.add("reassignedDistrict",reassignedDistrict);
				district = reassignedDistrict;
			}
			List<String> workingDistricts = jobsDao.getWorkingDistricts(techId);
			EngineerGetCandidatesTasksResponse response = engineerGetCandidatesTasksClickClient.callEngineerGetCandidatesTasks(techId, district, workingDistricts);
			//Removing redundant code
		//	ArrayList<AvailableJob> availableJobs = new ArrayList<AvailableJob>();
			dispatchSelfAssignResponse.setTechnicianId(techId);
		//	dispatchSelfAssignResponse.setListJobSummary(availableJobs);
			List<String> correlationIdList = new ArrayList<String>();
			for (TaskExt taskExt : response.getEngineerGetCandidatesTasksResult().getTask()) {
			/*	AvailableJob job = new AvailableJob();
				Appointment appointment = new Appointment();
				job.setAppointment(appointment);
				Location location = new Location();
				job.setLocation(location);*/
				Task task = (Task)taskExt.getTaskProperties();
				/*DispatchInfo dispatchInfo = new DispatchInfo();
				job.setDispatchInfo(dispatchInfo);
				dispatchInfo.setDispatchCorrelationId(Long.parseLong(task.getCallID()));
				dispatchInfo.setDuration(task.getDuration().longValue());
				job.setPriority(task.getPriority().longValue());
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				appointment.setAccessAfterDateTime(formatter.format(task.getEarlyStart().toGregorianCalendar().getTime()).replace(' ', 'T'));
				appointment.setAccessBeforeDateTime(formatter.format(task.getLateStart().toGregorianCalendar().getTime()).replace(' ', 'T'));
				appointment.setAppointmentStartDateTime(formatter.format(task.getAppointmentStart().toGregorianCalendar().getTime()).replace(' ', 'T'));
				appointment.setAppointmentEndDateTime(formatter.format(task.getAppointmentFinish().toGregorianCalendar().getTime()).replace(' ', 'T'));
				appointment.setDueDate(formatter.format(task.getDueDate().toGregorianCalendar().getTime()).replace(' ', 'T'));
				
				location.setAddressLine1(task.getStreet());
				location.setAddressLine2(task.getAddress2());
				location.setCity(task.getCity());
				location.setState(task.getState());
				availableJobs.add(job);*/
				correlationIdList.add(task.getCallID());
			}
			LOG.info(new LogContext().setMessage("Tasks from Click").add(requestContext).add("correlationIdList",correlationIdList.toString()));
			if (correlationIdList.size() > 0)
				jobsList = jobsDao.getJobsSummaryByCorrelationIdList(correlationIdList, techId, configuration.getNumberOfAvailableTasksReturned());  
			dispatchSelfAssignResponse.setListJobSummary(jobsList);
		}
		if (!authorized) {
			baseResponse.setMessage("Unauthorized tech and district");
			baseResponse.setResponseStatus(responseStatusValues.Warning);
			baseResponse.setReasonCode(ReasonCodes.UNAUTHORIZED);
		}
		else if (jobsList != null && jobsList.size() > 0) {
			baseResponse.setMessage("Found available jobs for technician ID: "+techId);
			baseResponse.setResponseStatus(responseStatusValues.Success);
			baseResponse.setReasonCode(ReasonCodes.SUCCESS);
		} else {
			baseResponse.setMessage("No available jobs found for technician ID: "+techId);
			baseResponse.setResponseStatus(responseStatusValues.Informational);
			baseResponse.setReasonCode(1001);		
		}
		LOG.trace("AvailableJobsServiceImpl::engineerGetCandidatesTasks::end");
		LOG.info(new LogContext().setMessage("Response")
									.add(requestContext)
									.add("responseStatus",baseResponse.getResponseStatus())
									.add("reasonCode",baseResponse.getReasonCode())
									.add("message",baseResponse.getMessage())
									.add("Number of jobs returned", dispatchSelfAssignResponse.getListJobSummary() != null ? dispatchSelfAssignResponse.getListJobSummary().size() : 0));	
		return dispatchSelfAssignResponse;
	}

	private String getReassignedDistrict(String techId, String district) throws DatatypeConfigurationException {

		XMLGregorianCalendar start = DatatypeFactory.newInstance().newXMLGregorianCalendar(Util.getYesterday());
		XMLGregorianCalendar finish = DatatypeFactory.newInstance().newXMLGregorianCalendar(Util.getTomorrow());
		GetEngineersCrewAllocationsResponse allocations = getEngineersCrewAllocationsClickClient.getCrewAllocations(techId, district, start, finish);
		if (allocations.getCrewAllocations() != null 
				&& allocations.getCrewAllocations().getCrewAllocation() != null 
				&& allocations.getCrewAllocations().getCrewAllocation().size() > 0) {
			
			for (CrewAllocation allocation : allocations.getCrewAllocations().getCrewAllocation()) {
				String timeZone = null;
				if (allocation.getCrew() == null
						|| allocation.getCrew().getDistrict() == null
						|| allocation.getStartTime() == null
						|| allocation.getFinishTime() == null) 
					continue;
				try {
					StateTimeZone tz = servicePlannerDao.getTimeZone(allocation.getCrew().getDistrict().getDisplayString());		
					timeZone = TimeZoneMapper.map.get(tz.getState());  // Check for AZ
					if (timeZone == null)
						timeZone = TimeZoneMapper.map.get(tz.getTimeZone());
				} catch (DispatchSelfAssignException e) {
					LOG.error(e);
					timeZone = "UTC";
				}
				GregorianCalendar now = new GregorianCalendar();
				GregorianCalendar convertedStart = Util.convert(allocation.getStartTime().toGregorianCalendar(), timeZone);
				GregorianCalendar convertedFinish = Util.convert(allocation.getFinishTime().toGregorianCalendar(), timeZone);
				LOG.info(new LogContext().add("techId",techId)
										.add("district",district)
										.add("now",now.getTime().toString())
										.add("convertedStart",convertedStart.getTime().toString())
										.add("convertedFinish",convertedFinish.getTime().toString())
										.add("timeZone",timeZone));
				if( Util.isInbetween(now, convertedStart, convertedFinish)) {
					return allocation.getCrew().getDistrict().getDisplayString();
				}
			}
		}
		return null;
	}
}
