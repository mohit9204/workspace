package com.centurylink.cgs.dispatchselfassign.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;

@Component
public class DispatchSelfAssignResponse {
	
	private BaseResponse baseResponse;
	private String technicianId;
	private List<AvailableJob> listJobSummary;
	
	public String getTechnicianId() {
		return technicianId;
	}
	public void setTechnicianId(String technicianId) {
		this.technicianId = technicianId;
	}
	public BaseResponse getBaseResponse() {
		return baseResponse;
	}
	public void setBaseResponse(BaseResponse baseResponse) {
		this.baseResponse = baseResponse;
	}
	public List<AvailableJob> getListJobSummary() {
		return listJobSummary;
	}
	public void setListJobSummary(List<AvailableJob> jobsList) {
		this.listJobSummary = jobsList;
	}
	@Override
	public String toString() {
		LogContext context = new LogContext();
		if (baseResponse != null)
			context.add("message",baseResponse.getMessage());
		if (listJobSummary != null)
			context.add("listJobSummary.size()",listJobSummary.size());
		return context.toString();
	}
}
