package com.centurylink.cgs.dispatchselfassign.service;

import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;

public interface AvailableJobsService {
	
	public DispatchSelfAssignResponse engineerGetCandidatesTasks(String techId, String district) throws Exception;

}
