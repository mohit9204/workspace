package com.centurylink.cgs.dispatchselfassign.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchlog.DispatchLog;
import com.centurylink.cgs.dispatchselfassign.exception.AlarmId;
import com.centurylink.cgs.dispatchselfassign.exception.DispatchSelfAssignException;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;

public class Util {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(Util.class);
	
	@Autowired 
	@Qualifier("jobsDataSource") 
	protected  DataSource dataSource; 
	
	public static String getStackTraceString(Exception e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}
	public static boolean isInbetween(GregorianCalendar theDate, GregorianCalendar beginDate, GregorianCalendar endDate) {
		if (theDate != null 
			&& beginDate != null
			&& endDate != null
			&& theDate.compareTo(beginDate) >= 0 
			&& theDate.compareTo(endDate) < 0) {
			return true;
		} else {
			return false;
		}
			
	}

	public static GregorianCalendar convert(GregorianCalendar cal, String timeZone) {
		GregorianCalendar newCal = new GregorianCalendar();
		TimeZone tz = TimeZone.getTimeZone(timeZone);
		newCal.setTimeZone(TimeZone.getTimeZone(timeZone));
		newCal.set(Calendar.YEAR, cal.get(Calendar.YEAR));
		newCal.set(Calendar.MONTH, cal.get(Calendar.MONTH));
		newCal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH));
		newCal.set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR_OF_DAY));
		newCal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE));
		newCal.set(Calendar.SECOND, cal.get(Calendar.SECOND));
		return newCal;

	}
	public static GregorianCalendar getYesterday() {
		GregorianCalendar yesterday = new GregorianCalendar();
		yesterday.set(Calendar.HOUR_OF_DAY, -1);
		yesterday.set(Calendar.MINUTE, 0);
		yesterday.set(Calendar.SECOND, 0);
		return yesterday;
	}
	public static GregorianCalendar getTomorrow() {
		GregorianCalendar tomorrow = new GregorianCalendar();
		tomorrow.add(Calendar.DAY_OF_YEAR, 1);
		tomorrow.set(Calendar.HOUR_OF_DAY, 0);
		tomorrow.set(Calendar.MINUTE, 0);
		tomorrow.set(Calendar.SECOND, 0);
		return tomorrow;
	}
	public void saveDispatchLog(DispatchSelfAssignException exception) {
		DispatchLog log = new DispatchLog();
		log.setServiceName(Constants.APPLICATION_SERVICE_NAME);
		if (exception != null) {
			String correlationId = exception.getContext().getValue("correlationId");
			log.setAlarmId(exception.getAlarmId());
			log.setAlarmMessage(exception.getMessage());
			log.setCorrelationId(correlationId+"");
			if (exception.getContext() != null){
				log.setAlarmContext(exception.getContext().toString());
			}
			log.setErrorMessage(exception.getMessage());
			log.setErrorNumber(exception.getAlarmId());
			log.setStackTrace(getStackTraceString(exception));
		}
		log.setErrorNumber(exception.getAlarmId());

		try {
			log.save(dataSource);
		} catch (Exception e) {
			LogContext context = new LogContext().add("exception",exception);
			DispatchSelfAssignException dtex = new DispatchSelfAssignException("Unable to save to dispatch log", e,
					AlarmId.UTIL_SAVE_DISPATCH_LOG, context);
			LOG.error(dtex);
		}
	}
}
