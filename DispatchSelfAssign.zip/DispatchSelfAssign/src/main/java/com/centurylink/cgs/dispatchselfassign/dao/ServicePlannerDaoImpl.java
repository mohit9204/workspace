package com.centurylink.cgs.dispatchselfassign.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchselfassign.dao.sql.SQLQueries;
import com.centurylink.cgs.dispatchselfassign.exception.AlarmId;
import com.centurylink.cgs.dispatchselfassign.exception.DispatchSelfAssignException;
import com.centurylink.cgs.dispatchselfassign.model.StateTimeZone;

public class ServicePlannerDaoImpl extends NamedParameterJdbcDaoSupport implements ServicePlannerDao{
	
	@Autowired 
	@Qualifier("spDataSource") 
	protected DataSource dataSource; 

	@PostConstruct
	private void initialize() {
		setDataSource(dataSource);
	}

	@Override
	public StateTimeZone getTimeZone(String district) throws DispatchSelfAssignException {
		LogContext logContext = new LogContext();
		try {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("serviceArea", district);
			logContext.add("district", district);
			List<StateTimeZone> timeZones = this.getNamedParameterJdbcTemplate().query(
					SQLQueries.SQL_GET_TIME_ZONE, paramMap, new TimeZoneRecordMapper());
			if (timeZones != null && timeZones.size() > 0)
				return timeZones.get(0);

		} catch (Exception ex) {
			DispatchSelfAssignException e = new DispatchSelfAssignException(ex.getMessage(), ex, AlarmId.SERVICE_PLANNER_DAO_IMPL_GET_TIME_ZONE,
					logContext);
			throw e;
		}
		return null;
	}

}
