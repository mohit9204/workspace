package com.centurylink.cgs.dispatchselfassign.model;

import javax.xml.bind.annotation.XmlRootElement;

import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(description="Dispatch Status returned for a request by ServiceTN, lat/lon, or CBR #")
@XmlRootElement
@JsonInclude(Include.NON_NULL)
public class DispatchTaskResponse {

	private BaseResponse baseResponse;
	private String correlationId;
	private String dispatcherCallId;
	private ClickResponse clickResponse;
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Override
	public String toString() {
		return this.toJSONString();
	}
	
	public String toJSONString() {
		try {
			mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
			return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
		} catch (JsonProcessingException jpe) {
			return jpe.getMessage();
		}
	}

	@ApiModelProperty("BaseResponse indicating success/failure")
	public BaseResponse getBaseResponse() {
		return baseResponse;
	}
	public void setBaseResponse(BaseResponse baseResponse) {
		this.baseResponse = baseResponse;
	}
	
	@ApiModelProperty(value="Correlation ID for the Dispatch", dataType="string")	
	public String getCorrelationId() {
		return correlationId;
	}
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}	
	
	@ApiModelProperty(value="Call ID for the Dispatch, informational for dispatcher", dataType="string")
	public String getDispatcherCallId() {
		return dispatcherCallId;
	}

	public void setDispatcherCallId(String dispatcherCallId) {
		this.dispatcherCallId = dispatcherCallId;
	}

	@ApiModelProperty("ClickResponse indicating web service call results")
	public ClickResponse getClickResponse() {
		return clickResponse;
	}
	public void setClickResponse(ClickResponse clickResponse) {
		this.clickResponse = clickResponse;
	}
	
}
