package com.centurylink.cgs.dispatchselfassign.client;

import java.net.URISyntaxException;
import java.util.Date;

import com.centurylink.cgs.dispatchcommon.http.HttpHelper;
import com.centurylink.cgs.dispatchselfassign.model.DispatchTaskResponse;
import com.centurylink.cgs.dispatchselfassign.model.TaskStatus;
import com.centurylink.cgs.dispatchselfassign.model.TaskStatusRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DispatchTaskClient {

	private String endpoint;
	public DispatchTaskClient(String endpoint, int readTimeout, int connectTimeout) {
		this.endpoint = endpoint;
	}
	public DispatchTaskResponse assignJob(String callingSystem, String correlationId, Date statusUpdateTimestamp, String selfAssignFlag, Date selfAssignTimestamp) throws Exception, URISyntaxException {
		TaskStatusRequest request = new TaskStatusRequest();
		TaskStatus taskStatus = new TaskStatus();
		request.setTaskStatus(taskStatus);
		request.setCallingSystem(callingSystem);
		taskStatus.setStatusUpdateTimestamp(statusUpdateTimestamp);
		taskStatus.setSelfAssignTimestamp(selfAssignTimestamp);
		taskStatus.setSelfAssignFlag(selfAssignFlag);
		taskStatus.setTaskStatus("Assigned");
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(request);
		String url = String.format("%s/task/%s/status", endpoint, correlationId);
		HttpHelper http = new HttpHelper(url);
		String respon = http.put(json);
		return mapper.readValue(respon, DispatchTaskResponse.class);
	}
}
