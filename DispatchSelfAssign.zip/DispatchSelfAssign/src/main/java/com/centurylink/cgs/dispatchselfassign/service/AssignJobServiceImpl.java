package com.centurylink.cgs.dispatchselfassign.service;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchselfassign.click.ProcessTaskExClickClient;
import com.centurylink.cgs.dispatchselfassign.client.DispatchTaskClient;
import com.centurylink.cgs.dispatchselfassign.dao.JobsDao;
import com.centurylink.cgs.dispatchselfassign.exception.AlarmId;
import com.centurylink.cgs.dispatchselfassign.exception.DispatchSelfAssignException;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;
import com.centurylink.cgs.dispatchselfassign.model.DispatchTaskResponse;
import com.centurylink.cgs.dispatchselfassign.model.ReasonCodes;
import com.centurylink.cgs.dispatchselfassign.util.Configuration;
import com.centurylink.cgs.dispatchselfassign.util.Constants;
import com.clicksoftware.ProcessTaskExResponse;

@Service
public class AssignJobServiceImpl implements AssignJobService {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(AssignJobServiceImpl.class);

	@Autowired
	private ProcessTaskExClickClient processTaskExClickClient;
	
	@Autowired
	private Configuration configuration;
	
	@Autowired 
	private JobsDao jobsDao;
		
	@Override
	public DispatchSelfAssignResponse assignJob(String techId, String district, String correlationId, String callingSystem, Date statusUpdateTimestamp, int duration) throws Exception {
		LOG.trace("SelfAssignServiceImpl::assignJob::start");
		LogContext requestContext = new LogContext().add("techId",techId)
													.add("district",district)
													.add("correlationId",correlationId)
													.add("callingSystem",callingSystem)
													.add("statusUpdateTimestamp",statusUpdateTimestamp.toString())
													.add("duration", duration);

		LOG.info(new LogContext().setMessage("Request").add(requestContext));
		DispatchSelfAssignResponse assignJobResponse = new DispatchSelfAssignResponse();
		BaseResponse baseResponse = new BaseResponse();
		assignJobResponse.setBaseResponse(baseResponse);
		GregorianCalendar gregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
		gregorianCalendar.setTime(statusUpdateTimestamp);
        DatatypeFactory datatypeFactory = DatatypeFactory.newInstance();
        XMLGregorianCalendar now = 
            datatypeFactory.newXMLGregorianCalendar(gregorianCalendar);
		XMLGregorianCalendar start = now;
		gregorianCalendar.add(Calendar.SECOND, duration);
		XMLGregorianCalendar finish = datatypeFactory.newXMLGregorianCalendar(gregorianCalendar);
		Date selfAssignDateTime = statusUpdateTimestamp;
		GregorianCalendar selfAssignCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
		selfAssignCalendar.setTime(selfAssignDateTime);
        DatatypeFactory selfAssignDTFactory = DatatypeFactory.newInstance();
        XMLGregorianCalendar selfAssignTimestamp = 
        		selfAssignDTFactory.newXMLGregorianCalendar(selfAssignCalendar);
		try {
			ProcessTaskExResponse response = processTaskExClickClient.allocateTask(techId, district, correlationId, start, finish, selfAssignTimestamp);
			if(response != null && response.getReturnCode() != null){
				LOG.info(new LogContext().setMessage("Allocate Task Click Response")
						.add("Return Code", response.getReturnCode()));
			}
			if (response != null && response.getSchedulingError() != null && response.getSchedulingError().getError() != null && response.getSchedulingError().getError().getErrorDescription() != null) {
				if (response.getSchedulingError().getError().getErrorDescription().startsWith("It is not allowed to schedule tasks with status")) {
					baseResponse.setResponseStatus(BaseResponse.responseStatusValues.Failure);
					baseResponse.setReasonCode(ReasonCodes.TASK_IS_ALREADY_ASSIGNED);
					baseResponse.setMessage(String.format("Job %s is no longer available for assignment", correlationId));
					return assignJobResponse;
				}
				throw new DispatchSelfAssignException(response.getSchedulingError().getError().getErrorDescription(), 
						AlarmId.ASSIGN_JOB_SERVICE_IMPL_ASSIGN_JOB_ALLOCATE,
						new LogContext().add("techId",techId).add("district",district).add("correlationId",correlationId).add("start",start).add("finish",finish).add("selfAssignTime",selfAssignDateTime));
			}
			DispatchTaskClient taskClient = new DispatchTaskClient(configuration.getTaskEndpointURI(), configuration.getTaskReadTimeout(), configuration.getTaskConnectTimeout());
			String jobsCorrelationId = jobsDao.getJobsCorrelationId(correlationId); // gets parent id for grouped jobs
			String SelfAssignFlag = "Y";
			DispatchTaskResponse taskResponse = taskClient.assignJob(callingSystem, jobsCorrelationId, statusUpdateTimestamp, SelfAssignFlag, selfAssignDateTime);
			if (taskResponse != null && taskResponse.getBaseResponse() != null && taskResponse.getBaseResponse().getResponseStatus() != BaseResponse.responseStatusValues.Success) {
				String message = null;
				if (taskResponse.getClickResponse() != null && taskResponse.getClickResponse() != null)
					message = taskResponse.getClickResponse().getSoapFaultReason();
				else
					message = taskResponse.getBaseResponse().getMessage();
	
				throw new DispatchSelfAssignException(message, 
						AlarmId.ASSIGN_JOB_SERVICE_IMPL_ASSIGN_JOB_ASSIGN,
						new LogContext().add("techId",techId).add("district",district).add(Constants.CORRELATION_ID,correlationId).add("start",start).add("finish",finish));
			}
			jobsDao.deleteRemark(correlationId, configuration.getRemarkType(), configuration.getRemarkToDelete());
			jobsDao.insertRemark(correlationId, configuration.getRemarkType(), String.format(configuration.getRemarkText(),techId));
			jobsDao.updateJobStatus(correlationId, configuration.getJobStatus());
			baseResponse.setResponseStatus(BaseResponse.responseStatusValues.Success);
			baseResponse.setReasonCode(ReasonCodes.SUCCESS);
			baseResponse.setMessage(String.format("Job %s successfully assigned to %s", correlationId, techId));
			LOG.trace("SelfAssignServiceImpl::assignJob::end");
		} finally {
			LOG.info(new LogContext().setMessage("Response")
										.add(requestContext)
										.add("responseStatus",baseResponse.getResponseStatus())
										.add("reasonCode",baseResponse.getReasonCode())
										.add("message",baseResponse.getMessage()));			
		}
		return assignJobResponse;
	}

}
