package com.centurylink.cgs.dispatchselfassign;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.HashMap;

import javax.net.ssl.SSLContext;
import javax.sql.DataSource;
import javax.xml.ws.spi.http.HttpContext;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;
import org.springframework.ws.transport.http.HttpComponentsMessageSender.RemoveSoapHeadersInterceptor;

import com.centurylink.cgs.dispatchcommon.encryption.EncryptedPasswordDataSource;
import com.centurylink.cgs.dispatchcommon.encryption.EncryptionHelper;
import com.centurylink.cgs.dispatchcommon.reference.DispatchReference;
import com.centurylink.cgs.dispatchselfassign.click.ClickInterceptor;
import com.centurylink.cgs.dispatchselfassign.click.EngineerGetCandidatesTasksClickClient;
import com.centurylink.cgs.dispatchselfassign.click.GetEngineersCrewAllocationsClickClient;
import com.centurylink.cgs.dispatchselfassign.click.ProcessTaskExClickClient;
import com.centurylink.cgs.dispatchselfassign.dao.ServicePlannerDao;
import com.centurylink.cgs.dispatchselfassign.dao.ServicePlannerDaoImpl;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.model.ApplicationContext;
import com.centurylink.cgs.dispatchselfassign.service.AvailableJobsService;
import com.centurylink.cgs.dispatchselfassign.service.AvailableJobsServiceImpl;
import com.centurylink.cgs.dispatchselfassign.util.Configuration;
import com.centurylink.cgs.dispatchselfassign.util.Constants;
import com.centurylink.cgs.dispatchselfassign.util.Util;


@SpringBootApplication
@EnableScheduling
@ComponentScan(basePackages = "com.centurylink.cgs.dispatchselfassign")

public class SelfAssignApplication {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(SelfAssignApplication.class);

	@Value("${client.timeout}")
	private int timeout;

	@Value("${client.ssl.trust-store}")
	private Resource trustStore;

	@Value("${client.ssl.trust-store-password}")
	private String trustStorePassword;

	@Value("${jobs.datasource.username}")
	private String jobsUsername;

	@Value("${jobs.datasource.encryptedPassword}")
	private String jobsPassword;

	@Value("${sp.datasource.username}")
	private String spUsername;

	@Value("${sp.datasource.encryptedPassword}")
	private String spPassword;
	@Autowired
	private ApplicationContext applicationContext;
	
	HashMap<String, String> clickEndPointMap = new HashMap<String, String>();

	public static void main(String[] args) {
		LOG.trace("SelfAssignApplication::main::start");
		SpringApplication.run(SelfAssignApplication.class, args);

		LOG.info("  >>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		LOG.info("  >>         Self Assign Service is STARTED        <<");
		LOG.info("  >>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
	}

	@Primary
	@Bean(name = "jobsDataSource")
	@ConfigurationProperties(prefix = "jobs.datasource")
	public DataSource dataSource() {
		EncryptedPasswordDataSource source = new EncryptedPasswordDataSource();
		source.setUsername(jobsUsername);
		source.setEncryptedPassword(jobsPassword);
		return source;
	}

	@Bean(name = "spDataSource")
	@ConfigurationProperties(prefix = "sp.datasource")
	public DataSource spDataSource() {
		EncryptedPasswordDataSource source = new EncryptedPasswordDataSource();
		source.setUsername(spUsername);
		source.setEncryptedPassword(spPassword);
		return source;
	}
	@Bean(name = "jobsJdbc") 
	public JdbcTemplate jdbcTemplate(DataSource jobsDataSource) { 
		return new JdbcTemplate(jobsDataSource); 
	} 

	@Bean
	public Jaxb2Marshaller serviceOptimizationMarshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPaths("com.clicksoftware.serviceoptimizeservice");
		return marshaller;
	}
	@Bean
	public Jaxb2Marshaller clickScheduleMarshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setContextPaths("com.clicksoftware");
		return marshaller;
	}
	@Bean
	public GetEngineersCrewAllocationsClickClient getEngineersCrewAllocationsClickClient(Jaxb2Marshaller clickScheduleMarshaller) throws Exception {
		GetEngineersCrewAllocationsClickClient client = new GetEngineersCrewAllocationsClickClient();	
		client.setMarshaller(clickScheduleMarshaller);
		client.setUnmarshaller(clickScheduleMarshaller);
		client.setMessageSender(httpComponentsMessageSender());	
		client.setDefaultUri(clickEndPointMap.get("clickScheduleServiceGetEngineersCrewAllocationsEndpoint"));
		ClientInterceptor[] interceptors  = client.getInterceptors();
		interceptors =  (ClientInterceptor[]) ArrayUtils.add(interceptors, new ClickInterceptor());
		client.setInterceptors(interceptors);
		return client;
	}
	@Bean
	public EngineerGetCandidatesTasksClickClient clickOptimizationClient(Jaxb2Marshaller serviceOptimizationMarshaller) throws Exception {
		EngineerGetCandidatesTasksClickClient client = new EngineerGetCandidatesTasksClickClient();	
		client.setMarshaller(serviceOptimizationMarshaller);
		client.setUnmarshaller(serviceOptimizationMarshaller);
		client.setMessageSender(httpComponentsMessageSender());	
		client.setDefaultUri(clickEndPointMap.get("clickSOSEndpoint"));//endpoint for DispatchOptimization
		ClientInterceptor[] interceptors  = client.getInterceptors();
		interceptors =  (ClientInterceptor[]) ArrayUtils.add(interceptors, new ClickInterceptor());
		client.setInterceptors(interceptors);
		return client;
	}
	@Bean
	public ProcessTaskExClickClient clickScheduleClient(Jaxb2Marshaller clickScheduleMarshaller) throws Exception {
		ProcessTaskExClickClient client = new ProcessTaskExClickClient();	
		client.setMarshaller(clickScheduleMarshaller);
		client.setUnmarshaller(clickScheduleMarshaller);
		client.setMessageSender(httpComponentsMessageSender());	
		client.setDefaultUri(clickEndPointMap.get("clickScheduleServiceEndpoint"));
		ClientInterceptor[] interceptors  = client.getInterceptors();
		interceptors =  (ClientInterceptor[]) ArrayUtils.add(interceptors, new ClickInterceptor());
		client.setInterceptors(interceptors);
		return client;
	}
	@Bean
	public HttpComponentsMessageSender httpComponentsMessageSender() throws Exception {
		HttpComponentsMessageSender httpComponentsMessageSender = new HttpComponentsMessageSender(); 
		httpComponentsMessageSender.setConnectionTimeout(timeout);
		httpComponentsMessageSender.setReadTimeout(timeout);
		httpComponentsMessageSender.setHttpClient(httpClient());
		return httpComponentsMessageSender;
	}

	public HttpClient httpClient() throws Exception {
		DispatchReference ref = new DispatchReference();
		clickEndPointMap = ref.getReferenceMap(dataSource(), Constants.DISPATCH_SELF_ASSIGN_OPTIONS);
		int connectTimeout = configuration().getClickConnectionTimeout();
		int readTimeout = configuration().getClickReadTimeout();
		int maxConnection = configuration().getMaxConnections();
		int maxConnectPerHost = configuration().getMaxConnectionsPerHost();
		this.applicationContext.setClickEndPointMap(clickEndPointMap);
		LOG.info("TechnicianAvailableJobsApplication::click properties from DB::"+clickEndPointMap);
		CredentialsProvider provider = new BasicCredentialsProvider();
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(clickEndPointMap.get("clickUserName"), EncryptionHelper.decrypt(clickEndPointMap.get("clickEncryptedPassword")));
		provider.setCredentials(AuthScope.ANY, credentials);		
		HttpRequestRetryHandler retryHandler = new HttpRequestRetryHandler() {
			@Override
			public boolean retryRequest(IOException exception, int executionCount, org.apache.http.protocol.HttpContext context) {
		        if (executionCount > 3) {
		            return false;
		    }
		    if (exception instanceof org.apache.http.NoHttpResponseException) {
		        return true;
		    }
		    return false;
		  }
		}; 
		RequestConfig requestConfig = RequestConfig.custom()
				   .setConnectTimeout(connectTimeout)
				   .setConnectionRequestTimeout(connectTimeout)
				   .setSocketTimeout(readTimeout)
				   .build();
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
	    connectionManager.setMaxTotal(maxConnection);
	    connectionManager.setDefaultMaxPerRoute(maxConnectPerHost);
		HttpClient httpClient  =  HttpClientBuilder.create().setConnectionManager(connectionManager).setDefaultCredentialsProvider(provider).setSSLSocketFactory(sslConnectionSocketFactory())
				.addInterceptorFirst(new RemoveSoapHeadersInterceptor()).setRetryHandler(retryHandler).setDefaultRequestConfig(requestConfig).build();
		return httpClient ;
	}

	public SSLConnectionSocketFactory sslConnectionSocketFactory() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException  {
		// NoopHostnameVerifier essentially turns hostname verification off as otherwise following error
		// is thrown: java.security.cert.CertificateException: No name matching localhost found
		return new SSLConnectionSocketFactory(sslContext(), NoopHostnameVerifier.INSTANCE);
	}

	public SSLContext sslContext() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, CertificateException, IOException  {
		File tempFile = File.createTempFile("truststore", "jks");
		tempFile.deleteOnExit();
		FileOutputStream out = new FileOutputStream(tempFile);
		IOUtils.copy(trustStore.getInputStream(), out);
		return SSLContextBuilder.create()
				.loadTrustMaterial(tempFile, trustStorePassword.toCharArray()).build();
	}	
	@Bean
	public Configuration configuration() {
		return new Configuration();
	}
	@Bean 
	public ServicePlannerDao servicePlannerDao() {
		return new ServicePlannerDaoImpl();
	}
	@Bean 
	public Util util() {
		return new Util();
	}
}

