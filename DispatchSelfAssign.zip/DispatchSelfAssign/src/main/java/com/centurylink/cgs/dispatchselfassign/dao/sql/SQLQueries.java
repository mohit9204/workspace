package com.centurylink.cgs.dispatchselfassign.dao.sql;

public class SQLQueries {

	public static final String SQL_FIND_JOBS_SUMMARY_BY_CORRELATION_ID = 
			"select * from ( "+
					"SELECT  %sortValues%,   "+
					"        CORRELATION_ID, "+
					"         TO_CHAR (APPT_FINISH, 'DD-MON-YYYY HH:MI:SS.FF AM') "+
					"            AS APPT_FINISH_STR, "+
					"         TO_CHAR (APPT_START, 'DD-MON-YYYY HH:MI:SS.FF AM') "+
					"            AS APPT_START_STR, "+
					"         TO_CHAR (DUE_DATE, 'DD-MON-YYYY HH:MI:SS.FF AM') "+
					"            AS DUE_DATE_STR, "+					
					"         ADDRESS_LINE2, "+
					"         CONTACT_NO, "+
					"         ADDRESS_LINE1, "+
					"         CUST_NAME, "+
					"         SERVICE_TYPE, "+
					"         CS_PRODUCT_TYP, "+
					"         DURATION, "+
					"         TO_CHAR (ASSIGNMENT_START, "+
					"                  'DD-MON-YYYY HH:MI:SS.FF AM') "+
					"            AS ASSIGNMENT_START_STR, "+
					"         DISPATCHER_CALL_ID, "+
					"         PRIORITY, "+
					"         TASK_STATUS, "+
					"         PRODUCT_TYPE, "+
					"         PROPERTY_ID, "+
					"		  TN_CKTID, "+
					"         GROUP_PARENT, "+
					"         GROUP_ID, "+
					"         tech_id, "+
					"         wirecenter, "+
					"         task_type_description, "+
					"         city, "+
					"         state "+
					"    FROM ( "+
					"SELECT /*+ index(m, DISPATCH_GROUP_MEMBERS_IX01 ) */ 'false' GROUP_PARENT, "+
					"       CASE "+
					"          WHEN G.GROUP_ID IS NULL THEN v.correlation_id "+
					"          WHEN G.DISPATCHER_CALL_ID != GROUP_NM THEN g.CORRELATION_ID "+
					"          ELSE v.CORRELATION_ID "+
					"       END "+
					"          AS CORRELATION_ID, "+
					"       v.TECH_ID, "+
					"       v.APPT_FINISH, "+
					"       v.APPT_START, "+
					"       v.ADDRESS_LINE2, "+
					"       v.CONTACT_NO, "+
					"       v.ADDRESS_LINE1, "+
					"       v.CUST_NAME, "+
					"       v.SERVICE_TYPE, "+
					"       v.DURATION, "+
					"       v.ASSIGNMENT_START, "+
					"       v.DISPATCHER_CALL_ID, "+
					"       v.PRIORITY, "+
					"       v.TASK_STATUS, "+
					"       v.PRODUCT_TYPE, "+
					"       v.PROPERTY_ID, "+
					"		v.TN_CKTID, "+
					"       CASE "+
					"          WHEN G.GROUP_ID IS NULL THEN NULL "+
					"          WHEN G.DISPATCHER_CALL_ID != GROUP_NM THEN NULL "+
					"          ELSE g.group_nm "+
					"       END "+
					"          AS GROUP_ID, "+
					"       2 GROUP_SORT, "+
					"       v.REASON_CODE, "+
					"       v.due_date, "+
					"       v.cs_product_typ, "+
					"       v.wirecenter, "+
					"       v.task_type_description, "+
					"       v.city, "+
					"       v.state "+
					"  FROM DISPATCH_GROUP_DETAILS G "+
					"       INNER JOIN DISPATCH_GROUP_MEMBERS M "+
					"          ON g.group_id = m.group_id "+
					"       INNER JOIN JOBS_DETAIL_V V ON m.correlation_id = v.correlation_id "+
					" WHERE g.correlation_id in (:correlationidList) "+
					"  %criteriaString%  "+
					"UNION ALL "+					
					"SELECT 'false' GROUP_PARENT, "+
					"       CASE "+
					"          WHEN G.GROUP_ID IS NULL THEN v.correlation_id "+
					"          WHEN G.DISPATCHER_CALL_ID != GROUP_NM THEN g.CORRELATION_ID "+
					"          ELSE v.CORRELATION_ID "+
					"       END "+
					"          AS CORRELATION_ID, "+
					"       v.TECH_ID, "+
					"       v.APPT_FINISH, "+
					"       v.APPT_START, "+
					"       v.ADDRESS_LINE2, "+
					"       v.CONTACT_NO, "+
					"       v.ADDRESS_LINE1, "+
					"       v.CUST_NAME, "+
					"       v.SERVICE_TYPE, "+
					"       v.DURATION, "+
					"       v.ASSIGNMENT_START, "+
					"       v.DISPATCHER_CALL_ID, "+
					"       v.PRIORITY, "+
					"       v.TASK_STATUS, "+
					"       v.PRODUCT_TYPE, "+
					"       v.PROPERTY_ID, "+
					"		v.TN_CKTID, "+
					"       CASE "+
					"          WHEN G.GROUP_ID IS NULL THEN NULL "+
					"          WHEN G.DISPATCHER_CALL_ID != GROUP_NM THEN NULL "+
					"          ELSE g.group_nm "+
					"       END "+
					"          AS GROUP_ID, "+
					"       2 GROUP_SORT, "+
					"       v.REASON_CODE, "+
					"       v.due_date, "+
					"       v.cs_product_typ, "+
					"       v.wirecenter, "+
					"       v.task_type_description, "+
					"       v.city, "+
					"       v.state "+
					"  FROM JOBS_DETAIL_V v "+
					"       LEFT OUTER JOIN DISPATCH_GROUP_MEMBERS M "+
					"          ON v.correlation_id = m.correlation_id "+
					"       LEFT OUTER JOIN DISPATCH_GROUP_DETAILS G ON m.GROUP_ID = g.GROUP_ID "+
					" WHERE v.correlation_id in (:correlationidList) "+
					"  %criteriaString%  "+					
					"UNION ALL "+
					"SELECT 'true' GROUP_PARENT, "+
					"       g.correlation_id, "+
					"       s.TECH_ID, "+
					"       g.APPT_FINISH, "+
					"       g.APPT_START, "+
					"       g.address_line2, "+
					"       g.contact_no, "+
					"       g.address_line1, "+
					"       g.cust_name, "+
					"       v.service_type, "+
					"       g.duration, "+
					"       s.ASSIGNMENT_START, "+
					"       g.dispatcher_call_id, "+
					"       g.priority, "+
					"       s.task_status, "+
					"       v.product_type, "+
					"       g.property_id, "+
					"		v.tn_cktid, "+
					"       g.group_nm, "+
					"       1 GROUP_SORT, "+
					"       v.reason_code, "+
					"       g.due_date, "+
					"       v.cs_product_typ, "+
					"       v.wirecenter,"+
					"       v.task_type_description, "+
					"       g.city, "+
					"       g.state "+
					"  FROM dispatch_group_details g "+
					"       INNER JOIN jobs_detail_v v ON g.parent_correlation_id = v.correlation_id "+
					"       LEFT OUTER JOIN dispatch_group_status s ON s.GROUP_ID = g.GROUP_ID "+
					" WHERE g.dispatcher_call_id = g.group_nm     "+
					" AND g.correlation_id in (:correlationidList) "+
					" %criteriaString% "+					
					")     "+
					" WHERE correlation_id in (:correlationidList) "+
					"%sortString% "+
					") where rownum < :rowLimit + 1 ";
	
	public static final String INSERT_REMARK = 
			"insert into remarks_details (correlation_id, type, remark, create_dt, update_dt)   "+
					"    select correlation_id, ?, ?, systimestamp, systimestamp  "+
					"    from (  "+
					"        select correlation_id from jobs_detail j where correlation_id = ?  "+
					"        and task_status not in ('Completed','Cancelled') "+
					"        union all  "+
					"        select m.correlation_id from dispatch_group_members m  "+
					"        inner join dispatch_group_details d on m.group_id = d.group_id "+
					"        inner join jobs_detail j on j.correlation_id = m.correlation_id  "+
					"        where d.correlation_id = ?  and j.task_status not in ('Completed','Cancelled') "+
					"    ) ";
	public static final String DELETE_REMARK = 
			"delete from remarks_details where type = ? and remark like ? and correlation_id in (  "+
					"    select correlation_id from jobs_detail  "+
					"    where correlation_id = ? and task_status not in ('Completed','Cancelled') "+
					"    union all  "+
					"    select m.correlation_id from dispatch_group_members m  "+
					"    inner join dispatch_group_details d on m.group_id = d.group_id "+
					"    inner join jobs_detail j on j.correlation_id = m.correlation_id  "+
					"    where d.correlation_id = ?  and j.task_status not in ('Completed','Cancelled') "+
					") ";
	public static final String UPDATE_JOB_STATUS = 
			"update jobs_detail set job_status = ? where correlation_id in (  "+
					"    select correlation_id from jobs_detail  "+
					"    where correlation_id = ? and task_status not in ('Completed','Cancelled') "+
					"    union all  "+
					"    select m.correlation_id from dispatch_group_members m  "+
					"    inner join dispatch_group_details d on m.group_id = d.group_id "+
					"    inner join jobs_detail j on j.correlation_id = m.correlation_id  "+
					"    where d.correlation_id = ?  and j.task_status not in ('Completed','Cancelled') "+
					") ";

	public static final String SQL_FIND_PARENT_CORRELATION_ID = "select parent_correlation_id from dispatch_group_details where correlation_id = ?";
	
	public static final String SQL_FIND_RESCHEDULED_JOBS_BY_TECH_ID = 
			"SELECT CORRELATION_ID,	"+
			        " TO_CHAR (APPT_FINISH,'DD-MON-YYYY HH:MI:SS.FF AM') "+
			        "    AS APPT_FINISH_STR,"+
			        " TO_CHAR (APPT_START,'DD-MON-YYYY HH:MI:SS.FF AM') "+
			        "    AS APPT_START_STR,"+
			        " TO_CHAR (DUE_DATE,'DD-MON-YYYY HH:MI:SS.FF AM')"+ 
			        "    AS DUE_DATE_STR,"+					
			        " ADDRESS_LINE2,"+
			        " CONTACT_NO,"+
			        " ADDRESS_LINE1,"+
			        " CUST_NAME,"+
			        " SERVICE_TYPE,"+
			        " CS_PRODUCT_TYP,"+
			        " DURATION,"+
			        " TO_CHAR (ASSIGNMENT_START,"+
			        "          'DD-MON-YYYY HH:MI:SS.FF AM')"+ 
			        "    AS ASSIGNMENT_START_STR,"+
			        " DISPATCHER_CALL_ID,"+
			        " PRIORITY,"+
			        " TASK_STATUS,"+
			        " PRODUCT_TYPE,"+
			        " PROPERTY_ID,"+
					" TN_CKTID,"+
			        " GROUP_PARENT,"+
			        " GROUP_ID,"+
			        " tech_id,"+
			        " wirecenter,"+
			        " task_type_description,"+
			        " city,"+
			        " state "+
			    "FROM ( "+
			 					
				"SELECT 'false' GROUP_PARENT,"+
			     "  CASE "+
			     "     WHEN G.GROUP_ID IS NULL THEN v.correlation_id "+ 
			     "     WHEN G.DISPATCHER_CALL_ID != GROUP_NM THEN g.CORRELATION_ID "+ 
			     "     ELSE v.CORRELATION_ID "+ 
			     "  END "+
			     "     AS CORRELATION_ID,"+
			     "  v.TECH_ID,"+
			     "  v.APPT_FINISH,"+
			     "  v.APPT_START,"+
			     "  v.ADDRESS_LINE2,"+
			     "  v.CONTACT_NO,"+
			     "  v.ADDRESS_LINE1,"+
			     "  v.CUST_NAME,"+
			     "  v.SERVICE_TYPE,"+
			     "  v.DURATION,"+
			     "  v.ASSIGNMENT_START,"+
			     "  v.DISPATCHER_CALL_ID,"+
			     "  v.PRIORITY,"+
			     "  v.TASK_STATUS,"+
			     "  v.PRODUCT_TYPE,"+
			     "  v.PROPERTY_ID,"+
				 "  v.TN_CKTID,"+
			     "  NULL AS GROUP_ID,"+					       
			     "  v.REASON_CODE,"+
			     "  v.due_date,"+
			     "  v.cs_product_typ,"+
			     "  v.wirecenter,"+
			     "  v.task_type_description,"+
			     "  v.city,"+
			     "  v.state "+
			  "FROM JOBS_DETAIL_V v "+ 
			   "    LEFT OUTER JOIN DISPATCH_GROUP_MEMBERS M "+ 
			   "       ON v.correlation_id = m.correlation_id "+
			   "    LEFT OUTER JOIN DISPATCH_GROUP_DETAILS G ON m.GROUP_ID = g.GROUP_ID "+ 
			 "WHERE v.REQUIRED_ENGG = (:techId) AND v.is_tech_rescheduled = 'Y' AND v.task_status in ('Unscheduled', 'Allocated') "+
			    "AND (g.group_id is null or g.group_nm <> g.dispatcher_call_id) "+
			 	
			"UNION ALL "+
			"SELECT 'true' GROUP_PARENT,"+
			 "      g.correlation_id,"+
			 "      s.TECH_ID,"+
			 "      g.APPT_FINISH,"+
			 "      g.APPT_START,"+
			 "      g.address_line2,"+
			 "      g.contact_no,"+
			 "      g.address_line1,"+
			 "      g.cust_name,"+
			 "      v.service_type,"+
			 "      g.duration,"+
			 "      s.ASSIGNMENT_START,"+
			 "      g.dispatcher_call_id,"+
			 "      g.priority,"+
			 "      s.task_status,"+
			 "      v.product_type,"+
			 "      g.property_id,"+
			 "		v.tn_cktid,"+
			 "      g.group_nm,"+
			 "      v.reason_code,"+
			 "      g.due_date,"+
			 "      v.cs_product_typ,"+
			 "      v.wirecenter,"+
			 "      v.task_type_description,"+
			 "      g.city,"+
			 "      g.state "+
			  "FROM dispatch_group_details g "+ 
			   "    INNER JOIN jobs_detail_v v ON g.parent_correlation_id = v.correlation_id "+ 
			   "    LEFT OUTER JOIN dispatch_group_status s ON s.GROUP_ID = g.GROUP_ID "+
			 "WHERE g.dispatcher_call_id = g.group_nm AND v.REQUIRED_ENGG =(:techId) AND v.is_tech_rescheduled ='Y' "+ 
			 	"AND v.task_status in ('Unscheduled', 'Allocated') "+					 					 				
			")"+   
			" ORDER BY DUE_DATE ASC";
	
	public static final String SQL_GET_TIME_ZONE = "select STATE, TIMEZONE from DISPATCH.SERVICE_AREA_HIERARCHY where SERVICE_AREA = :serviceArea";
		
	public static final String SQL_GET_WORKING_DISTRICTS = "select DISTRICT from CLICK_TECH_WORKING_DISTRICT where TECH_ID = :techId";
}
