package com.centurylink.cgs.dispatchselfassign.model;

import java.util.Date;

public class TaskStatus {
	private String taskStatus;
	private Date statusUpdateTimestamp;
	private String selfAssignFlag;
	private Date selfAssignTimestamp;
	
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public Date getStatusUpdateTimestamp() {
		return statusUpdateTimestamp;
	}
	public void setStatusUpdateTimestamp(Date statusUpdateTimestamp) {
		this.statusUpdateTimestamp = statusUpdateTimestamp;
	}
	public String getSelfAssignFlag() {
		return selfAssignFlag;
	}
	public void setSelfAssignFlag(String selfAssignFlag) {
		this.selfAssignFlag = selfAssignFlag;
	}
	public Date getSelfAssignTimestamp() {
		return selfAssignTimestamp;
	}
	public void setSelfAssignTimestamp(Date selfAssignTimestamp) {
		this.selfAssignTimestamp = selfAssignTimestamp;
	}

}
