package com.centurylink.cgs.dispatchselfassign.model;

public class TaskStatusRequest {
	public String getCallingSystem() {
		return callingSystem;
	}
	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}
	public TaskStatus getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(TaskStatus taskStatus) {
		this.taskStatus = taskStatus;
	}
	private String callingSystem;
	private TaskStatus taskStatus;
}
