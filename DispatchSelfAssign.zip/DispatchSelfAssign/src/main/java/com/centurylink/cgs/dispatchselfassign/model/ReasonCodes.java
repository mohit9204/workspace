package com.centurylink.cgs.dispatchselfassign.model;

public class ReasonCodes {
	public static final int SUCCESS = 1;
	public static final int TASK_IS_ALREADY_ASSIGNED = 2;
	public static final int UNAUTHORIZED = 3;


}
