package com.centurylink.cgs.dispatchselfassign.service;

public interface ScheduleService {
	public void refreshConfiguration();
}
