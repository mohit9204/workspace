package com.centurylink.cgs.dispatchselfassign.dao;

import java.util.List;

import com.centurylink.cgs.dispatchselfassign.exception.DispatchSelfAssignException;
import com.centurylink.cgs.dispatchselfassign.model.AvailableJob;

public interface JobsDao {
	public List<AvailableJob> getJobsSummaryByCorrelationIdList(List<String> correlationIdList, String techId, int rowLimit) throws DispatchSelfAssignException;
	public List<AvailableJob> getRescheduledJobsSummaryByTechId(String techId) throws DispatchSelfAssignException;

	public void insertRemark(String correlationId, String type, String remark) throws DispatchSelfAssignException;
	public void deleteRemark(String correlationId, String type, String remark) throws DispatchSelfAssignException;
	public void updateJobStatus(String correlationId, String status) throws DispatchSelfAssignException;
	public String getJobsCorrelationId(String correlationId) throws DispatchSelfAssignException;
	public List<String> getWorkingDistricts(String techId) throws DispatchSelfAssignException;
}
