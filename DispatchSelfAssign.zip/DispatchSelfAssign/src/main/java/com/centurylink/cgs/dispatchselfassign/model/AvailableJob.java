package com.centurylink.cgs.dispatchselfassign.model;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author wmiddle
 *
 */
public class AvailableJob {


	private Long priority;
	private String status;
	private String id;
	private String groupId;
	private String groupParent;
	private DispatchInfo dispatchInfo;
	private Appointment appointment;
	private CustomerInfo customerInfo;
	private Location location;
	private String productType;
	private String wireCenter;
	private String taskTypeDescription;
	
	@ApiModelProperty(value = "job ID", dataType = "String")
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@ApiModelProperty(value = "Status", dataType = "String")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@ApiModelProperty(value = "Product type info", dataType = "String")
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	@ApiModelProperty(value = "group Parent", dataType = "String")
	public String getGroupParent() {
		return groupParent;
	}
	public void setGroupParent(String groupParent) {
		this.groupParent = groupParent;
	}
	@ApiModelProperty(value = "group ID", dataType = "String")
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	@ApiModelProperty(value = "Job priority", dataType = "Long")
	public Long getPriority() {
		return priority;
	}
	public void setPriority(Long long1) {
		this.priority = long1;
	}
	@ApiModelProperty(value = "Appoinment info", dataType = "appoinmentInfo")
	public Appointment getAppointment() {
		return appointment;
	}
	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	@ApiModelProperty(value = "Job location info", dataType = "jobLocation")
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	@ApiModelProperty(value = "Dispatch info", dataType = "dispatchInfo")
	public DispatchInfo getDispatchInfo() {
		return dispatchInfo;
	}
	public void setDispatchInfo(DispatchInfo dispatchInfo) {
		this.dispatchInfo = dispatchInfo;
	}
	public CustomerInfo getCustomerInfo() {
		return customerInfo;
	}
	public void setCustomerInfo(CustomerInfo customerInfo) {
		this.customerInfo = customerInfo;
	}
	@ApiModelProperty(value = "Wirecenter info", dataType = "String")
	public String getWireCenter() {
		return wireCenter;
	}

	public void setWireCenter(String wireCenter) {
		this.wireCenter = wireCenter;
	}
	@ApiModelProperty(value = "TaskType Description", dataType = "String")
	public String getTaskTypeDescription() {
		return taskTypeDescription;
	}
	public void setTaskTypeDescription(String taskTypeDescription) {
		this.taskTypeDescription = taskTypeDescription;
	}
}
