package com.centurylink.cgs.dispatchselfassign.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="Appointment date/times used for jobs")
@JsonInclude(Include.NON_EMPTY)
public class Appointment {
	
	private String appointmentStartDateTime;
	private String appointmentEndDateTime;
	private String dueDate;
	private String accessAfterDateTime;
	private String accessBeforeDateTime;

	public String getAppointmentStartDateTime() {
		return appointmentStartDateTime;
	}
	public void setAppointmentStartDateTime(String appointmentStartDateTime) {
		this.appointmentStartDateTime = appointmentStartDateTime;
	}
	@ApiModelProperty(value="Appoinment end date time", dataType="date")
	public String getAppointmentEndDateTime() {
		return appointmentEndDateTime;
	}
	public void setAppointmentEndDateTime(String appointmentEndDateTime) {
		this.appointmentEndDateTime = appointmentEndDateTime;
	}
	@ApiModelProperty(value="Due date/time for appointment", dataType="date")
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	@ApiModelProperty(value="Appointment access after date time", dataType="date")
	public String getAccessAfterDateTime() {
		return accessAfterDateTime;
	}
	public void setAccessAfterDateTime(String accessAfterDateTime) {
		this.accessAfterDateTime = accessAfterDateTime;
	}
	@ApiModelProperty(value="Appointment access date time", dataType="date")
	public String getAccessBeforeDateTime() {
		return accessBeforeDateTime;
	}
	public void setAccessBeforeDateTime(String accessBeforeDateTime) {
		this.accessBeforeDateTime = accessBeforeDateTime;
	}
	}
