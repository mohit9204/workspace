package com.centurylink.cgs.dispatchselfassign.model;

import java.util.Date;

import com.centurylink.cgs.dispatchselfassign.json.CustomDateDeserializer;
import com.centurylink.cgs.dispatchselfassign.json.CustomDateSerializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModelProperty;

public class DispatchSelfAssignRequest {
	private String callingSystem;
	private String technicianId;
	private String district;
	private Date statusUpdateTimestamp;
	private int duration;
	
	public String getCallingSystem() {
		return callingSystem;
	}
	public void setCallingSystem(String callingSystem) {
		this.callingSystem = callingSystem;
	}
	public String getTechnicianId() {
		return technicianId;
	}
	public void setTechnicianId(String technicianId) {
		this.technicianId = technicianId;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	@ApiModelProperty(value="Status update timestamp", dataType="date")
	@JsonDeserialize(using = CustomDateDeserializer.class)
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getStatusUpdateTimestamp() {
		return statusUpdateTimestamp;
	}
	public void setStatusUpdateTimestamp(Date statusUpdateTimestamp) {
		this.statusUpdateTimestamp = statusUpdateTimestamp;
	}
	public int getDuration() {
		return duration;
	}

	public void setDuration(int durationSec) {
		this.duration = durationSec;
	}
}
