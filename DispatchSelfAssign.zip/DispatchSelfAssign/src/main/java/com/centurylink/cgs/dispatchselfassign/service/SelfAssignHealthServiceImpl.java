package com.centurylink.cgs.dispatchselfassign.service;

import org.springframework.stereotype.Service;

import com.centurylink.cgs.dispatchcommon.healthcheck.VersionHealthInfo;
import com.centurylink.cgs.dispatchcommon.logging.LogContext;
import com.centurylink.cgs.dispatchcommon.model.BaseResponse;
import com.centurylink.cgs.dispatchcommon.model.VersionHealthResponse;
import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.util.Constants;

@Service
public class SelfAssignHealthServiceImpl implements SelfAssignHealthService {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger
			.getLogger(SelfAssignHealthServiceImpl.class);

	public VersionHealthResponse getHealthDetails() {

		VersionHealthResponse healthResponse = new VersionHealthResponse();
		BaseResponse base = new BaseResponse();
		healthResponse.setBaseResponse(base);
		boolean success = true;

		LogContext context = new LogContext().appendMessage("Health Check");
		LOG.info(context);

		if (!VersionHealthInfo.setVersionInfo(healthResponse, Constants.APPLICATION_SERVICE_NAME))
			success = false;

		if (!success) {
			base.setResponseStatus(BaseResponse.responseStatusValues.Failure);
			base.setMessage("Health Check Failed");
			base.setReasonCode(-1);
		} else {
			base.setResponseStatus(BaseResponse.responseStatusValues.Success);
			base.setMessage("Health Check Succeeded");
			base.setReasonCode(1);
		}

		context.add("status", base.getMessage());
		LOG.info(context);
		
		return healthResponse;
	}

}
