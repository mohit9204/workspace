package com.centurylink.cgs.dispatchselfassign.util;

import java.util.HashMap;

public class TimeZoneMapper {

	public static final HashMap<String, String> map = new HashMap<String, String>();
	static {
		map.put("Eastern Standard Time", "US/Eastern");
		map.put("Central Standard Time", "US/Central");
		map.put("Mountain Standard Time", "US/Mountain");
		map.put("Pacific Standard Time", "US/Pacific");
		map.put("AZ", "US/Arizona");
	}
}
