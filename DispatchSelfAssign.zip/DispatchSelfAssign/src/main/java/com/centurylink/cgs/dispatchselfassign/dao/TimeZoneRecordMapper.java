package com.centurylink.cgs.dispatchselfassign.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.dispatchselfassign.model.StateTimeZone;

public class TimeZoneRecordMapper  implements RowMapper<StateTimeZone>{

	@Override
	public StateTimeZone mapRow(ResultSet rs, int rowNum) throws SQLException {
		StateTimeZone stateTimeZone = new StateTimeZone();
		stateTimeZone.setTimeZone(rs.getString("TIMEZONE"));
		stateTimeZone.setState(rs.getString("STATE"));
		return stateTimeZone;
	}
}

