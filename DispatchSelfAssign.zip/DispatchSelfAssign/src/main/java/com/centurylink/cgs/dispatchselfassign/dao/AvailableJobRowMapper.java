package com.centurylink.cgs.dispatchselfassign.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.centurylink.cgs.dispatchselfassign.model.Appointment;
import com.centurylink.cgs.dispatchselfassign.model.AvailableJob;
import com.centurylink.cgs.dispatchselfassign.model.CustomerInfo;
import com.centurylink.cgs.dispatchselfassign.model.DispatchInfo;
import com.centurylink.cgs.dispatchselfassign.model.Location;

public class AvailableJobRowMapper  implements RowMapper<AvailableJob>{

	@Override
	public AvailableJob mapRow(ResultSet rs, int rowNum) throws SQLException {
		AvailableJob jobSummary = new AvailableJob();
		Appointment appointment = new Appointment();
		appointment.setAppointmentEndDateTime(rs.getString("APPT_FINISH_STR"));
		appointment.setAppointmentStartDateTime(rs.getString("APPT_START_STR"));
		appointment.setDueDate(rs.getString("DUE_DATE_STR"));
		
		if (appointment.getAppointmentEndDateTime() != null || appointment.getAppointmentStartDateTime() != null || appointment.getDueDate() != null) {
			jobSummary.setAppointment(appointment);	
		}

		Location location = new Location();
		location.setAddressLine1(rs.getString("ADDRESS_LINE1"));
		location.setAddressLine2(rs.getString("ADDRESS_LINE2"));
		location.setCity(rs.getString("CITY"));
		location.setState(rs.getString("STATE"));
		
		if (location.getAddressLine1() != null || location.getAddressLine2() != null ) {
			jobSummary.setLocation(location);
		}
			
		CustomerInfo customerInfo = new CustomerInfo();
		customerInfo.setPrimaryContactNumber(rs.getString("CONTACT_NO"));
		customerInfo.setCustomerName(rs.getString("CUST_NAME"));
		customerInfo.setCircuitId(rs.getString("TN_CKTID"));
		if (customerInfo.getPrimaryContactNumber() != null || customerInfo.getCustomerName() != null || customerInfo.getCircuitId() != null) {
			jobSummary.setCustomerInfo(customerInfo);
		}
			
		DispatchInfo dispatchInfo = new DispatchInfo();
		jobSummary.setDispatchInfo(dispatchInfo);
		long correlationId = rs.getLong("CORRELATION_ID");
		dispatchInfo.setDispatchCorrelationId(rs.wasNull() ? null : correlationId);
		dispatchInfo.setDispatchType(rs.getString("SERVICE_TYPE"));
		long duration = rs.getLong("DURATION");
		dispatchInfo.setDuration(rs.wasNull() ? null : duration);
		jobSummary.setId(rs.getString("DISPATCHER_CALL_ID"));
		long priority = rs.getLong("PRIORITY");
		jobSummary.setPriority(rs.wasNull() ? null : priority);
		jobSummary.setStatus(rs.getString("TASK_STATUS"));
		jobSummary.setProductType(rs.getString("PRODUCT_TYPE"));
		
		String parent = rs.getString("GROUP_PARENT");
		if (parent != null && "true".equals(parent))
			jobSummary.setGroupParent("true");
		jobSummary.setGroupId(rs.getString("GROUP_ID"));
		jobSummary.setWireCenter(rs.getString("WIRECENTER"));
		jobSummary.setTaskTypeDescription(rs.getString("TASK_TYPE_DESCRIPTION"));
		return jobSummary;

	}

}

