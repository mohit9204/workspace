package com.centurylink.cgs.dispatchselfassign.service;

import java.text.ParseException;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;

import com.centurylink.cgs.dispatchselfassign.model.DispatchSelfAssignResponse;

public interface AssignJobService {
	
	public DispatchSelfAssignResponse assignJob(String techId, String district, String correlationId, String callingSystem, Date statusUpdateTimestamp, int duration) throws Exception;

}
