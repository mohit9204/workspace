package com.centurylink.cgs.dispatchselfassign.util;

import java.util.HashMap;

public class QueryBuilder {

	public String buildQuery(String sql, HashMap<String,String> criteria, HashMap<String,String> sortValues) {
		StringBuilder sortString = new StringBuilder("order by ");
		StringBuilder sortValuesString = new StringBuilder();
		StringBuilder criteriaString = new StringBuilder();
		
		for (int i = 1; true; ++i) {
			String key = String.format("sort%d", i);
			if (sortValues.get(key) != null) {
				String sortValue = sortValues.get(key); 
				if (i == 1) {
					sortValuesString.append(String.format("%s ", sortValue));
					sortString.append(String.format("%s", key));
				}
				else {
					sortValuesString.append(String.format(", \n%s", sortValue));
					sortString.append(String.format(", %s", key));
				}
			} else
				break;
		}
		for (int i = 1; true; ++i) {
			String key = String.format("criteria%d", i);
			if (criteria.get(key) != null) {
				criteriaString.append(String.format("and %s \n", criteria.get(key)));
			} else
				break;
		}
		String query = sql.replace("%sortValues%", sortValuesString.toString())
							.replace("%sortString%", sortString.toString())
							.replace("%criteriaString%", criteriaString.toString());
		return query;
	}
}
