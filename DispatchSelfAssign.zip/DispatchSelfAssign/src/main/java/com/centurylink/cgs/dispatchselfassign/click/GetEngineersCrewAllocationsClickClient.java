package com.centurylink.cgs.dispatchselfassign.click;

import java.io.IOException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.TransformerException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.centurylink.cgs.dispatchselfassign.logging.DispatchSelfAssignLogger;
import com.centurylink.cgs.dispatchselfassign.util.Constants;
import com.clicksoftware.DistrictReference;
import com.clicksoftware.EngineerReference;
import com.clicksoftware.EngineersReferences;
import com.clicksoftware.GetEngineersCrewAllocations;
import com.clicksoftware.GetEngineersCrewAllocationsResponse;
import com.clicksoftware.serviceoptimizeservice.OptionalParameters;

public class GetEngineersCrewAllocationsClickClient extends WebServiceGatewaySupport {
	private static final DispatchSelfAssignLogger LOG = DispatchSelfAssignLogger.getLogger(GetEngineersCrewAllocationsClickClient.class);
	
	@Value("${click.date.format}")
	private String clickDateFormat;

	@Value("${click.getengineerscrewallocations.soap.action}")
	private String clickSoapAction;
	
	public GetEngineersCrewAllocationsResponse getCrewAllocations(String techId, String district, XMLGregorianCalendar start, XMLGregorianCalendar finish) throws DatatypeConfigurationException {
		
		GetEngineersCrewAllocations request = constructRequest(techId, district,  start, finish);
		WebServiceTemplate wsTemplate = getWebServiceTemplate();		
		
		GetEngineersCrewAllocationsResponse response = (GetEngineersCrewAllocationsResponse) wsTemplate.marshalSendAndReceive(request, 
				new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(WebServiceMessage requestMessage) throws IOException, TransformerException {
				try {
					SoapMessage soapMsg = ((SoapMessage) requestMessage);
					// get the header from the SOAP message		
					SoapHeader soapHeader = soapMsg.getSoapHeader();
					soapMsg.setSoapAction(clickSoapAction);					
					// create the header element
					OptionalParameters optionalParameters = new OptionalParameters();
					optionalParameters.setCallerIdentity(Constants.CALLER_IDENTY); 
					optionalParameters.setErrorOnNonExistingDictionaries(true);
					// create a marshaller
					JAXBContext context = JAXBContext.newInstance(OptionalParameters.class);
					Marshaller marshaller = context.createMarshaller();
					// marshal the headers into the specified result
					marshaller.marshal(optionalParameters, soapHeader.getResult());
				} catch (JAXBException  e) {
					throw new TransformerException("Error while marshalling");
				}
			}
		});
		LOG.trace("ProcessTaskExClickClient::allocateTask::end");	
		return response;
	}

	private GetEngineersCrewAllocations constructRequest(String techId, String district, XMLGregorianCalendar start, XMLGregorianCalendar finish) {
		GetEngineersCrewAllocations request = new GetEngineersCrewAllocations();
		EngineersReferences engineers = new EngineersReferences();
		request.setEngineers(engineers);
		EngineerReference engineer = new EngineerReference();
		engineers.getEngineer().add(engineer);
		engineer.setID(techId);
		DistrictReference districtRef = new DistrictReference();
		engineer.setDistrict(districtRef);
		districtRef.setName(district);
		request.setStart(start);
		request.setFinish(finish);
		return request;
	}
}
